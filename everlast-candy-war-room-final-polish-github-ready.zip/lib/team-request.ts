import { NextRequest, NextResponse } from 'next/server';

export function privateResponse(body: unknown, status = 200): NextResponse {
  const res = NextResponse.json(body, { status });
  res.headers.set('Cache-Control', 'private, no-store');
  res.headers.set('X-Content-Type-Options', 'nosniff');
  return res;
}

/** Cookie-authenticated POSTs must originate from this site's own origin. */
export function isSameOrigin(req: NextRequest): boolean {
  const origin = req.headers.get('origin');
  if (!origin) return false;
  try {
    const target = new URL(req.url);
    return new URL(origin).host === target.host && new URL(origin).protocol === target.protocol;
  } catch { return false; }
}

export function isUuid(value: unknown): value is string {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
}
