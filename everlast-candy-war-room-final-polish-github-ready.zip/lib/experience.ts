import type { Character, LevelEvent, WarSide } from './types';

/**
 * Tibia experience formula: total XP needed to reach level L.
 *   exp(L) = 50/3 * (L^3 - 6L^2 + 17L - 12)
 * Level 1 => 0 XP.
 */
export function expForLevel(level: number): number {
  if (!level || level <= 1) return 0;
  const l = level;
  return Math.round((50 / 3) * (l * l * l - 6 * l * l + 17 * l - 12));
}

export function expToNextLevel(level: number): number {
  return expForLevel(level + 1) - expForLevel(level);
}

/** Experience gained by moving from one level to another (negative on a level loss). */
export function expBetween(from: number | null, to: number | null): number {
  if (from == null || to == null) return 0;
  return expForLevel(to) - expForLevel(from);
}

export function formatExp(n: number): string {
  const abs = Math.abs(n);
  const sign = n < 0 ? '-' : '';
  if (abs >= 1e12) return `${sign}${(abs / 1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `${sign}${(abs / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `${sign}${(abs / 1e6).toFixed(1)}M`;
  if (abs >= 1e3) return `${sign}${(abs / 1e3).toFixed(1)}K`;
  return `${n}`;
}

export type TrackedSide = Extract<WarSide, 'everlast' | 'ally' | 'enemy'>;
export const TRACKED_SIDES: TrackedSide[] = ['everlast', 'ally', 'enemy'];

export interface PlayerProgress {
  name: string;
  side: WarSide;
  vocation: string | null;
  guild: string | null;
  level: number;
  totalExp: number;
  online: boolean;
  gained: number;       // levels gained (sum of positive diffs) in the window
  lost: number;         // levels lost (sum of negative diffs, positive number)
  netLevels: number;    // gained - lost
  expGained: number;    // exp gained from net level change in the window
  events: number;
  biggestJump: number;
}

export interface GuildProgress {
  side: TrackedSide;
  members: number;
  online: number;
  avgLevel: number;
  medianLevel: number;
  totalExp: number;
  avgExp: number;
  highest: PlayerProgress | null;
  levelsGained: number;
  levelsLost: number;
  netLevels: number;
  expGained: number;
  activeGainers: number; // members with a net gain in the window
  vocations: { vocation: string; count: number; avgLevel: number }[];
  brackets: { label: string; count: number }[];
}

const BRACKETS: [string, number, number][] = [
  ['< 100', 0, 99],
  ['100-199', 100, 199],
  ['200-399', 200, 399],
  ['400-599', 400, 599],
  ['600-799', 600, 799],
  ['800+', 800, Infinity],
];

export function buildPlayerProgress(characters: Character[], events: LevelEvent[]): PlayerProgress[] {
  const byName = new Map<string, PlayerProgress>();
  for (const c of characters) {
    if (c.deleted || c.level == null) continue;
    byName.set(c.name.toLowerCase(), {
      name: c.name,
      side: c.side,
      vocation: c.vocation,
      guild: c.guild_name,
      level: c.level,
      totalExp: expForLevel(c.level),
      online: c.online,
      gained: 0,
      lost: 0,
      netLevels: 0,
      expGained: 0,
      events: 0,
      biggestJump: 0,
    });
  }
  for (const ev of events) {
    const p = byName.get(ev.character_name.toLowerCase());
    if (!p) continue;
    p.events++;
    if (ev.level_diff > 0) {
      p.gained += ev.level_diff;
      if (ev.level_diff > p.biggestJump) p.biggestJump = ev.level_diff;
    } else {
      p.lost += Math.abs(ev.level_diff);
    }
    p.expGained += expBetween(ev.previous_level, ev.new_level);
  }
  Array.from(byName.values()).forEach((p) => { p.netLevels = p.gained - p.lost; });
  return Array.from(byName.values());
}

export function buildGuildProgress(players: PlayerProgress[], side: TrackedSide): GuildProgress {
  const members = players.filter((p) => p.side === side);
  const levels = members.map((m) => m.level).sort((a, b) => a - b);
  const sum = (arr: number[]) => arr.reduce((a, b) => a + b, 0);
  const median = levels.length
    ? levels.length % 2 === 1
      ? levels[Math.floor(levels.length / 2)]
      : (levels[levels.length / 2 - 1] + levels[levels.length / 2]) / 2
    : 0;

  const vocMap = new Map<string, { count: number; levelSum: number }>();
  for (const m of members) {
    const key = m.vocation ?? 'Unknown';
    const cur = vocMap.get(key) ?? { count: 0, levelSum: 0 };
    cur.count++;
    cur.levelSum += m.level;
    vocMap.set(key, cur);
  }

  return {
    side,
    members: members.length,
    online: members.filter((m) => m.online).length,
    avgLevel: members.length ? Math.round(sum(levels) / members.length) : 0,
    medianLevel: median,
    totalExp: sum(members.map((m) => m.totalExp)),
    avgExp: members.length ? Math.round(sum(members.map((m) => m.totalExp)) / members.length) : 0,
    highest: members.reduce<PlayerProgress | null>((best, m) => (!best || m.level > best.level ? m : best), null),
    levelsGained: sum(members.map((m) => m.gained)),
    levelsLost: sum(members.map((m) => m.lost)),
    netLevels: sum(members.map((m) => m.netLevels)),
    expGained: sum(members.map((m) => m.expGained)),
    activeGainers: members.filter((m) => m.netLevels > 0).length,
    vocations: Array.from(vocMap.entries())
      .map(([vocation, v]) => ({ vocation, count: v.count, avgLevel: Math.round(v.levelSum / v.count) }))
      .sort((a, b) => b.count - a.count),
    brackets: BRACKETS.map(([label, lo, hi]) => ({
      label,
      count: members.filter((m) => m.level >= lo && m.level <= hi).length,
    })),
  };
}

export interface DailyLevelPoint {
  date: string;
  label: string;
  everlast: number;
  ally: number;
  enemy: number;
}

/** Levels gained per day, per guild side, for the last `days` days. */
export function buildDailyLevelSeries(events: LevelEvent[], days: number): DailyLevelPoint[] {
  const points: DailyLevelPoint[] = [];
  const index = new Map<string, DailyLevelPoint>();
  const now = new Date();
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    const pt: DailyLevelPoint = {
      date: key,
      label: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      everlast: 0,
      ally: 0,
      enemy: 0,
    };
    points.push(pt);
    index.set(key, pt);
  }
  for (const ev of events) {
    if (ev.level_diff <= 0) continue;
    const side = ev.character_side;
    if (side !== 'everlast' && side !== 'ally' && side !== 'enemy') continue;
    const pt = index.get(new Date(ev.observed_at).toISOString().slice(0, 10));
    if (pt) pt[side] += ev.level_diff;
  }
  return points;
}
