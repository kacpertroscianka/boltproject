/**
 * Client-side data fetcher that goes through the authenticated API proxy.
 * All data requests hit /api/data?q=... which checks the session cookie server-side.
 */

export async function fetchData<T>(
  query: string,
  params?: Record<string, string | number | boolean | undefined>,
): Promise<T> {
  const url = new URL('/api/data', window.location.origin);
  url.searchParams.set('q', query);
  if (params) {
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null) url.searchParams.set(k, String(v));
    }
  }
  const res = await fetch(url.toString(), { credentials: 'same-origin' });
  if (!res.ok) {
    if (res.status === 401) {
      throw new AuthError('Unauthorized');
    }
    const body = await res.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(body.error || `Request failed: ${res.status}`);
  }
  const body = await res.json();
  return body.data as T;
}

export class AuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AuthError';
  }
}
