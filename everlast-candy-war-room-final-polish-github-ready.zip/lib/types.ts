export type WarSide = 'everlast' | 'enemy' | 'ally' | 'neutral';

export type Vocation =
  | 'Elite Knight'
  | 'Royal Paladin'
  | 'Master Sorcerer'
  | 'Elder Druid'
  | 'Exalted Monk'
  | 'Monk'
  | 'Knight'
  | 'Paladin'
  | 'Sorcerer'
  | 'Druid'
  | 'None';

export interface Guild {
  id: string;
  name: string;
  world: string;
  side: WarSide;
  alliance: string | null;
  display_label: string | null;
  logo_url: string | null;
  motd: string | null;
  member_count: number;
  last_synced_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Character {
  id: string;
  name: string;
  world: string;
  vocation: string | null;
  level: number | null;
  sex: string | null;
  guild_id: string | null;
  guild_name: string | null;
  side: WarSide;
  online: boolean;
  last_seen_at: string | null;
  last_observed_level: number | null;
  previous_level: number | null;
  rank: string | null;
  deleted: boolean;
  tibidata_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface DeathEvent {
  id: string;
  character_id: string | null;
  character_name: string;
  character_level: number;
  character_vocation: string | null;
  character_side: WarSide;
  killer_name: string | null;
  killer_vocation: string | null;
  killer_level: number | null;
  killer_guild_name: string | null;
  killer_side: WarSide | null;
  reason: string;
  is_pvp: boolean;
  is_player_kill: boolean;
  death_time: string;
  killers: TibiaKiller[] | null;
  assists: TibiaKiller[] | null;
  participated_players: string[] | null;
  assisted_players: string[] | null;
  source: string | null;
  world: string | null;
  created_at: string;
  updated_at: string;
}

export interface ActivitySnapshot {
  id: string;
  guild_id: string | null;
  guild_name: string;
  side: WarSide;
  online_count: number;
  total_members: number;
  online_members: string[] | null;
  snapshot_at: string;
}

export interface WatchlistEntry {
  id: string;
  user_id: string;
  character_id: string;
  notify_on_death: boolean;
  notify_on_level_change: boolean;
  last_notified_death_id: string | null;
  created_at: string;
  character?: Character;
}

export interface LevelEvent {
  id: string;
  character_id: string | null;
  character_name: string;
  previous_level: number | null;
  new_level: number | null;
  level_diff: number;
  observed_at: string;
  source: string | null;
  world: string | null;
  character_side?: WarSide;
  character_guild_name?: string | null;
  character_vocation?: string | null;
}

export interface SyncLogEntry {
  id: string;
  job: string;
  status: string;
  message: string | null;
  records_processed: number;
  started_at: string;
  finished_at: string | null;
}

export type Attribution = 'confirmed' | 'inferred' | 'unknown' | 'same_alliance' | 'pve';
export type WarCategory =
  | 'friendly_kills_enemy'
  | 'enemy_kills_friendly'
  | 'friendly_kills_enemy_inferred'
  | 'enemy_kills_friendly_inferred'
  | 'same_alliance'
  | 'pve'
  | 'excluded';

export interface TibiaKiller {
  name: string;
  player: boolean;
  summon?: string;
  traded?: boolean;
}

export interface CanonicalDeathEvent {
  id: string;
  character_id: string | null;
  character_name: string;
  character_level: number;
  character_vocation: string | null;
  character_side: WarSide;
  killer_name: string | null;
  killer_vocation: string | null;
  killer_level: number | null;
  killer_guild_name: string | null;
  killer_side: WarSide | null;
  reason: string;
  is_pvp: boolean;
  is_player_kill: boolean;
  death_time: string;
  killers: TibiaKiller[] | null;
  assists: TibiaKiller[] | null;
  participated_players: string[] | null;
  assisted_players: string[] | null;
  source: string | null;
  world: string | null;
  created_at: string;
  updated_at: string;
}

export interface CanonicalWarEvent {
  event_id: string;
  character_id: string | null;
  character_name: string;
  character_level: number;
  character_vocation: string | null;
  character_side: WarSide;
  killer_name: string | null;
  killer_vocation: string | null;
  killer_level: number | null;
  stored_killer_guild: string | null;
  stored_killer_side: WarSide | null;
  cause: string;
  is_pvp: boolean;
  is_player_kill: boolean;
  death_time: string;
  killers: TibiaKiller[] | null;
  assists: TibiaKiller[] | null;
  participated_players: string[] | null;
  assisted_players: string[] | null;
  source: string | null;
  world: string | null;
  created_at: string;
  victim_guild: string | null;
  victim_current_side: WarSide | null;
  killer_current_guild: string | null;
  killer_current_side: WarSide | null;
  attribution: Attribution;
  war_category: WarCategory;
  participant_count: number;
  assist_count: number;
}


export type BattleReadiness = 'ready' | 'omw' | 'afk';

export interface TeamWarCall {
  id: string;
  title: string;
  meeting_point: string | null;
  starts_at: string | null;
  notes: string | null;
  created_by: string | null;
  status: 'active' | 'ended' | 'cancelled';
  ended_at?: string | null;
  created_at: string;
  updated_at: string;
}

export interface TeamWarCallResponse {
  id: string;
  war_call_id: string;
  client_id: string;
  player_name: string;
  player_side: WarSide;
  readiness_status: BattleReadiness;
  note: string | null;
  updated_at: string;
}

export interface RetroFragGuardEntry {
  id: string;
  character_name: string;
  side: WarSide;
  unjust_24h: number;
  unjust_7d: number;
  unjust_30d: number;
  notes: string | null;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface RetroObservedLastHits {
  character_name: string;
  last_hits_24h: number;
  last_hits_7d: number;
  last_hits_30d: number;
}

export interface TeamSupplyChecklist {
  id: string; war_call_id: string; client_id: string; player_name: string; player_side: WarSide;
  potions: boolean; runes: boolean; amulets: boolean; backpack: boolean; voice_comms: boolean;
  note: string | null; updated_at: string;
}

export interface AfterBattleSummary {
  totalEvents: number; allianceConfirmed: number; enemyConfirmed: number;
  allianceInferred: number; enemyInferred: number; allianceDeaths: number; enemyDeaths: number;
  pveDeaths: number; sameAlliance: number;
}
export interface AfterBattleEvent {
  eventId: string; time: string; victim: string; killer: string | null; category: string; victimLevel: number;
}
export type AfterBattleReport = { available: false; reason: string } | {
  available: true; callId: string; callTitle: string; windowStart: string; windowEnd: string;
  summary: AfterBattleSummary; events: AfterBattleEvent[]; method: string;
};
