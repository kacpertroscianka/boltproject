import type { Character, DeathEvent, ActivitySnapshot, Guild, SyncLogEntry, LevelEvent, WarSide, CanonicalWarEvent, CanonicalDeathEvent, Attribution, WarCategory, TeamWarCall, TeamWarCallResponse, RetroFragGuardEntry, RetroObservedLastHits } from './types';
import { GUILD_EVERLAST, GUILD_ALLY, GUILD_ENEMY, isFriendlySide, isEnemySide } from './tibia';
import { dayKey } from './format';
import { fetchData } from './api-client';

// ----- Guilds -----
export async function getGuilds(): Promise<Guild[]> {
  return fetchData<Guild[]>('guilds');
}

export async function getGuildByName(name: string): Promise<Guild | null> {
  const all = await fetchData<Guild[]>('guilds');
  return all.find((g) => g.name === name) ?? null;
}

// ----- Characters -----
export async function getCharactersBySide(side: WarSide): Promise<Character[]> {
  return fetchData<Character[]>('characters-by-side', { sides: side });
}

export async function getCharactersBySides(sides: WarSide[]): Promise<Character[]> {
  return fetchData<Character[]>('characters-by-side', { sides: sides.join(',') });
}

export async function getCharacterByName(name: string): Promise<Character | null> {
  return fetchData<Character | null>('character-by-name', { name });
}

export async function searchCharacters(query: string, limit = 20): Promise<Character[]> {
  return fetchData<Character[]>('search-characters', { query, limit });
}

// ----- Death Events (from canonical_death_events — deduplicated) -----
export async function getRecentDeaths(limit = 50): Promise<DeathEvent[]> {
  return fetchData<DeathEvent[]>('recent-deaths', { limit });
}

export async function getDeathsBySide(side: WarSide, limit = 100): Promise<DeathEvent[]> {
  const all = await fetchData<DeathEvent[]>('recent-deaths', { limit });
  return all.filter((d) => d.character_side === side);
}

export async function getDeathsForCharacter(name: string, limit = 50): Promise<DeathEvent[]> {
  // Server-side lookup by name: complete history (the old client filter only saw the
  // latest 2000 deaths and dropped rows whose character_id was null).
  return fetchData<DeathEvent[]>('deaths-for-character', { name, limit });
}

/** Recorded PvP events where the character made the last hit, participated or assisted.
 * Unlike a global feed, this searches the full canonical view server-side.
 * A safety cap of 5000 applies; the profile warns when it is reached.
 */
export async function getCombatEventsForCharacter(name: string, limit = 5000): Promise<CanonicalWarEvent[]> {
  return fetchData<CanonicalWarEvent[]>('combat-for-character', { name, limit });
}

export async function getCanonicalDeathsForCharacterName(name: string, limit = 50): Promise<CanonicalDeathEvent[]> {
  return fetchData<CanonicalDeathEvent[]>('deaths-for-character', { name, limit });
}

// ----- Activity Snapshots -----
export async function getRecentActivity(limit = 20): Promise<ActivitySnapshot[]> {
  return fetchData<ActivitySnapshot[]>('recent-activity', { limit });
}

// ----- Sync Log -----
export async function getRecentSyncLogs(limit = 10): Promise<SyncLogEntry[]> {
  return fetchData<SyncLogEntry[]>('recent-sync-logs', { limit });
}

// ----- Aggregations -----
export interface WarScore {
  everlastKills: number;
  allyKills: number;
  friendlyKills: number;
  enemyKills: number;
  everlastDeaths: number;
  allyDeaths: number;
  friendlyDeaths: number;
  enemyDeaths: number;
  ratio: number;
}

/**
 * Compute alliance war score from canonical death events.
 * The canonical_death_events table is already deduplicated by (character_name, death_time)
 * so no client-side dedup is needed.
 *
 * Friendly = Everlast (side='everlast') + Terror Squad (side='ally')
 * Enemy = Mandatory Again (side='enemy')
 *
 * Kill counting rules:
 * - Friendly kill = enemy victim killed by a friendly killer (everlast or ally)
 * - Enemy kill = friendly victim (everlast or ally) killed by an enemy killer
 * - Same-alliance kills do NOT count
 * - PvE deaths are excluded from kill counts
 * - Neutral PvP deaths (killer_side is null/neutral) are excluded
 */
export function computeWarScore(deaths: DeathEvent[]): WarScore {
  let everlastKills = 0;
  let allyKills = 0;
  let enemyKills = 0;

  for (const d of deaths) {
    if (!d.is_player_kill) continue;

    if (isEnemySide(d.character_side) && isFriendlySide(d.killer_side)) {
      if (d.killer_side === 'everlast') everlastKills++;
      if (d.killer_side === 'ally') allyKills++;
    }

    if (isFriendlySide(d.character_side) && isEnemySide(d.killer_side)) {
      enemyKills++;
    }
  }

  const everlastDeaths = deaths.filter((d) => d.character_side === 'everlast').length;
  const allyDeaths = deaths.filter((d) => d.character_side === 'ally').length;
  const enemyDeaths = deaths.filter((d) => d.character_side === 'enemy').length;
  const friendlyKills = everlastKills + allyKills;
  const friendlyDeaths = everlastDeaths + allyDeaths;
  const ratio = enemyKills > 0 ? friendlyKills / enemyKills : friendlyKills > 0 ? friendlyKills : 0;

  return {
    everlastKills,
    allyKills,
    friendlyKills,
    enemyKills,
    everlastDeaths,
    allyDeaths,
    friendlyDeaths,
    enemyDeaths,
    ratio,
  };
}

export interface DailyDeathPoint {
  date: string;
  label: string;
  friendlyKills: number;
  enemyKills: number;
  friendlyDeaths: number;
  enemyDeaths: number;
}

export function buildDailySeries(deaths: DeathEvent[], days = 7): DailyDeathPoint[] {
  const now = new Date();
  const buckets: DailyDeathPoint[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const key = dayKey(d);
    buckets.push({
      date: key,
      label: d.toLocaleDateString('en-US', { weekday: 'short', day: 'numeric' }),
      friendlyKills: 0,
      enemyKills: 0,
      friendlyDeaths: 0,
      enemyDeaths: 0,
    });
  }
  const map = new Map(buckets.map((b) => [b.date, b]));
  for (const death of deaths) {
    const key = dayKey(death.death_time);
    const bucket = map.get(key);
    if (!bucket) continue;
    if (death.is_player_kill) {
      if (isEnemySide(death.character_side) && isFriendlySide(death.killer_side)) bucket.friendlyKills++;
      if (isFriendlySide(death.character_side) && isEnemySide(death.killer_side)) bucket.enemyKills++;
    }
    if (isFriendlySide(death.character_side)) bucket.friendlyDeaths++;
    if (isEnemySide(death.character_side)) bucket.enemyDeaths++;
  }
  return buckets;
}

export interface TopKiller {
  name: string;
  vocation: string | null;
  level: number | null;
  guild: string | null;
  side: WarSide | null;
  kills: number;
}

export function computeTopKillers(deaths: DeathEvent[], limit = 10): TopKiller[] {
  const counts = new Map<string, TopKiller>();
  for (const d of deaths) {
    if (!d.is_player_kill || !d.killer_name) continue;
    if (d.killer_name === d.character_name) continue;
    const existing = counts.get(d.killer_name);
    if (existing) {
      existing.kills++;
    } else {
      counts.set(d.killer_name, {
        name: d.killer_name,
        vocation: d.killer_vocation,
        level: d.killer_level,
        guild: d.killer_guild_name,
        side: d.killer_side,
        kills: 1,
      });
    }
  }
  return Array.from(counts.values()).sort((a, b) => b.kills - a.kills).slice(0, limit);
}

export interface MostKilled {
  name: string;
  vocation: string | null;
  level: number;
  side: WarSide;
  deaths: number;
}

export function computeMostKilled(deaths: DeathEvent[], limit = 10): MostKilled[] {
  const counts = new Map<string, MostKilled>();
  for (const d of deaths) {
    if (!d.is_pvp) continue;
    if (d.killer_name === d.character_name) continue;
    const existing = counts.get(d.character_name);
    if (existing) {
      existing.deaths++;
    } else {
      counts.set(d.character_name, {
        name: d.character_name,
        vocation: d.character_vocation,
        level: d.character_level,
        side: d.character_side,
        deaths: 1,
      });
    }
  }
  return Array.from(counts.values()).sort((a, b) => b.deaths - a.deaths).slice(0, limit);
}

// ----- Canonical War Events (from database view) -----

export interface CanonicalWarScore {
  confirmedFriendly: number;
  inferredFriendly: number;
  confirmedEnemy: number;
  inferredEnemy: number;
  totalFriendly: number;
  totalEnemy: number;
  sameAlliance: number;
  pve: number;
  unknown: number;
  totalEvents: number;
  ratio: number;
}

export async function getCanonicalWarEvents(limit = 2000): Promise<CanonicalWarEvent[]> {
  return fetchData<CanonicalWarEvent[]>('war-events', { limit });
}

export async function getCanonicalWarEventsFiltered(
  filters: {
    attribution?: Attribution;
    warCategory?: WarCategory;
    side?: WarSide;
    isPvp?: boolean;
    since?: string;
    until?: string;
    search?: string;
  },
  limit = 2000,
): Promise<CanonicalWarEvent[]> {
  return fetchData<CanonicalWarEvent[]>('war-events', {
    ...filters,
    limit,
  });
}

export function computeCanonicalWarScore(events: CanonicalWarEvent[]): CanonicalWarScore {
  let confirmedFriendly = 0;
  let inferredFriendly = 0;
  let confirmedEnemy = 0;
  let inferredEnemy = 0;
  let sameAlliance = 0;
  let pve = 0;
  let unknown = 0;

  for (const e of events) {
    switch (e.war_category) {
      case 'friendly_kills_enemy': confirmedFriendly++; break;
      case 'friendly_kills_enemy_inferred': inferredFriendly++; break;
      case 'enemy_kills_friendly': confirmedEnemy++; break;
      case 'enemy_kills_friendly_inferred': inferredEnemy++; break;
      case 'same_alliance': sameAlliance++; break;
      case 'pve': pve++; break;
      default: unknown++; break;
    }
  }

  const totalFriendly = confirmedFriendly + inferredFriendly;
  const totalEnemy = confirmedEnemy + inferredEnemy;
  const ratio = totalEnemy > 0 ? totalFriendly / totalEnemy : totalFriendly > 0 ? totalFriendly : 0;

  return {
    confirmedFriendly,
    inferredFriendly,
    confirmedEnemy,
    inferredEnemy,
    totalFriendly,
    totalEnemy,
    sameAlliance,
    pve,
    unknown,
    totalEvents: events.length,
    ratio,
  };
}

export function buildCanonicalDailySeries(events: CanonicalWarEvent[], days = 7): DailyDeathPoint[] {
  const now = new Date();
  const buckets: DailyDeathPoint[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const key = dayKey(d);
    buckets.push({
      date: key,
      label: d.toLocaleDateString('en-US', { weekday: 'short', day: 'numeric' }),
      friendlyKills: 0,
      enemyKills: 0,
      friendlyDeaths: 0,
      enemyDeaths: 0,
    });
  }
  const map = new Map(buckets.map((b) => [b.date, b]));
  for (const e of events) {
    const key = dayKey(e.death_time);
    const bucket = map.get(key);
    if (!bucket) continue;
    if (e.war_category === 'friendly_kills_enemy' || e.war_category === 'friendly_kills_enemy_inferred') bucket.friendlyKills++;
    if (e.war_category === 'enemy_kills_friendly' || e.war_category === 'enemy_kills_friendly_inferred') bucket.enemyKills++;
    if (isFriendlySide(e.character_side)) bucket.friendlyDeaths++;
    if (isEnemySide(e.character_side)) bucket.enemyDeaths++;
  }
  return buckets;
}

export interface OnlineSummary {
  everlastOnline: number;
  everlastTotal: number;
  allyOnline: number;
  allyTotal: number;
  friendlyOnline: number;
  friendlyTotal: number;
  enemyOnline: number;
  enemyTotal: number;
  everlastMembers: Character[];
  allyMembers: Character[];
  enemyMembers: Character[];
}

export async function getOnlineSummary(): Promise<OnlineSummary> {
  const [everlast, ally, enemy] = await Promise.all([
    getCharactersBySide('everlast'),
    getCharactersBySide('ally'),
    getCharactersBySide('enemy'),
  ]);
  const everlastOnline = everlast.filter((c) => c.online).length;
  const allyOnline = ally.filter((c) => c.online).length;
  const enemyOnline = enemy.filter((c) => c.online).length;
  return {
    everlastOnline,
    everlastTotal: everlast.length,
    allyOnline,
    allyTotal: ally.length,
    friendlyOnline: everlastOnline + allyOnline,
    friendlyTotal: everlast.length + ally.length,
    enemyOnline,
    enemyTotal: enemy.length,
    everlastMembers: everlast,
    allyMembers: ally,
    enemyMembers: enemy,
  };
}

export { GUILD_EVERLAST, GUILD_ALLY, GUILD_ENEMY };

// ----- Level Events -----
export async function getRecentLevelUps(limit = 20): Promise<LevelEvent[]> {
  return fetchData<LevelEvent[]>('recent-level-ups', { limit });
}

export async function getRecentLevelDowns(limit = 20): Promise<LevelEvent[]> {
  return fetchData<LevelEvent[]>('recent-level-downs', { limit });
}

export async function getLevelEventsForCharacter(characterName: string, limit = 50): Promise<LevelEvent[]> {
  return fetchData<LevelEvent[]>('level-events-for-character', { name: characterName, limit });
}

export interface LevelLeaderboardEntry {
  name: string;
  side: WarSide;
  totalGain: number;
  events: number;
  maxJump: number;
}

export async function getLevelGuildLeaderboard(
  side: WarSide,
  days = 7,
  limit = 15,
): Promise<LevelLeaderboardEntry[]> {
  const rows = await fetchData<{ character_name: string; level_diff: number; char_name: string | null; char_side: WarSide | null }[]>(
    'level-guild-leaderboard',
    { days },
  );

  let charSides: WarSide[];
  if (side === 'everlast' || side === 'ally' || side === 'enemy') {
    charSides = [side];
  } else {
    charSides = ['everlast', 'ally'];
  }

  const map = new Map<string, LevelLeaderboardEntry>();
  for (const row of Array.isArray(rows) ? rows : []) {
    const charSide = row.char_side as WarSide | null;
    if (!charSide || !charSides.includes(charSide)) continue;
    const existing = map.get(row.character_name);
    if (existing) {
      existing.totalGain += row.level_diff;
      existing.events++;
      if (row.level_diff > existing.maxJump) existing.maxJump = row.level_diff;
    } else {
      map.set(row.character_name, {
        name: row.character_name,
        side: charSide,
        totalGain: row.level_diff,
        events: 1,
        maxJump: row.level_diff,
      });
    }
  }
  return Array.from(map.values())
    .sort((a, b) => b.totalGain - a.totalGain)
    .slice(0, limit);
}

/**
 * All level events (ups + downs) since a given time, enriched with guild side.
 * Note: Supabase caps each RPC response at ~1000 rows, so very busy windows are truncated
 * to the most recent events per direction.
 */
export async function getLevelEventsSince(since: string, limit = 1000): Promise<LevelEvent[]> {
  return fetchData<LevelEvent[]>('recent-level-events', { direction: 'all', since, limit });
}


export async function getTeamWarCalls(): Promise<TeamWarCall[]> {
  return fetchData<TeamWarCall[]>('team-war-calls');
}

export async function getTeamWarCallResponses(warCallId: string): Promise<TeamWarCallResponse[]> {
  return fetchData<TeamWarCallResponse[]>('team-war-call-responses', { warCallId });
}

export async function getRetroFragGuardEntries(): Promise<RetroFragGuardEntry[]> {
  return fetchData<RetroFragGuardEntry[]>('retro-frag-guard');
}

export async function getRetroObservedLastHits(): Promise<RetroObservedLastHits[]> {
  return fetchData<RetroObservedLastHits[]>('retro-observed-last-hits');
}

export async function getActiveTeamWarCall(): Promise<TeamWarCall | null> {
  return fetchData<TeamWarCall | null>('active-team-war-call');
}

export async function getTeamSupplyChecklists(warCallId: string): Promise<TeamSupplyChecklist[]> {
  return fetchData<TeamSupplyChecklist[]>('team-supplies', { warCallId });
}
export async function getAfterBattleReport(warCallId: string): Promise<AfterBattleReport> {
  return fetchData<AfterBattleReport>('after-battle-report', { warCallId });
}
