'use client';

import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from './supabase';

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  loading: boolean;
  /** Shared-password access (candy gate) */
  candyUnlocked: boolean;
  candyChecking: boolean;
  checkCandyAccess: () => Promise<void>;
  lockCandy: () => Promise<void>;
  /** Per-user Supabase auth (for watchlist) */
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [candyUnlocked, setCandyUnlocked] = useState(false);
  const [candyChecking, setCandyChecking] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setUser(data.session?.user ?? null);
      setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
      setUser(newSession?.user ?? null);
      setLoading(false);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  // Check shared-password session
  const checkCandyAccess = useCallback(async () => {
    setCandyChecking(true);
    try {
      const res = await fetch('/api/auth/verify', { credentials: 'same-origin' });
      const data = await res.json();
      setCandyUnlocked(data.authenticated === true);
    } catch {
      setCandyUnlocked(false);
    } finally {
      setCandyChecking(false);
    }
  }, []);

  const lockCandy = useCallback(async () => {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'same-origin' });
    setCandyUnlocked(false);
    window.location.href = '/unlock';
  }, []);

  useEffect(() => {
    checkCandyAccess();
  }, [checkCandyAccess]);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error?.message ?? null };
  };

  const signUp = async (email: string, password: string) => {
    const { error } = await supabase.auth.signUp({ email, password });
    return { error: error?.message ?? null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <AuthContext.Provider value={{ session, user, loading, candyUnlocked, candyChecking, checkCandyAccess, lockCandy, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
