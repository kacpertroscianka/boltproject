'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import type { CanonicalWarEvent, LevelEvent, WarSide } from './types';
import { isFriendlySide, isEnemySide, GUILD_ENEMY } from './tibia';
import { fetchData } from './api-client';
import {
  type AlertSettings,
  type AlertHistoryEntry,
  type AlertEventType,
  type AlertGuild,
  loadSettings,
  saveSettings,
  loadAlertHistory,
  saveAlertHistory,
  loadCursor,
  saveCursor,
  EVENT_TYPE_LABELS,
  type SoundType,
} from './alert-types';

const POLL_INTERVAL = 8000;
const CHANNEL_NAME = 'candy-alerts';
const MAX_CONCURRENT_SOUNDS = 1;

interface RawDeathEvent {
  id: string;
  event_id?: string;
  character_name: string;
  character_level: number;
  character_side: WarSide;
  killer_name: string | null;
  killer_side: WarSide | null;
  is_pvp: boolean;
  is_player_kill: boolean;
  death_time: string;
  created_at: string;
  updated_at: string;
  war_category?: string;
  killers?: { name: string; player: boolean }[] | null;
  assists?: { name: string; player: boolean }[] | null;
  participated_players?: string[] | null;
  cause?: string;
  reason?: string;
}

interface RawLevelEvent {
  id: string;
  character_name: string;
  character_id: string | null;
  previous_level: number | null;
  new_level: number | null;
  level_diff: number;
  observed_at: string;
  character_side?: WarSide;
  character_guild_name?: string | null;
  character_vocation?: string | null;
}

interface ClassifiedAlert {
  type: AlertEventType;
  characterName: string;
  side: WarSide | null;
  guild: string | null;
  level: number | null;
  title: string;
  message: string;
  detailHref: string | null;
  eventTime: string;
  eventId: string;
  soundType: SoundType;
}

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (audioCtx) return audioCtx;
  try {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    audioCtx = new Ctor();
    return audioCtx;
  } catch {
    return null;
  }
}

export async function unlockAudio(): Promise<boolean> {
  const ctx = getAudioContext();
  if (!ctx) return false;
  try {
    if (ctx.state === 'suspended') await ctx.resume();
    return ctx.state === 'running';
  } catch {
    return false;
  }
}

function playTone(freq: number, duration: number, type: OscillatorType, volume: number, when = 0): void {
  const ctx = getAudioContext();
  if (!ctx) return;
  try {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.value = 0;
    const start = ctx.currentTime + when;
    gain.gain.setValueAtTime(0, start);
    gain.gain.linearRampToValueAtTime(volume, start + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, start + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(start);
    osc.stop(start + duration + 0.05);
  } catch {}
}

export function playSound(type: SoundType, volume: number): void {
  const v = Math.max(0, Math.min(1, volume));
  if (v === 0) return;
  const ctx = getAudioContext();
  if (!ctx) return;
  if (ctx.state === 'suspended') {
    void ctx.resume().then(() => playSound(type, volume)).catch(() => {});
    return;
  }
  switch (type) {
    case 'enemy_death':
      playTone(220, 0.15, 'sawtooth', v * 0.4);
      playTone(165, 0.25, 'sawtooth', v * 0.3, 0.1);
      break;
    case 'friendly_death':
      playTone(440, 0.2, 'sine', v * 0.25);
      playTone(330, 0.3, 'sine', v * 0.2, 0.15);
      break;
    case 'friendly_kill':
      playTone(523, 0.1, 'square', v * 0.3);
      playTone(659, 0.1, 'square', v * 0.3, 0.08);
      playTone(784, 0.2, 'square', v * 0.35, 0.16);
      break;
    case 'enemy_kill':
      playTone(196, 0.12, 'sawtooth', v * 0.35);
      playTone(147, 0.2, 'sawtooth', v * 0.3, 0.1);
      break;
    case 'level_up':
      playTone(523, 0.08, 'triangle', v * 0.25);
      playTone(659, 0.08, 'triangle', v * 0.25, 0.06);
      playTone(784, 0.08, 'triangle', v * 0.25, 0.12);
      playTone(1047, 0.2, 'triangle', v * 0.3, 0.18);
      break;
    case 'level_down':
      playTone(440, 0.1, 'sine', v * 0.25);
      playTone(349, 0.12, 'sine', v * 0.22, 0.1);
      playTone(294, 0.25, 'sine', v * 0.2, 0.22);
      break;
  }
}

function classifyWarEvent(
  event: RawDeathEvent,
  scoringMode: 'last-hit' | 'participation',
): ClassifiedAlert | null {
  const victimSide = event.character_side;
  const killerSide = event.killer_side;
  const isPvp = event.is_pvp && event.is_player_kill;

  // Enemy death (PvP or PvE)
  if (isEnemySide(victimSide)) {
    if (isPvp) {
      // Check if it was a friendly kill
      if (isFriendlySide(killerSide)) {
        if (scoringMode === 'participation') {
          // Check if friendly alliance participated (not just last hit)
          const participants = event.participated_players ?? [];
          const allKillers = (event.killers ?? []).filter((k) => k.player).map((k) => k.name);
          const allAssists = (event.assists ?? []).filter((a) => a.player).map((a) => a.name);
          const hasFriendly = [...allKillers, ...allAssists, ...participants].length > 0 && isFriendlySide(killerSide);
          if (hasFriendly) {
            return makeAlert('friendly_kills_enemy_participation', event, '💜 TERRORY STRIKE!', `${event.killer_name || 'Alliance'} uczestniczyło w zabiciu ${event.character_name}!`, 'friendly_kill');
          }
        }
        return makeAlert('friendly_kills_enemy', event, '💚 EVERLAST KILL!', `${event.killer_name || 'Alliance'} zabił ${event.character_name} z ${GUILD_ENEMY}!`, 'friendly_kill');
      }
      return makeAlert('enemy_death_pvp', event, '💀 ENEMY DOWN!', `${event.character_name} z ${GUILD_ENEMY} zginął na levelu ${event.character_level}!`, 'enemy_death');
    }
    return makeAlert('enemy_death_pve', event, '💀 ENEMY DOWN!', `${event.character_name} z ${GUILD_ENEMY} zginął (PvE) na levelu ${event.character_level}!`, 'enemy_death');
  }

  // Friendly death
  if (isFriendlySide(victimSide)) {
    if (isPvp && isEnemySide(killerSide)) {
      return makeAlert('enemy_kills_friendly', event, '🩸 ENEMY STRIKE!', `${event.killer_name || 'Enemy'} zabił ${event.character_name}!`, 'enemy_kill');
    }
    return makeAlert('friendly_death', event, '💔 ALLIANCE MEMBER DOWN!', `${event.character_name} właśnie zginął!`, 'friendly_death');
  }

  return null;
}

function makeAlert(
  type: AlertEventType,
  event: RawDeathEvent,
  title: string,
  message: string,
  soundType: SoundType,
): ClassifiedAlert {
  return {
    type,
    characterName: event.character_name,
    side: event.character_side,
    guild: null,
    level: event.character_level,
    title,
    message,
    detailHref: `/character/${encodeURIComponent(event.character_name)}`,
    eventTime: event.death_time,
    eventId: event.event_id || event.id,
    soundType,
  };
}

function classifyLevelEvent(event: RawLevelEvent): ClassifiedAlert | null {
  if (event.level_diff === 0) return null;
  const isUp = event.level_diff > 0;
  const side = event.character_side ?? null;

  if (side && isEnemySide(side)) {
    if (isUp) {
      return {
        type: 'enemy_level_up',
        characterName: event.character_name,
        side,
        guild: GUILD_ENEMY,
        title: '⭐ ENEMY LEVEL UP!',
        message: `${event.character_name} z ${GUILD_ENEMY}: ${event.previous_level} → ${event.new_level}!`,
        detailHref: `/character/${encodeURIComponent(event.character_name)}`,
        eventTime: event.observed_at,
        eventId: event.id,
        soundType: 'level_up',
        level: event.new_level ?? null,
      };
    }
    return {
      type: 'enemy_level_down',
      characterName: event.character_name,
      side,
      guild: GUILD_ENEMY,
      title: '📉 ENEMY LEVEL DOWN!',
      message: `${event.character_name} z ${GUILD_ENEMY}: ${event.previous_level} → ${event.new_level}!`,
      detailHref: `/character/${encodeURIComponent(event.character_name)}`,
      eventTime: event.observed_at,
      eventId: event.id,
      soundType: 'level_down',
      level: event.new_level ?? null,
    };
  }

  if (side && isFriendlySide(side)) {
    if (isUp) {
      return {
        type: 'friendly_level_up',
        characterName: event.character_name,
        side,
        guild: side === 'everlast' ? 'Everlast' : 'Terrory',
        title: '🎉 LEVEL UP!',
        message: `${event.character_name}: ${event.previous_level} → ${event.new_level}!`,
        detailHref: `/character/${encodeURIComponent(event.character_name)}`,
        eventTime: event.observed_at,
        eventId: event.id,
        soundType: 'level_up',
        level: event.new_level ?? null,
      };
    }
    return {
      type: 'friendly_level_down',
      characterName: event.character_name,
      side,
      guild: side === 'everlast' ? 'Everlast' : 'Terrory',
      title: '📉 LEVEL DOWN!',
      message: `${event.character_name}: ${event.previous_level} → ${event.new_level}!`,
      detailHref: `/character/${encodeURIComponent(event.character_name)}`,
      eventTime: event.observed_at,
      eventId: event.id,
      soundType: 'level_down',
      level: event.new_level ?? null,
    };
  }

  return null;
}

function shouldNotify(
  alert: ClassifiedAlert,
  settings: AlertSettings,
): boolean {
  if (!settings.enabled) return false;
  if (settings.mutedUntil && Date.now() < settings.mutedUntil) return false;
  if (settings.minLevel > 0) {
    const level = alert.level ?? 0;
    if (level < settings.minLevel) return false;
  }

  // Guild filter
  const guildMap: Record<AlertGuild, boolean> = settings.guildFilters;
  if (alert.side === 'everlast' && !guildMap.everlast) return false;
  if (alert.side === 'ally' && !guildMap.ally) return false;
  if (alert.side === 'enemy' && !guildMap.enemy) return false;

  // Event filter
  if (!settings.eventFilters[alert.type]) return false;

  return true;
}

export interface UseAlertEngine {
  settings: AlertSettings;
  updateSettings: (partial: Partial<AlertSettings>) => void;
  history: AlertHistoryEntry[];
  clearHistory: () => void;
  markAllRead: () => void;
  notificationPermission: NotificationPermission | 'unsupported';
  requestNotificationPermission: () => Promise<boolean>;
  testNotification: () => void;
  testSound: (type: SoundType) => void;
  audioStatus: 'enabled' | 'blocked' | 'muted';
  isPolling: boolean;
  lastPollAt: number | null;
  unreadCount: number;
}

export function useAlertEngine(allowPolling = true): UseAlertEngine {
  const [settings, setSettings] = useState<AlertSettings>(DEFAULT_ALERT_SETTINGS_PERSISTED);
  const allowedRef = useRef(allowPolling);
  useEffect(() => { allowedRef.current = allowPolling; }, [allowPolling]);
  const [history, setHistory] = useState<AlertHistoryEntry[]>([]);
  const [isPolling, setIsPolling] = useState(false);
  const [lastPollAt, setLastPollAt] = useState<number | null>(null);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission | 'unsupported'>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'unsupported',
  );
  const [unreadCount, setUnreadCount] = useState(0);
  const [audioStatus, setAudioStatus] = useState<'enabled' | 'blocked' | 'muted'>('muted');

  const channelRef = useRef<BroadcastChannel | null>(null);
  const settingsRef = useRef(settings);
  const historyRef = useRef(history);
  const cursorRef = useRef<string | null>(null);
  const deliveredRef = useRef<Set<string>>(new Set());
  const lastSoundAt = useRef<number>(0);
  const initializedRef = useRef(false);
  const inFlightRef = useRef(false);

  useEffect(() => { settingsRef.current = settings; }, [settings]);
  useEffect(() => { historyRef.current = history; }, [history]);

  // Load from localStorage on mount
  useEffect(() => {
    const s = loadSettings();
    setSettings(s);
    const h = loadAlertHistory();
    setHistory(h);
    const c = loadCursor();
    cursorRef.current = c;
    // Populate delivered set from history to avoid re-notifying
    for (const entry of h) {
      deliveredRef.current.add(entry.eventId);
    }
  }, []);

  // Save settings when they change
  const updateSettings = useCallback((partial: Partial<AlertSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...partial };
      saveSettings(next);
      settingsRef.current = next;
      return next;
    });
  }, []);

  // BroadcastChannel for multi-tab coordination
  useEffect(() => {
    if (typeof window === 'undefined') return;
    let ch: BroadcastChannel | null = null;
    try {
      ch = new BroadcastChannel(CHANNEL_NAME);
      ch.onmessage = (ev: { data: unknown }) => {
        const data = ev.data as { type: string; eventId?: string; alert?: AlertHistoryEntry };
        if (data.type === 'alert-delivered' && data.eventId) {
          deliveredRef.current.add(data.eventId);
        }
        if (data.type === 'alert-history' && data.alert) {
          setHistory((prev) => {
            if (prev.some((h) => h.eventId === data.alert!.eventId)) return prev;
            const next = [data.alert!, ...prev].slice(0, 200);
            saveAlertHistory(next);
            return next;
          });
        }
      };
      channelRef.current = ch;
    } catch {
      channelRef.current = null;
    }
    return () => {
      ch?.close();
    };
  }, []);

  const addToHistory = useCallback((alert: ClassifiedAlert, detectedAt: string) => {
    const entry: AlertHistoryEntry = {
      id: `${alert.eventId}-${Date.now()}`,
      eventId: alert.eventId,
      type: alert.type,
      characterName: alert.characterName,
      guild: alert.guild,
      side: alert.side,
      title: alert.title,
      message: alert.message,
      detailHref: alert.detailHref,
      eventTime: alert.eventTime,
      detectedAt,
      read: false,
    };
    setHistory((prev) => {
      if (prev.some((h) => h.eventId === entry.eventId)) return prev;
      const next = [entry, ...prev].slice(0, 200);
      saveAlertHistory(next);
      return next;
    });
    // Broadcast to other tabs
    channelRef.current?.postMessage({ type: 'alert-history', alert: entry });
    channelRef.current?.postMessage({ type: 'alert-delivered', eventId: entry.eventId });
  }, []);

  const deliverAlert = useCallback((alert: ClassifiedAlert) => {
    if (deliveredRef.current.has(alert.eventId)) return;
    deliveredRef.current.add(alert.eventId);

    const s = settingsRef.current;
    if (!shouldNotify(alert, s)) return;

    const detectedAt = new Date().toISOString();
    addToHistory(alert, detectedAt);

    const isBackground = document.visibilityState === 'hidden';
    const showInForeground = s.notifyInForeground && !isBackground;
    const showInBackground = s.notifyInBackground && isBackground;

    if (showInForeground || showInBackground) {
      // In-app toast via custom event
      window.dispatchEvent(new CustomEvent('candy-alert', { detail: alert }));

      // Browser notification for background
      if (showInBackground && 'Notification' in window && Notification.permission === 'granted') {
        try {
          const notif = new Notification(alert.title, {
            body: alert.message,
            tag: alert.eventId,
            icon: '/favicon.ico',
          });
          notif.onclick = () => {
            window.focus();
            if (alert.detailHref) {
              window.location.href = alert.detailHref;
            }
            notif.close();
          };
        } catch {}
      }
    }

    // Sound
    if (s.soundsEnabled) {
      const now = Date.now();
      if (now - lastSoundAt.current > 500) {
        lastSoundAt.current = now;
        playSound(alert.soundType, s.volume);
      }
    }
  }, [addToHistory]);

  const pollOnce = useCallback(async () => {
    const s = settingsRef.current;
    if (!s.enabled || !allowedRef.current) return;

    if (inFlightRef.current) return;
    inFlightRef.current = true;
    setIsPolling(true);
    try {
      const cursor = cursorRef.current;
      // Small overlap covers events with identical timestamps and eventual consistency.
      // deliveredRef + persisted history suppress duplicate delivery.
      const sinceParam = cursor ? new Date(Math.max(0, Date.parse(cursor) - 90_000)).toISOString()
        : new Date(Date.now() - 5 * 60 * 1000).toISOString();

      // Fetch recent deaths and level events since cursor
      const [deaths, levelEvents] = await Promise.all([
        fetchData<RawDeathEvent[]>('recent-deaths-since', { since: sinceParam, limit: 100 }),
        fetchData<RawLevelEvent[]>('recent-level-events', { since: sinceParam, limit: 100 }),
      ]);

      let latestTime = cursor ? new Date(cursor).getTime() : 0;

      // Process deaths
      for (const death of deaths ?? []) {
        const alert = classifyWarEvent(death, s.scoringMode);
        if (alert) {
          deliverAlert(alert);
        }
        const dt = new Date(death.death_time).getTime();
        if (dt > latestTime) latestTime = dt;
      }

      // Process level events
      for (const level of levelEvents ?? []) {
        const alert = classifyLevelEvent(level);
        if (alert) {
          deliverAlert(alert);
        }
        const dt = new Date(level.observed_at).getTime();
        if (dt > latestTime) latestTime = dt;
      }

      // Update cursor
      if (latestTime > 0) {
        const newCursor = new Date(latestTime + 1).toISOString();
        cursorRef.current = newCursor;
        saveCursor(newCursor);
      }

      setLastPollAt(Date.now());
    } catch (err) {
      // Silently fail — will retry next interval
      if (err instanceof Error && err.message === 'Unauthorized') {
        // Session expired — stop polling
        updateSettings({ enabled: false });
      }
    } finally {
      inFlightRef.current = false;
      setIsPolling(false);
    }
  }, [deliverAlert, updateSettings]);

  // Initialize cursor on first enable
  useEffect(() => {
    if (!settings.enabled || !allowPolling || initializedRef.current) return;
    initializedRef.current = true;
    // Set cursor to now so we don't replay historical events
    if (!cursorRef.current) {
      const now = new Date().toISOString();
      cursorRef.current = now;
      saveCursor(now);
    }
    // Do an immediate poll
    pollOnce();
  }, [settings.enabled, allowPolling, pollOnce]);

  // Polling interval
  useEffect(() => {
    if (!settings.enabled || !allowPolling) return;
    const interval = setInterval(pollOnce, POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [settings.enabled, allowPolling, pollOnce]);

  // Handle tab resume — poll immediately after returning from background
  useEffect(() => {
    if (!settings.enabled || !allowPolling) return;
    const onVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        pollOnce();
      }
    };
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => document.removeEventListener('visibilitychange', onVisibilityChange);
  }, [settings.enabled, allowPolling, pollOnce]);

  // Update unread count
  useEffect(() => {
    setUnreadCount(history.filter((h) => !h.read).length);
  }, [history]);

  const clearHistory = useCallback(() => {
    setHistory([]);
    saveAlertHistory([]);
  }, []);

  const markAllRead = useCallback(() => {
    setHistory((prev) => {
      const next = prev.map((h) => ({ ...h, read: true }));
      saveAlertHistory(next);
      return next;
    });
  }, []);

  const requestNotificationPermission = useCallback(async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setNotificationPermission('unsupported');
      return false;
    }
    try {
      const result = await Notification.requestPermission();
      setNotificationPermission(result);
      return result === 'granted';
    } catch {
      return false;
    }
  }, []);

  const testNotification = useCallback(() => {
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    if (Notification.permission === 'granted') {
      try {
        const n = new Notification('🍬 Candy Test Alert!', {
          body: 'Powiadomienia działają! Candy War Room jest gotowy.',
          icon: '/favicon.ico',
        });
        setTimeout(() => n.close(), 5000);
      } catch {}
    }
    // Also show in-app toast
    window.dispatchEvent(new CustomEvent('candy-alert', {
      detail: {
        type: 'friendly_level_up',
        title: '🍬 Candy Test Alert!',
        message: 'Powiadomienia działają! Candy War Room jest gotowy.',
        detailHref: null,
        soundType: 'level_up',
      },
    }));
  }, []);

  const testSound = useCallback((type: SoundType) => {
    if (settingsRef.current.volume <= 0 || !settingsRef.current.soundsEnabled) {
      setAudioStatus('muted');
      return;
    }
    void unlockAudio().then((ready) => {
      if (!ready) {
        setAudioStatus('blocked');
        return;
      }
      setAudioStatus('enabled');
      playSound(type, settingsRef.current.volume);
    });
  }, []);

  return {
    settings,
    updateSettings,
    history,
    clearHistory,
    markAllRead,
    notificationPermission,
    requestNotificationPermission,
    testNotification,
    testSound,
    isPolling,
    lastPollAt,
    unreadCount,
    audioStatus: settings.soundsEnabled && settings.volume > 0 ? audioStatus : 'muted',
  };
}

// Lazy-loaded default
const DEFAULT_ALERT_SETTINGS_PERSISTED: AlertSettings = {
  enabled: false,
  soundsEnabled: false,
  volume: 0.5,
  notifyInForeground: true,
  notifyInBackground: true,
  guildFilters: { everlast: true, ally: true, enemy: true },
  eventFilters: {
    enemy_death_pvp: true,
    enemy_death_pve: true,
    enemy_level_up: true,
    enemy_level_down: true,
    enemy_kills_friendly: true,
    friendly_death: true,
    friendly_level_up: true,
    friendly_level_down: true,
    friendly_kills_enemy: true,
    friendly_kills_enemy_participation: false,
  },
  soundPerEvent: {},
  scoringMode: 'last-hit',
  minLevel: 0,
  cooldownMs: 0,
  mutedUntil: null,
};
