import { cookies } from 'next/headers';
import crypto from 'crypto';

const COOKIE_NAME = 'candy_session';
const SESSION_DURATION_MS = 24 * 60 * 60 * 1000; // 24 hours

function getSecret(): string {
  const secret = process.env.CANDY_SESSION_SECRET;
  if (!secret || secret.length < 32) {
    throw new Error('CANDY_SESSION_SECRET missing or too short');
  }
  return secret;
}

function getPasswordHash(): string {
  const hash = process.env.CANDY_PASSWORD_HASH;
  if (!hash) {
    throw new Error('CANDY_PASSWORD_HASH missing');
  }
  return hash;
}

export function isAuthConfigured(): boolean {
  return !!(process.env.CANDY_PASSWORD_HASH && process.env.CANDY_SESSION_SECRET);
}

export function verifyPassword(password: string): boolean {
  try {
    const stored = getPasswordHash();
    const parts = stored.split(':');
    if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
    const salt = parts[1];
    const expectedHash = parts[2];
    const computedHash = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(
      Buffer.from(computedHash, 'hex'),
      Buffer.from(expectedHash, 'hex'),
    );
  } catch {
    return false;
  }
}

export function createSessionToken(): string {
  const secret = getSecret();
  const now = Date.now();
  const payload = JSON.stringify({ iat: now, exp: now + SESSION_DURATION_MS });
  const payloadB64 = Buffer.from(payload, 'utf8').toString('base64url');
  const hmac = crypto.createHmac('sha256', secret).update(payloadB64).digest('base64url');
  return `${payloadB64}.${hmac}`;
}

export function verifySessionToken(token: string | undefined | null): boolean {
  if (!token) return false;
  try {
    const secret = getSecret();
    const [payloadB64, hmac] = token.split('.');
    if (!payloadB64 || !hmac) return false;
    const expectedHmac = crypto.createHmac('sha256', secret).update(payloadB64).digest('base64url');
    if (hmac.length !== expectedHmac.length) return false;
    if (!crypto.timingSafeEqual(Buffer.from(hmac), Buffer.from(expectedHmac))) {
      return false;
    }
    const payload = JSON.parse(Buffer.from(payloadB64, 'base64url').toString('utf8'));
    if (typeof payload.exp !== 'number') return false;
    return Date.now() < payload.exp;
  } catch {
    return false;
  }
}

export function isAuthenticated(): boolean {
  try {
    const name = getCookieName();
    const token = cookies().get(name)?.value ?? cookies().get(COOKIE_NAME)?.value;
    return verifySessionToken(token);
  } catch {
    return false;
  }
}

/**
 * Determine if we're in a local dev environment where secure cookies
 * must be relaxed (HTTP localhost). Production/preview uses HTTPS.
 */
function isLocalDev(): boolean {
  const nodeEnv = process.env.NODE_ENV;
  const vercelEnv = process.env.CONTEXT; // Netlify context
  if (nodeEnv === 'development') return true;
  if (vercelEnv && vercelEnv !== 'production') return true;
  return false;
}

export function getCookieOptions() {
  return {
    name: COOKIE_NAME,
    httpOnly: true,
    secure: !isLocalDev(),
    sameSite: 'lax' as const,
    path: '/',
    maxAge: SESSION_DURATION_MS / 1000,
  };
}

export function getCookieName(): string {
  return COOKIE_NAME;
}

export { COOKIE_NAME, SESSION_DURATION_MS };
