import type { WarSide } from './types';

export type AlertEventType =
  | 'enemy_death_pvp'
  | 'enemy_death_pve'
  | 'enemy_level_up'
  | 'enemy_level_down'
  | 'enemy_kills_friendly'
  | 'friendly_death'
  | 'friendly_level_up'
  | 'friendly_level_down'
  | 'friendly_kills_enemy'
  | 'friendly_kills_enemy_participation';

export type AlertGuild = 'everlast' | 'ally' | 'enemy';

export type AlertScoringMode = 'last-hit' | 'participation';

export interface AlertSettings {
  enabled: boolean;
  soundsEnabled: boolean;
  volume: number; // 0..1
  notifyInForeground: boolean;
  notifyInBackground: boolean;
  guildFilters: Record<AlertGuild, boolean>;
  eventFilters: Record<AlertEventType, boolean>;
  soundPerEvent: Partial<Record<AlertEventType, string>>;
  scoringMode: AlertScoringMode;
  minLevel: number;
  cooldownMs: number;
  mutedUntil: number | null;
}

export const DEFAULT_ALERT_SETTINGS: AlertSettings = {
  enabled: false,
  soundsEnabled: false,
  volume: 0.5,
  notifyInForeground: true,
  notifyInBackground: true,
  guildFilters: { everlast: true, ally: true, enemy: true },
  eventFilters: {
    enemy_death_pvp: true,
    enemy_death_pve: true,
    enemy_level_up: true,
    enemy_level_down: true,
    enemy_kills_friendly: true,
    friendly_death: true,
    friendly_level_up: true,
    friendly_level_down: true,
    friendly_kills_enemy: true,
    friendly_kills_enemy_participation: false,
  },
  soundPerEvent: {},
  scoringMode: 'last-hit',
  minLevel: 0,
  cooldownMs: 0,
  mutedUntil: null,
};

const STORAGE_KEY = 'candy-alert-settings';
const HISTORY_KEY = 'candy-alert-history';
const CURSOR_KEY = 'candy-alert-cursor';

export function loadSettings(): AlertSettings {
  if (typeof window === 'undefined') return DEFAULT_ALERT_SETTINGS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_ALERT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<AlertSettings>;
    // Older releases might not have every filter or sound setting.
    // Deep-merge without resetting the user's explicit saved choices.
    return {
      ...DEFAULT_ALERT_SETTINGS,
      ...parsed,
      guildFilters: { ...DEFAULT_ALERT_SETTINGS.guildFilters, ...parsed.guildFilters },
      eventFilters: { ...DEFAULT_ALERT_SETTINGS.eventFilters, ...parsed.eventFilters },
      soundPerEvent: { ...DEFAULT_ALERT_SETTINGS.soundPerEvent, ...parsed.soundPerEvent },
    };
  } catch {
    return DEFAULT_ALERT_SETTINGS;
  }
}

export function saveSettings(settings: AlertSettings): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {}
}

export interface AlertHistoryEntry {
  id: string;
  eventId: string;
  type: AlertEventType;
  characterName: string;
  guild: string | null;
  side: WarSide | null;
  title: string;
  message: string;
  detailHref: string | null;
  eventTime: string;
  detectedAt: string;
  read: boolean;
}

export function loadAlertHistory(): AlertHistoryEntry[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as AlertHistoryEntry[];
  } catch {
    return [];
  }
}

export function saveAlertHistory(history: AlertHistoryEntry[]): void {
  if (typeof window === 'undefined') return;
  try {
    // Cap at 200 entries
    const capped = history.slice(0, 200);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(capped));
  } catch {}
}

export function loadCursor(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    return localStorage.getItem(CURSOR_KEY);
  } catch {
    return null;
  }
}

export function saveCursor(cursor: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(CURSOR_KEY, cursor);
  } catch {}
}

export const EVENT_TYPE_LABELS: Record<AlertEventType, { label: string; emoji: string }> = {
  enemy_death_pvp: { label: 'Enemy PvP Death', emoji: '💀' },
  enemy_death_pve: { label: 'Enemy PvE Death', emoji: '💀' },
  enemy_level_up: { label: 'Enemy Level Up', emoji: '⭐' },
  enemy_level_down: { label: 'Enemy Level Down', emoji: '📉' },
  enemy_kills_friendly: { label: 'Enemy Kills Friendly', emoji: '🩸' },
  friendly_death: { label: 'Friendly Death', emoji: '💔' },
  friendly_level_up: { label: 'Friendly Level Up', emoji: '🎉' },
  friendly_level_down: { label: 'Friendly Level Down', emoji: '📉' },
  friendly_kills_enemy: { label: 'Friendly Kill (Last Hit)', emoji: '💚' },
  friendly_kills_enemy_participation: { label: 'Friendly Kill (Participation)', emoji: '💜' },
};

export const SOUND_TYPES = [
  'enemy_death',
  'friendly_death',
  'friendly_kill',
  'enemy_kill',
  'level_up',
  'level_down',
] as const;

export type SoundType = (typeof SOUND_TYPES)[number];

export const SOUND_LABELS: Record<SoundType, string> = {
  enemy_death: 'Enemy Death',
  friendly_death: 'Friendly Death',
  friendly_kill: 'Friendly Kill',
  enemy_kill: 'Enemy Kill',
  level_up: 'Level Up',
  level_down: 'Level Down',
};
