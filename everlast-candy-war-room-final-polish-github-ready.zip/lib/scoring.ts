import type { CanonicalWarEvent, WarSide, TibiaKiller } from './types';
import { isFriendlySide, isEnemySide } from './tibia';

export type ScoringMode = 'last-hit' | 'participation' | 'compare';

export const SCORING_MODE_LABELS: Record<ScoringMode, { label: string; emoji: string; short: string }> = {
  'last-hit': { label: 'Last Hit', emoji: '⚔️', short: 'Last Hit' },
  'participation': { label: 'Udział w zabójstwie', emoji: '🤝', short: 'Participation' },
  'compare': { label: 'Porównaj oba', emoji: '🍬', short: 'Compare' },
};

const SCORING_MODE_STORAGE_KEY = 'candy-scoring-mode';

export function getStoredScoringMode(): ScoringMode {
  if (typeof window === 'undefined') return 'last-hit';
  try {
    const stored = localStorage.getItem(SCORING_MODE_STORAGE_KEY);
    if (stored === 'last-hit' || stored === 'participation' || stored === 'compare') {
      return stored;
    }
  } catch {}
  return 'last-hit';
}

export function storeScoringMode(mode: ScoringMode): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(SCORING_MODE_STORAGE_KEY, mode);
  } catch {}
}

/**
 * Build a name→side lookup from war events.
 * Combines stored_killer_side, killer_current_side, and character_side
 * to build the most complete roster mapping possible client-side.
 */
export function buildSideLookup(events: CanonicalWarEvent[]): Map<string, WarSide> {
  const lookup = new Map<string, WarSide>();
  for (const e of events) {
    if (e.character_name) {
      lookup.set(e.character_name, e.character_side);
    }
    if (e.killer_name && e.stored_killer_side) {
      lookup.set(e.killer_name, e.stored_killer_side);
    }
    if (e.killer_name && e.killer_current_side && !lookup.has(e.killer_name)) {
      lookup.set(e.killer_name, e.killer_current_side);
    }
    // Also map from participants and assists
    for (const p of e.participated_players ?? []) {
      if (!lookup.has(p)) {
        if (e.stored_killer_side && isFriendlySide(e.stored_killer_side) && isEnemySide(e.character_side)) {
          lookup.set(p, e.stored_killer_side);
        }
        if (e.stored_killer_side && isEnemySide(e.stored_killer_side) && isFriendlySide(e.character_side)) {
          lookup.set(p, e.stored_killer_side);
        }
      }
    }
  }
  return lookup;
}

/**
 * Get the side of a participant name using the side lookup.
 * Falls back to checking if they appear as a killer with a known side in any event.
 */
function getSideForParticipant(name: string, sideLookup: Map<string, WarSide>): WarSide | null {
  return sideLookup.get(name) ?? null;
}

/**
 * Extract all player names from killers and assists arrays.
 */
function getAllParticipants(event: CanonicalWarEvent): { killers: string[]; assists: string[] } {
  const killerNames: string[] = [];
  for (const k of event.killers ?? []) {
    if (k.player === true && k.name !== event.character_name) {
      killerNames.push(k.name);
    }
  }
  const assistNames: string[] = [];
  for (const a of event.assists ?? []) {
    if (a.player === true && a.name !== event.character_name) {
      assistNames.push(a.name);
    }
  }
  return { killers: killerNames, assists: assistNames };
}

/**
 * Check whether assists data is missing (pre-reimport) vs confirmed absent.
 * The reimported data has source 'tibiadata-v5-reimport' and always populates assists.
 * Older data (source 'tibiadata') may have null assists if the API returned none.
 * We treat null assists array as "data not available" only for pre-reimport sources.
 */
function assistsDataMissing(event: CanonicalWarEvent): boolean {
  if (event.assists !== null && event.assists !== undefined) return false;
  // If assists is null and source indicates old import, data may be missing
  return event.source === 'tibiadata' && event.assist_count === null;
}

// ===== LAST HIT SCORING =====

export interface LastHitScore {
  friendlyKills: number;
  enemyKills: number;
  /** Friendly kills attributed via current-guild inference (stored_side was null) */
  inferredFriendly: number;
  inferredEnemy: number;
  sameAlliance: number;
  unknown: number;
  pve: number;
  total: number;
}

/**
 * Last Hit scoring: counts a kill for the alliance of the credited killer (killers[0]).
 * Uses the war_category from the canonical_war_events view, which is computed server-side.
 */
export function computeLastHitScore(events: CanonicalWarEvent[]): LastHitScore {
  let friendlyKills = 0;
  let enemyKills = 0;
  let inferredFriendly = 0;
  let inferredEnemy = 0;
  let sameAlliance = 0;
  let unknown = 0;
  let pve = 0;

  for (const e of events) {
    switch (e.war_category) {
      case 'friendly_kills_enemy': friendlyKills++; break;
      case 'friendly_kills_enemy_inferred': inferredFriendly++; break;
      case 'enemy_kills_friendly': enemyKills++; break;
      case 'enemy_kills_friendly_inferred': inferredEnemy++; break;
      case 'same_alliance': sameAlliance++; break;
      case 'pve': pve++; break;
      default: unknown++; break;
    }
  }

  return {
    friendlyKills,
    enemyKills,
    inferredFriendly,
    inferredEnemy,
    sameAlliance,
    unknown,
    pve,
    total: events.length,
  };
}

// ===== PARTICIPATION SCORING =====

export interface ParticipationDetail {
  friendlyParticipation: number;
  enemyParticipation: number;
  mixedInvolvement: number;
  unknownParticipation: number;
  sameAlliance: number;
  pve: number;
  incompleteAssistData: number;
  total: number;
  /** Deaths where friendly alliance participated in killing an enemy */
  friendlyKills: number;
  /** Deaths where enemy alliance participated in killing a friendly */
  enemyKills: number;
}

/**
 * Participation scoring: counts a unique opposing-guild death when at least one
 * verified member of the opposing alliance participated as a killer or assistant.
 *
 * Rules:
 * - One unique death = maximum one point for the eligible opposing alliance
 * - Multiple members of the same alliance never create additional points
 * - Exclude monster-only deaths
 * - Mixed involvement (both alliances participated) is flagged, not awarded to either
 * - Neutral participants are kept separate
 */
export function computeParticipationScore(
  events: CanonicalWarEvent[],
  sideLookup: Map<string, WarSide>,
): ParticipationDetail {
  let friendlyKills = 0;
  let enemyKills = 0;
  let mixedInvolvement = 0;
  let unknownParticipation = 0;
  let sameAlliance = 0;
  let pve = 0;
  let incompleteAssistData = 0;
  let friendlyParticipation = 0;
  let enemyParticipation = 0;

  for (const e of events) {
    // PvE deaths: no player participants
    if (!e.is_player_kill) {
      pve++;
      continue;
    }

    const { killers, assists } = getAllParticipants(e);
    const allParticipants = [...killers, ...assists];

    if (allParticipants.length === 0) {
      // Player kill flag but no player participants found — treat as unknown
      unknownParticipation++;
      continue;
    }

    // Track incomplete assist data
    const hasIncompleteAssists = assistsDataMissing(e);
    if (hasIncompleteAssists) {
      incompleteAssistData++;
    }

    // Classify each participant by their side
    let hasFriendlyParticipant = false;
    let hasEnemyParticipant = false;
    let hasKnownParticipant = false;

    for (const name of allParticipants) {
      const side = getSideForParticipant(name, sideLookup);
      if (isFriendlySide(side)) {
        hasFriendlyParticipant = true;
        hasKnownParticipant = true;
      } else if (isEnemySide(side)) {
        hasEnemyParticipant = true;
        hasKnownParticipant = true;
      }
    }

    // Same-alliance check: victim and all participants are from the same alliance
    const victimIsFriendly = isFriendlySide(e.character_side);
    const victimIsEnemy = isEnemySide(e.character_side);

    if (hasFriendlyParticipant && hasEnemyParticipant) {
      // Mixed involvement — both alliances participated, don't award to either
      mixedInvolvement++;
    } else if (hasFriendlyParticipant && victimIsEnemy) {
      // Friendly alliance killed an enemy
      friendlyKills++;
      friendlyParticipation++;
    } else if (hasEnemyParticipant && victimIsFriendly) {
      // Enemy alliance killed a friendly
      enemyKills++;
      enemyParticipation++;
    } else if (hasFriendlyParticipant && victimIsFriendly) {
      // Friendly killed friendly — same alliance
      sameAlliance++;
    } else if (hasEnemyParticipant && victimIsEnemy) {
      // Enemy killed enemy — same alliance (from our perspective)
      sameAlliance++;
    } else if (!hasKnownParticipant) {
      // No known participants — neutral/unknown killers
      unknownParticipation++;
    }
  }

  return {
    friendlyKills,
    enemyKills,
    mixedInvolvement,
    unknownParticipation,
    sameAlliance,
    pve,
    incompleteAssistData,
    friendlyParticipation,
    enemyParticipation,
    total: events.length,
  };
}

// ===== COMPARE MODE =====

export interface CompareScore {
  lastHit: LastHitScore;
  participation: ParticipationDetail;
  /** Difference in friendly kills between methods */
  friendlyDiff: number;
  /** Difference in enemy kills between methods */
  enemyDiff: number;
  /** Opposing-guild deaths that included friendly assists */
  deathsWithFriendlyAssists: number;
  /** Opposing-guild deaths that included enemy assists */
  deathsWithEnemyAssists: number;
  /** Events with incomplete participation data */
  incompleteData: number;
  /** Events that remain ambiguous (mixed involvement) */
  ambiguous: number;
}

// ===== GUILD BREAKDOWN (for stat cards) =====

export interface GuildBreakdown {
  everlastKills: number;
  allyKills: number;
  friendlyKills: number;
  enemyKills: number;
}

/**
 * Break down friendly kills by guild (Everlast vs Terrory) from canonical war events.
 * Uses the SAME scoring logic as the scoreboard so the cards always match.
 * - last-hit: credits the killer's guild (killers[0])
 * - participation: credits any verified participant's guild (one death = one point max)
 */
export function computeGuildBreakdown(
  events: CanonicalWarEvent[],
  mode: ScoringMode,
  sideLookup: Map<string, WarSide>,
): GuildBreakdown {
  let everlastKills = 0;
  let allyKills = 0;
  let friendlyKills = 0;
  let enemyKills = 0;

  if (mode === 'participation') {
    for (const e of events) {
      if (!e.is_player_kill) continue;
      const { killers, assists } = getAllParticipants(e);
      const allParticipants = [...killers, ...assists];
      if (allParticipants.length === 0) continue;

      let hasFriendlyEverlast = false;
      let hasFriendlyAlly = false;
      let hasEnemy = false;
      const victimIsFriendly = isFriendlySide(e.character_side);
      const victimIsEnemy = isEnemySide(e.character_side);

      for (const name of allParticipants) {
        const side = getSideForParticipant(name, sideLookup);
        if (side === 'everlast') hasFriendlyEverlast = true;
        else if (side === 'ally') hasFriendlyAlly = true;
        else if (side === 'enemy') hasEnemy = true;
      }

      if (hasEnemy && hasFriendlyEverlast && victimIsFriendly) {
        enemyKills++;
      }
      if (hasEnemy && hasFriendlyAlly && victimIsFriendly) {
        enemyKills++;
      }
      if (hasFriendlyEverlast && victimIsEnemy && !hasEnemy) {
        everlastKills++;
        friendlyKills++;
      }
      if (hasFriendlyAlly && victimIsEnemy && !hasEnemy && !hasFriendlyEverlast) {
        allyKills++;
        friendlyKills++;
      }
    }
    return { everlastKills, allyKills, friendlyKills, enemyKills };
  }

  // last-hit (default)
  for (const e of events) {
    if (e.war_category === 'friendly_kills_enemy' || e.war_category === 'friendly_kills_enemy_inferred') {
      friendlyKills++;
      const killerSide = e.stored_killer_side ?? e.killer_current_side;
      if (killerSide === 'everlast') everlastKills++;
      else if (killerSide === 'ally') allyKills++;
    }
    if (e.war_category === 'enemy_kills_friendly' || e.war_category === 'enemy_kills_friendly_inferred') {
      enemyKills++;
    }
  }
  return { everlastKills, allyKills, friendlyKills, enemyKills };
}

export function computeCompareScore(
  events: CanonicalWarEvent[],
  sideLookup: Map<string, WarSide>,
): CompareScore {
  const lastHit = computeLastHitScore(events);
  const participation = computeParticipationScore(events, sideLookup);

  // Count deaths where opposing-guild victims had friendly/enemy assists
  let deathsWithFriendlyAssists = 0;
  let deathsWithEnemyAssists = 0;

  for (const e of events) {
    if (!e.is_player_kill) continue;
    const { assists } = getAllParticipants(e);
    if (assists.length === 0) continue;

    for (const name of assists) {
      const side = getSideForParticipant(name, sideLookup);
      if (isFriendlySide(side) && isEnemySide(e.character_side)) {
        deathsWithFriendlyAssists++;
        break;
      }
      if (isEnemySide(side) && isFriendlySide(e.character_side)) {
        deathsWithEnemyAssists++;
        break;
      }
    }
  }

  return {
    lastHit,
    participation,
    friendlyDiff: participation.friendlyKills - lastHit.friendlyKills,
    enemyDiff: participation.enemyKills - lastHit.enemyKills,
    deathsWithFriendlyAssists,
    deathsWithEnemyAssists,
    incompleteData: participation.incompleteAssistData,
    ambiguous: participation.mixedInvolvement,
  };
}
