'use client';

import { createContext, useContext, type ReactNode } from 'react';
import { useAuth } from '@/lib/auth-context';
import { useAlertEngine } from '@/lib/alert-engine';

type GlobalAlertEngine = ReturnType<typeof useAlertEngine>;
const GlobalAlertsContext = createContext<GlobalAlertEngine | null>(null);

/**
 * App Router root layout persists across client navigation. Keep exactly ONE
 * alert poller and settings/history store for every page, including War TV.
 * Never query the authenticated API while the shared-password gate is locked.
 */
export function GlobalAlertsProvider({ children }: { children: ReactNode }) {
  const { candyUnlocked, candyChecking } = useAuth();
  const engine = useAlertEngine(candyUnlocked && !candyChecking);
  return <GlobalAlertsContext.Provider value={engine}>{children}</GlobalAlertsContext.Provider>;
}

export function useGlobalAlerts(): GlobalAlertEngine {
  const value = useContext(GlobalAlertsContext);
  if (!value) throw new Error('useGlobalAlerts must be inside GlobalAlertsProvider');
  return value;
}
