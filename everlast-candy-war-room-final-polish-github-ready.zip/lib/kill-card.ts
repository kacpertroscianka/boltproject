'use client';

import type { CanonicalWarEvent } from './types';
import { isFriendlySide, isEnemySide, GUILD_ENEMY, GUILD_EVERLAST, GUILD_ALLY } from './tibia';

const CANVAS_W = 800;
const CANVAS_H = 500;

export function generateKillCard(
  event: CanonicalWarEvent,
  scoringMode: 'last-hit' | 'participation' = 'last-hit',
): string {
  const canvas = document.createElement('canvas');
  canvas.width = CANVAS_W;
  canvas.height = CANVAS_H;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Background gradient (pastel pink → lavender)
  const bgGrad = ctx.createLinearGradient(0, 0, CANVAS_W, CANVAS_H);
  bgGrad.addColorStop(0, '#FFF4FC');
  bgGrad.addColorStop(0.5, '#F3E8FF');
  bgGrad.addColorStop(1, '#E0F2FE');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);

  // Top accent bar
  const barGrad = ctx.createLinearGradient(0, 0, CANVAS_W, 0);
  barGrad.addColorStop(0, '#55CFA6');
  barGrad.addColorStop(0.5, '#B69AF5');
  barGrad.addColorStop(1, '#F36F9E');
  ctx.fillStyle = barGrad;
  ctx.fillRect(0, 0, CANVAS_W, 8);

  // Border
  ctx.strokeStyle = '#F36F9E';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.roundRect(20, 20, CANVAS_W - 40, CANVAS_H - 40, 24);
  ctx.stroke();

  // Title
  ctx.fillStyle = '#60496B';
  ctx.font = 'bold 28px Inter, system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('🍬 Candy Kill Card', CANVAS_W / 2, 70);

  // Skull emoji placeholder + PvP badge
  ctx.font = 'bold 16px Inter, system-ui, sans-serif';
  const isPvp = event.is_pvp && event.is_player_kill;
  ctx.fillStyle = isPvp ? '#F36F9E' : '#94A3B8';
  ctx.fillText(isPvp ? '⚔️ PvP KILL' : '💀 PvE DEATH', CANVAS_W / 2, 100);

  // Victim section
  const victimY = 150;
  ctx.font = 'bold 14px Inter, system-ui, sans-serif';
  ctx.fillStyle = '#94A3B8';
  ctx.textAlign = 'left';
  ctx.fillText('VICTIM', 60, victimY);

  ctx.font = 'bold 24px Inter, system-ui, sans-serif';
  ctx.fillStyle = event.character_side === 'enemy' ? '#F36F9E' : isFriendlySide(event.character_side) ? '#55CFA6' : '#60496B';
  ctx.fillText(event.character_name, 60, victimY + 30);

  ctx.font = '16px Inter, system-ui, sans-serif';
  ctx.fillStyle = '#60496B';
  const victimGuild = event.character_side === 'enemy' ? GUILD_ENEMY : isFriendlySide(event.character_side) ? (event.character_side === 'everlast' ? GUILD_EVERLAST : GUILD_ALLY) : 'Unknown';
  ctx.fillText(`Level ${event.character_level} · ${victimGuild}`, 60, victimY + 55);

  // Killer section
  const killerY = 240;
  if (event.killer_name) {
    ctx.font = 'bold 14px Inter, system-ui, sans-serif';
    ctx.fillStyle = '#94A3B8';
    ctx.fillText('CREDITED KILLER', 60, killerY);

    ctx.font = 'bold 24px Inter, system-ui, sans-serif';
    const killerSide = event.killer_current_side ?? event.stored_killer_side;
    ctx.fillStyle = killerSide === 'enemy' ? '#F36F9E' : isFriendlySide(killerSide) ? '#55CFA6' : '#60496B';
    ctx.fillText(event.killer_name, 60, killerY + 30);

    ctx.font = '16px Inter, system-ui, sans-serif';
    ctx.fillStyle = '#60496B';
    const killerGuild = event.killer_current_guild ?? event.stored_killer_guild ?? 'Unknown';
    ctx.fillText(`${killerGuild}${event.attribution !== 'confirmed' ? ` · (${event.attribution})` : ''}`, 60, killerY + 55);
  }

  // VS divider
  ctx.font = 'bold 20px Inter, system-ui, sans-serif';
  ctx.fillStyle = '#B69AF5';
  ctx.textAlign = 'center';
  ctx.fillText('VS', CANVAS_W / 2, (victimY + killerY) / 2 + 30);

  // Details section
  const detailsY = 340;
  ctx.textAlign = 'left';
  ctx.font = 'bold 14px Inter, system-ui, sans-serif';
  ctx.fillStyle = '#94A3B8';
  ctx.fillText('DETAILS', 60, detailsY);

  ctx.font = '14px Inter, system-ui, sans-serif';
  ctx.fillStyle = '#60496B';
  const deathDate = new Date(event.death_time).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' });
  ctx.fillText(`Date: ${deathDate}`, 60, detailsY + 25);
  ctx.fillText(`Scoring: ${scoringMode === 'participation' ? 'Participation' : 'Last Hit'}`, 60, detailsY + 48);
  if (event.cause) {
    const cause = event.cause.length > 60 ? event.cause.slice(0, 57) + '...' : event.cause;
    ctx.fillText(`Reason: ${cause}`, 60, detailsY + 71);
  }

  // Branding footer
  ctx.font = 'bold 12px Inter, system-ui, sans-serif';
  ctx.fillStyle = '#F36F9E';
  ctx.textAlign = 'center';
  ctx.fillText('🍬 EVERLAST CANDY WAR ROOM · powered by Courier', CANVAS_W / 2, CANVAS_H - 35);

  // Decorative sparkles
  ctx.fillStyle = 'rgba(180, 154, 245, 0.3)';
  ctx.beginPath();
  ctx.arc(CANVAS_W - 80, 90, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.arc(CANVAS_W - 60, 110, 3, 0, Math.PI * 2);
  ctx.fill();

  return canvas.toDataURL('image/png');
}

export function downloadKillCard(event: CanonicalWarEvent, scoringMode: 'last-hit' | 'participation' = 'last-hit'): void {
  const dataUrl = generateKillCard(event, scoringMode);
  if (!dataUrl) return;
  const link = document.createElement('a');
  link.download = `kill-card-${event.character_name}-${event.event_id.slice(0, 8)}.png`;
  link.href = dataUrl;
  link.click();
}
