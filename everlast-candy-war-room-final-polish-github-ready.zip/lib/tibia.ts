import type { WarSide } from './types';

export const GUILD_EVERLAST = 'Everlast';
export const GUILD_ALLY = 'Terror Squad';
export const GUILD_ENEMY = 'Mandatory Again';
export const WORLD = 'Sinistra';

export const SIDE_LABELS: Record<WarSide, string> = {
  everlast: 'Everlast',
  ally: 'Terrory',
  enemy: 'Mandatory Again',
  neutral: 'Neutral',
};

export const SIDE_COLORS: Record<WarSide, string> = {
  everlast: 'mint',
  ally: 'lavender',
  enemy: 'pink',
  neutral: 'lavender',
};

export const ALLIANCE_LABEL = 'Everlast Alliance';

export function isFriendlySide(side: WarSide | null | undefined): boolean {
  return side === 'everlast' || side === 'ally';
}

export function isEnemySide(side: WarSide | null | undefined): boolean {
  return side === 'enemy';
}

export const VOCATION_ABBR: Record<string, string> = {
  'Elite Knight': 'EK',
  'Royal Paladin': 'RP',
  'Master Sorcerer': 'MS',
  'Elder Druid': 'ED',
  'Exalted Monk': 'XM',
  'Monk': 'MK',
  Knight: 'K',
  Paladin: 'P',
  Sorcerer: 'S',
  Druid: 'D',
  None: '-',
};

export const VOCATION_ICONS: Record<string, string> = {
  'Elite Knight': '🛡️',
  'Royal Paladin': '🏹',
  'Master Sorcerer': '✨',
  'Elder Druid': '🌿',
  'Exalted Monk': '🧘',
  'Monk': '🧘',
};

export const VOCATION_COLORS: Record<string, string> = {
  'Elite Knight': 'text-amber-500',
  'Royal Paladin': 'text-sky-500',
  'Master Sorcerer': 'text-violet-500',
  'Elder Druid': 'text-emerald-500',
  'Exalted Monk': 'text-rose-400',
  'Monk': 'text-rose-300',
};

export function vocationAbbr(vocation: string | null | undefined): string {
  if (!vocation) return '-';
  return VOCATION_ABBR[vocation] ?? vocation.slice(0, 2).toUpperCase();
}

export function vocationColor(vocation: string | null | undefined): string {
  if (!vocation) return 'text-muted-foreground';
  return VOCATION_COLORS[vocation] ?? 'text-muted-foreground';
}

export function levelDelta(char: {
  last_observed_level: number | null;
  previous_level: number | null;
}): number | null {
  if (char.last_observed_level == null || char.previous_level == null) return null;
  if (char.last_observed_level === char.previous_level) return null;
  return char.last_observed_level - char.previous_level;
}
