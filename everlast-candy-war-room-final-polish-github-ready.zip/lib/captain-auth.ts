import crypto from 'crypto';
import { cookies } from 'next/headers';

const COOKIE = 'candy_captain';
const DURATION_SEC = 8 * 60 * 60;

function key(): Buffer {
  const secret = process.env.CANDY_SESSION_SECRET;
  if (!secret || secret.length < 32) throw new Error('Session secret not configured');
  return crypto.createHmac('sha256', secret).update('captain-access-v1').digest();
}

export type CaptainTeam = 'owner' | 'everlast' | 'terrory';

const hashes: Record<CaptainTeam, string | undefined> = {
  owner: process.env.CAPTAIN_PASSWORD_HASH,
  everlast: process.env.CAPTAIN_PASSWORD_HASH_EVERLAST,
  terrory: process.env.CAPTAIN_PASSWORD_HASH_TERRORY,
};

export function captainConfigured(): boolean {
  return Boolean(process.env.CANDY_SESSION_SECRET && Object.values(hashes).some(Boolean));
}

export function checkCaptainPassword(password: string, team: CaptainTeam): boolean {
  if (typeof password !== 'string' || password.length < 12 || password.length > 256) return false;
  const raw = hashes[team] || '';
  const parts = raw.split(':');
  if (parts.length !== 3 || parts[0] !== 'scrypt' || !/^[a-f0-9]{32}$/.test(parts[1]) || !/^[a-f0-9]{128}$/.test(parts[2])) return false;
  try {
    const computed = crypto.scryptSync(password, parts[1], 64);
    return crypto.timingSafeEqual(computed, Buffer.from(parts[2], 'hex'));
  } catch { return false; }
}

export function issueCaptainToken(team: CaptainTeam): string {
  const payload = Buffer.from(JSON.stringify({ role: 'captain', team, exp: Date.now() + DURATION_SEC * 1000 })).toString('base64url');
  const sig = crypto.createHmac('sha256', key()).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

export function verifyCaptainToken(token: string | undefined): boolean {
  if (!token || token.length > 512) return false;
  try {
    const [payload, sig, extra] = token.split('.');
    if (!payload || !sig || extra) return false;
    const expected = crypto.createHmac('sha256', key()).update(payload).digest();
    const supplied = Buffer.from(sig, 'base64url');
    if (expected.length !== supplied.length || !crypto.timingSafeEqual(expected, supplied)) return false;
    const data: unknown = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (!data || typeof data !== 'object' || !('role' in data) || !('exp' in data)) return false;
    return data.role === 'captain' && 'team' in data && ['owner','everlast','terrory'].includes(String(data.team)) && typeof data.exp === 'number' && Date.now() < data.exp;
  } catch { return false; }
}

export function hasCaptainAccess(): boolean {
  try { return verifyCaptainToken(cookies().get(COOKIE)?.value); }
  catch { return false; }
}

export function captainCookie() {
  return { name: COOKIE, path: '/', sameSite: 'lax' as const,
    httpOnly: true, secure: process.env.NODE_ENV !== 'development', maxAge: DURATION_SEC };
}
