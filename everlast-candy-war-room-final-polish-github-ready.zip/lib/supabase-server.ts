import { createClient, type SupabaseClient } from '@supabase/supabase-js';

let cachedClient: SupabaseClient | null = null;

/**
 * Server-side Supabase client using the anon key.
 * Data access goes through SECURITY DEFINER RPC functions that verify
 * the CANDY_SESSION_SECRET server-side token before returning any data.
 * This avoids needing the service role key in the Next.js environment.
 */
export function getServerSupabase(): SupabaseClient {
  if (cachedClient) return cachedClient;

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anonKey) {
    throw new Error('Supabase environment variables not configured');
  }

  cachedClient = createClient(url, anonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  return cachedClient;
}

/**
 * Get the server-side secret token for RPC calls.
 * This is NEVER exposed to the browser (no NEXT_PUBLIC_ prefix).
 */
export function getCandySecret(): string {
  const secret = process.env.CANDY_SESSION_SECRET;
  if (!secret) {
    throw new Error('CANDY_SESSION_SECRET not configured');
  }
  return secret;
}
