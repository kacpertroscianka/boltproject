import type { RetroFragGuardEntry } from './types';

export type FragRiskLevel = 'black' | 'red' | 'near-black' | 'near-red' | 'low' | 'stale';
export interface FragRisk { level: FragRiskLevel; label: string; detail: string; priority: number; }

/** Manually reported unjust counts. NOT an actual skull status. */
export function evaluateFragRisk(entry: Pick<RetroFragGuardEntry, 'unjust_24h' | 'unjust_7d' | 'unjust_30d' | 'updated_at'>, now = Date.now()): FragRisk {
  const counts = [entry.unjust_24h, entry.unjust_7d, entry.unjust_30d];
  const thresholds = [3, 5, 10];
  const blackThresholds = [6, 10, 20];
  const age = now - Date.parse(entry.updated_at);
  if (counts.some((c, i) => c >= blackThresholds[i])) {
    return { level: 'black', label: 'BLACK THRESHOLD', detail: 'Manual counts have reached a black-skull threshold. Verify in-game.', priority: 6 };
  }
  if (counts.some((c, i) => blackThresholds[i] - c === 1)) {
    return { level: 'near-black', label: 'NEAR BLACK', detail: 'Already above a red threshold and one reported unjust below black.', priority: 5 };
  }
  if (counts.some((c, i) => c >= thresholds[i])) {
    return { level: 'red', label: 'RED THRESHOLD', detail: 'Manual counts have reached a red-skull threshold. Verify in-game.', priority: 4 };
  }
  if (!Number.isFinite(age) || age > 24 * 3600_000) {
    return { level: 'stale', label: 'CHECK MANUALLY', detail: 'Last manual update is older than 24 hours.', priority: 3 };
  }
  if (counts.some((c, i) => thresholds[i] - c === 1)) {
    return { level: 'near-red', label: 'NEAR RED', detail: 'One reported unjust below a red-skull threshold.', priority: 2 };
  }
  return { level: 'low', label: 'BELOW THRESHOLDS', detail: 'Reported manual counts are below thresholds. Not proof of a safe skull.', priority: 1 };
}

export const FRAG_RISK_CLASSES: Record<FragRiskLevel, string> = {
  black: 'border-zinc-700 bg-zinc-900 text-white',
  red: 'border-rose-300 bg-rose-100 text-rose-700',
  'near-black': 'border-orange-400 bg-orange-100 text-orange-800',
  'near-red': 'border-amber-300 bg-amber-100 text-amber-800',
  stale: 'border-purple-300 bg-purple-100 text-purple-800',
  low: 'border-emerald-300 bg-emerald-100 text-emerald-700',
};
