'use client';

import { useEffect, useState, useRef } from 'react';
import { Gift, Heart, Sparkles, X } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';

export function WelcomeToast() {
  const { candyUnlocked, candyChecking } = useAuth();
  const [visible, setVisible] = useState(false);
  const [exiting, setExiting] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (candyChecking || !candyUnlocked) { setVisible(false); return; }
    if (window.sessionStorage.getItem('candy-welcome-shown-v1') === '1') return;
    window.sessionStorage.setItem('candy-welcome-shown-v1', '1');
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const showDelay = prefersReducedMotion ? 200 : 600;
    const dismissDelay = 10000;

    const showTimer = setTimeout(() => setVisible(true), showDelay);
    const dismissTimer = setTimeout(() => {
      setExiting(true);
      setTimeout(() => setVisible(false), prefersReducedMotion ? 0 : 400);
    }, showDelay + dismissDelay);

    timerRef.current = dismissTimer;

    return () => {
      clearTimeout(showTimer);
      clearTimeout(dismissTimer);
    };
  }, [candyUnlocked, candyChecking]);

  function handleClose() {
    setExiting(true);
    if (timerRef.current) clearTimeout(timerRef.current);
    setTimeout(() => setVisible(false), 300);
  }

  if (!visible) return null;

  return (
    <div
      className={`fixed z-[60] pointer-events-auto ${exiting ? 'animate-toast-exit' : 'animate-toast-enter'}`}
      style={{
        bottom: 'max(1rem, env(safe-area-inset-bottom))',
        left: '1rem',
        maxWidth: 'calc(100vw - 2rem)',
      }}
    >
      <div
        className="relative rounded-3xl border-2 p-4 pr-10 shadow-lg"
        style={{
          background: 'linear-gradient(135deg, hsl(330 90% 92%), hsl(280 80% 94%))',
          borderColor: 'hsl(280 70% 82%)',
          width: '340px',
          maxWidth: 'calc(100vw - 2rem)',
        }}
      >
        <button
          onClick={handleClose}
          aria-label="Close"
          className="absolute right-2 top-2 rounded-full p-1 transition-colors hover:bg-white/50"
        >
          <X className="size-3.5" style={{ color: 'hsl(330 60% 60%)' }} />
        </button>

        <div className="flex items-start gap-3">
          <div className="flex shrink-0 items-center gap-1">
            <Gift className="size-5" style={{ color: 'hsl(330 80% 65%)' }} />
            <Sparkles className="size-3.5 animate-sparkle" style={{ color: 'hsl(50 90% 65%)' }} />
          </div>
          <div className="min-w-0 flex-1">
            <div
              className="text-sm font-bold mb-1"
              style={{ color: 'hsl(280 50% 35%)' }}
            >
              🍬 Czy wiesz, że? 💝
            </div>
            <div
              className="text-xs leading-relaxed"
              style={{ color: 'hsl(280 40% 40%)' }}
            >
              Terror Parcel Courier podarował dla Byku Retro Frontline — Tagralt Blade! 🎁⚔️
            </div>
            <div className="mt-2 flex items-center gap-1">
              <Heart
                className="size-2.5 animate-heartbeat"
                fill="currentColor"
                style={{ color: 'hsl(330 70% 65%)' }}
              />
              <span
                className="text-[9px] font-semibold uppercase tracking-wider"
                style={{ color: 'hsl(330 50% 55%)' }}
              >
                Courier
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
