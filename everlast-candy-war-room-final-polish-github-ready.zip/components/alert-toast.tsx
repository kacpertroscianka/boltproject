'use client';

import { useEffect, useState, useCallback } from 'react';
import { X, ExternalLink } from 'lucide-react';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import type { AlertEventType, AlertHistoryEntry } from '@/lib/alert-types';
import { isFriendlySide, isEnemySide } from '@/lib/tibia';

interface ActiveToast {
  id: string;
  title: string;
  message: string;
  type: AlertEventType;
  side: 'everlast' | 'ally' | 'enemy' | 'neutral' | null;
  detailHref: string | null;
  createdAt: number;
}

const TOAST_DURATION = 8000; // 8 seconds

const SIDE_STYLES: Record<string, { border: string; bg: string; text: string }> = {
  everlast: { border: 'border-emerald-300', bg: 'bg-emerald-50', text: 'text-emerald-600' },
  ally: { border: 'border-purple-300', bg: 'bg-purple-50', text: 'text-purple-600' },
  enemy: { border: 'border-pink-300', bg: 'bg-pink-50', text: 'text-pink-600' },
  neutral: { border: 'border-blue-300', bg: 'bg-blue-50', text: 'text-blue-600' },
};

export function AlertToastContainer() {
  const [toasts, setToasts] = useState<ActiveToast[]>([]);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as {
        type: AlertEventType;
        title: string;
        message: string;
        side?: string | null;
        detailHref?: string | null;
      };
      const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const toast: ActiveToast = {
        id,
        title: detail.title,
        message: detail.message,
        type: detail.type,
        side: (detail.side as ActiveToast['side']) || null,
        detailHref: detail.detailHref ?? null,
        createdAt: Date.now(),
      };
      setToasts((prev) => [...prev.slice(-3), toast]); // max 4 at a time

      // Auto-dismiss after duration
      setTimeout(() => dismissToast(id), TOAST_DURATION);
    };

    window.addEventListener('candy-alert', handler);
    return () => window.removeEventListener('candy-alert', handler);
  }, [dismissToast]);

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2 max-w-sm w-[calc(100vw-2rem)] pointer-events-none" role="region" aria-label="Candy notifications" aria-live="polite">
      {toasts.map((toast) => {
        const styleKey = toast.side || 'neutral';
        const style = SIDE_STYLES[styleKey] ?? SIDE_STYLES.neutral;
        const elapsed = Date.now() - toast.createdAt;
        const progress = Math.max(0, 100 - (elapsed / TOAST_DURATION) * 100);

        return (
          <div
            key={toast.id}
            className={cn(
              'pointer-events-auto rounded-2xl border-2 p-4 shadow-[0_8px_24px_-4px_rgba(0,0,0,0.15)] backdrop-blur-xl animate-float-up',
              style.border,
              style.bg,
            )}
          >
            <div className="flex items-start gap-3">
              <div className="flex-1 min-w-0">
                <div className={cn('text-sm font-bold mb-1', style.text)}>
                  {toast.title}
                </div>
                <div className="text-xs text-foreground/80 leading-relaxed">
                  {toast.message}
                </div>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                {toast.detailHref && (
                  <Link
                    href={toast.detailHref}
                    className="rounded-lg p-1 hover:bg-white/60 transition-colors"
                    aria-label="Open details"
                    onClick={() => dismissToast(toast.id)}
                  >
                    <ExternalLink className={cn('size-3.5', style.text)} />
                  </Link>
                )}
                <button
                  onClick={() => dismissToast(toast.id)}
                  className="rounded-lg p-1 hover:bg-white/60 transition-colors"
                  aria-label="Dismiss"
                >
                  <X className={cn('size-3.5', style.text)} />
                </button>
              </div>
            </div>
            {/* Progress bar */}
            <div className="mt-2 h-1 rounded-full bg-black/10 overflow-hidden">
              <div
                className={cn('h-full rounded-full transition-all', style.text, 'bg-current opacity-50')}
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
