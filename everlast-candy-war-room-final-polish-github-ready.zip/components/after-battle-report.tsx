'use client';

import { useEffect, useState } from 'react';
import { BarChart3, Clock, FileText } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { getAfterBattleReport } from '@/lib/queries';
import type { AfterBattleReport as ReportData } from '@/lib/types';

export function AfterBattleReport({ warCallId }: { warCallId: string }) {
  const [report, setReport] = useState<ReportData | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let mounted = true; setLoading(true); setReport(null); setError('');
    void getAfterBattleReport(warCallId).then(data => { if (mounted) setReport(data); })
      .catch(() => { if (mounted) setError('Raport niedostępny — migracja SQL lub połączenie Supabase.'); })
      .finally(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, [warCallId]);
  return <Card className="rounded-3xl border-2 border-sky-200 bg-white/90 shadow-bubbly">
    <CardHeader>
      <CardTitle className="flex items-center gap-2 text-lg"><FileText className="size-5 text-sky-500" /> After Battle Report</CardTitle>
      <CardDescription>Podsumowanie dostępnych zdarzeń z przedziału czasu zakończonego War Calla.</CardDescription>
    </CardHeader>
    <CardContent className="space-y-4">
      {loading ? <p className="text-sm text-muted-foreground">Ładowanie raportu...</p> : error ? <p role="alert" className="text-sm text-red-700">{error}</p> : !report ? <p>Brak danych.</p> : !report.available ?
        <p className="text-sm text-amber-700">Nie można wygenerować raportu: {report.reason}. Starsze zakończone calle mogą nie mieć zapisanego czasu zakończenia.</p> : <>
          <div className="rounded-xl border border-sky-200 bg-sky-50 p-3 text-xs text-sky-900">
            <div className="font-bold flex items-center gap-2"><Clock className="size-4" /> {new Date(report.windowStart).toLocaleString()} — {new Date(report.windowEnd).toLocaleString()}</div>
            <p className="mt-1">⚠️ Dopasowanie TYLKO po czasie: zgony i kille z tego okresu nie musiały należeć do tej walki. To nie jest zweryfikowany wynik War Calla.</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {([
              ['Alliance confirmed', report.summary.allianceConfirmed], ['Enemy confirmed', report.summary.enemyConfirmed],
              ['Alliance inferred', report.summary.allianceInferred], ['Enemy inferred', report.summary.enemyInferred],
              ['Alliance deaths', report.summary.allianceDeaths], ['Enemy deaths', report.summary.enemyDeaths],
              ['PvE deaths', report.summary.pveDeaths], ['Total logged', report.summary.totalEvents],
            ] as [string, number][]).map(([label, count]) => <div key={label} className="rounded-xl border border-sky-200 bg-sky-50/60 p-3">
              <div className="text-xl font-black text-sky-800">{count}</div><div className="text-xs text-muted-foreground">{label}</div>
            </div>)}
          </div>
          <div className="space-y-2 max-h-72 overflow-y-auto">
            <p className="flex items-center gap-2 text-sm font-bold"><BarChart3 className="size-4" /> Ostatnie zdarzenia (max 30)</p>
            {report.events.map(event => <div key={event.eventId} className="rounded-xl border border-sky-100 bg-white p-2 text-xs">
              <span className="font-semibold">{event.victim}</span> ({event.victimLevel}) · {event.killer || 'PvE/unknown'} · {event.category} · {new Date(event.time).toLocaleTimeString()}
            </div>)}
            {report.events.length === 0 && <p className="text-sm text-muted-foreground">Brak zarejestrowanych zdarzeń w tym czasie.</p>}
          </div>
        </>}
    </CardContent>
  </Card>;
}
