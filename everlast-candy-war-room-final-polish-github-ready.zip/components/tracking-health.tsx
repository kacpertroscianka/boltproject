'use client';

import { useState, useEffect, useMemo } from 'react';
import { Activity, Users, CheckCircle, Clock, AlertTriangle, RefreshCw, XCircle } from 'lucide-react';
import { fetchData } from '@/lib/api-client';
import { getCharactersBySides, getRecentSyncLogs } from '@/lib/queries';
import type { Character, SyncLogEntry, WarSide } from '@/lib/types';
import { cn } from '@/lib/utils';
import { timeAgo } from '@/lib/format';

interface SyncQueueStats {
  total: number;
  pending: number;
  failed: number;
}

export function TrackingHealth() {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [syncLogs, setSyncLogs] = useState<SyncLogEntry[]>([]);
  const [queueStats, setQueueStats] = useState<SyncQueueStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    Promise.allSettled([
      getCharactersBySides(['everlast', 'ally', 'enemy']),
      getRecentSyncLogs(10),
    ]).then(([charsR, logsR]) => {
      if (charsR.status === 'fulfilled') setCharacters(charsR.value);
      if (logsR.status === 'fulfilled') setSyncLogs(logsR.value);
      setError([charsR, logsR].some((r) => r.status === 'rejected'));
      setLoading(false);
    });
  }, []);

  const stats = useMemo(() => {
    const total = characters.length;
    const recentlyChecked = characters.filter((c) => {
      if (!c.updated_at) return false;
      const age = Date.now() - new Date(c.updated_at).getTime();
      return age < 60 * 60 * 1000; // checked in last hour
    }).length;
    const stale = characters.filter((c) => {
      if (!c.updated_at) return true;
      const age = Date.now() - new Date(c.updated_at).getTime();
      return age > 6 * 60 * 60 * 1000; // stale if > 6h
    }).length;

    const lastSync = syncLogs[0];
    const successfulSyncs = syncLogs.filter((s) => s.status === 'success');

    return {
      total,
      recentlyChecked,
      stale,
      lastSync,
      successfulSyncs: successfulSyncs.length,
      totalSyncs: syncLogs.length,
    };
  }, [characters, syncLogs]);

  const lastSyncTime = stats.lastSync?.finished_at ?? stats.lastSync?.started_at;
  const isStale = stats.stale > stats.total * 0.3;

  if (loading) {
    return (
      <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-4 shadow-bubbly">
        <div className="text-xs text-muted-foreground font-semibold">Loading tracking health...</div>
      </div>
    );
  }

  if (error && characters.length === 0) {
    return (
      <div className="rounded-2xl border-2 border-amber-200 bg-amber-50/50 p-4 shadow-bubbly">
        <div className="flex items-center gap-2 text-xs font-bold text-amber-600">
          <AlertTriangle className="size-4" />
          Failed to load tracking data. Retrying on next refresh.
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-4 shadow-bubbly">
      <div className="flex items-center gap-2 mb-3">
        <Activity className="size-4 text-emerald-400" />
        <h3 className="text-sm font-bold text-foreground">Tracking Health</h3>
        <span className={cn('ml-auto flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold', isStale ? 'border-amber-300 bg-amber-50 text-amber-600' : 'border-emerald-300 bg-emerald-50 text-emerald-600')}>
          {isStale ? <AlertTriangle className="size-2.5" /> : <CheckCircle className="size-2.5" />}
          {isStale ? 'Stale' : 'Healthy'}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <HealthStat icon={Users} label="Monitored" value={stats.total} color="text-foreground" />
        <HealthStat icon={CheckCircle} label="Checked (1h)" value={stats.recentlyChecked} color="text-emerald-500" />
        <HealthStat icon={Clock} label="Last Sync" value={lastSyncTime ? timeAgo(lastSyncTime) : '—'} color="text-purple-500" isText />
        <HealthStat icon={AlertTriangle} label="Stale (>6h)" value={stats.stale} color="text-amber-500" />
      </div>

      {isStale && (
        <div className="mt-2 rounded-xl border border-amber-200 bg-amber-50/50 p-2 text-[10px] text-amber-600 font-semibold">
          Some characters haven&apos;t been checked in over 6 hours. Sync may be delayed.
        </div>
      )}

      <div className="mt-2 text-[10px] text-muted-foreground">
        Per-character refresh interval depends on the sync queue, not cron frequency.
      </div>
    </div>
  );
}

function HealthStat({ icon: Icon, label, value, color, isText }: { icon: typeof Users; label: string; value: number | string; color: string; isText?: boolean }) {
  return (
    <div className="rounded-xl border border-pink-100 bg-white/60 p-2">
      <div className="flex items-center gap-1.5 mb-0.5">
        <Icon className={cn('size-3', color)} />
        <span className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">{label}</span>
      </div>
      <div className={cn('font-extrabold tabular-nums', isText ? 'text-xs' : 'text-lg', color)}>
        {value}
      </div>
    </div>
  );
}
