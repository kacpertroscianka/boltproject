'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { BellOff, BellRing, Volume2, WifiOff } from 'lucide-react';
import { getActiveTeamWarCall } from '@/lib/queries';
import { playSound, unlockAudio } from '@/lib/alert-engine';

const ENABLED_KEY = 'candy-war-call-alerts-v1';
const SEEN_KEY = 'candy-war-call-seen-v1';
const LOCK_KEY = 'candy-war-call-lock-v1';
const POLL_MS = 12000;

type State = 'off' | 'on' | 'unavailable';

/** Foreground app + best-effort background-tab notifications. NOT closed-browser Web Push. */
export function WarCallNotifier() {
  const [state, setState] = useState<State>('off');
  const [enabled, setEnabled] = useState(false);
  const [soundReady, setSoundReady] = useState(false);
  const [busy, setBusy] = useState(false);
  const fetching = useRef(false);

  const check = useCallback(async () => {
    if (fetching.current) return;
    fetching.current = true;
    try {
      const active = await getActiveTeamWarCall();
      setState('on');
      const newId = active?.id ?? 'none';
      const stored = localStorage.getItem(SEEN_KEY);
      if (stored === null) {
        // A freshly enabled user sees only future War Calls, never old alerts.
        localStorage.setItem(SEEN_KEY, newId);
        return;
      }
      if (!active || stored === newId) return;
      if (Date.now() - Date.parse(active.created_at) > 24 * 3600_000) { localStorage.setItem(SEEN_KEY, newId); return; }
      localStorage.setItem(SEEN_KEY, newId);
      // Shared storage stops typical multiple-tab duplicate alerts.
      const lock = localStorage.getItem(LOCK_KEY);
      let previous: { id: string; expires: number } | null = null;
      try { previous = lock ? JSON.parse(lock) as { id: string; expires: number } : null; } catch {}
      if (previous && previous.expires > Date.now() && previous.id === active.id) return;
      localStorage.setItem(LOCK_KEY, JSON.stringify({ id: active.id, expires: Date.now() + 60000 }));

      const summary = [active.meeting_point, active.starts_at ? new Date(active.starts_at).toLocaleString('pl-PL') : null]
        .filter(Boolean).join(' • ');
      const message = `${active.title}${summary ? ` — ${summary}` : ''}`;
      window.dispatchEvent(new CustomEvent('candy-alert', {
        detail: { type: 'friendly_kill', title: '📢 NEW WAR CALL', message, side: 'everlast', detailHref: '/battle-command' },
      }));
      // Browser autoplay restrictions may require re-arming sound after reload.
      playSound('friendly_kill', 0.35);
      if ('Notification' in window && Notification.permission === 'granted') {
        try {
          const notification = new Notification('⚔️ Everlast Battle Command — War Call!', {
            body: message,
            tag: `war-call-${active.id}`,
          });
          notification.onclick = () => { window.focus(); window.location.assign('/battle-command'); notification.close(); };
        } catch { /* Visual alert still works. */ }
      }
    } catch {
      setState('unavailable');
    } finally { fetching.current = false; }
  }, []);

  useEffect(() => { setEnabled(localStorage.getItem(ENABLED_KEY) === '1'); }, []);

  useEffect(() => {
    if (!enabled) { setState('off'); return; }
    setState('on');
    void check();
    const timer = window.setInterval(() => void check(), POLL_MS);
    const onVisibility = () => { if (document.visibilityState === 'visible') void check(); };
    document.addEventListener('visibilitychange', onVisibility);
    return () => { window.clearInterval(timer); document.removeEventListener('visibilitychange', onVisibility); };
  }, [check, enabled]);

  const toggle = async () => {
    if (enabled) {
      localStorage.setItem(ENABLED_KEY, '0');
      setEnabled(false);
      setSoundReady(false);
      return;
    }
    setBusy(true);
    try {
      if ('Notification' in window && Notification.permission === 'default') {
        await Notification.requestPermission();
      }
      setSoundReady(await unlockAudio());
      localStorage.removeItem(SEEN_KEY);
      localStorage.setItem(ENABLED_KEY, '1');
      setEnabled(true);
    } finally { setBusy(false); }
  };

  const armSound = async () => { setSoundReady(await unlockAudio()); };
  const Icon = !enabled ? BellOff : state === 'unavailable' ? WifiOff : BellRing;
  return (
    <div className="flex shrink-0 items-center gap-1">
      <button type="button" onClick={() => void toggle()} disabled={busy}
        className="flex items-center gap-1 rounded-xl border-2 border-purple-200 bg-purple-50 px-2 py-1.5 text-[11px] font-bold text-purple-700 hover:bg-purple-100"
        title="War Call notifications, with the site open (may be delayed in background tabs). Click to toggle."
        aria-label={`War Call notifications ${enabled ? 'enabled' : 'disabled'}. Toggle`}>
        <Icon className="size-3.5" />
        <span className="hidden lg:inline">War Call {enabled ? state === 'unavailable' ? '—' : 'ON' : 'OFF'}</span>
      </button>
      {enabled && !soundReady && <button type="button" onClick={() => void armSound()}
        className="rounded-xl border border-amber-300 bg-amber-50 p-1.5 text-amber-700"
        title="Click to enable War Call sound in this tab after refresh"
        aria-label="Activate War Call sound"><Volume2 className="size-3.5" /></button>}
    </div>
  );
}
