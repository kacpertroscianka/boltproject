'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Backpack, ClipboardCheck, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { TeamSupplyChecklist } from '@/lib/types';
import { getTeamSupplyChecklists } from '@/lib/queries';

const fields = [
  ['potions', 'Potions / mana'], ['runes', 'Runes / bombs'], ['amulets', 'Amulet / ring'],
  ['backpack', 'Backpack / bless check'], ['voice_comms', 'TeamSpeak / voice'],
] as const;
type Field = (typeof fields)[number][0];
type Checklist = Record<Field, boolean>;
const empty: Checklist = { potions: false, runes: false, amulets: false, backpack: false, voice_comms: false };

export function BattleSupplies({ warCallId }: { warCallId: string }) {
  const [rows, setRows] = useState<TeamSupplyChecklist[]>([]);
  const [checked, setChecked] = useState<Checklist>(empty);
  const [note, setNote] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const load = useCallback(async () => {
    try {
      const current = await getTeamSupplyChecklists(warCallId);
      setRows(current); setError(null);
      const clientId = window.localStorage.getItem('battle_command_client_id');
      const mine = current.find(x => x.client_id === clientId);
      if (mine) {
        setChecked({ potions: mine.potions, runes: mine.runes, amulets: mine.amulets, backpack: mine.backpack, voice_comms: mine.voice_comms });
        setNote(mine.note || '');
      }
    } catch { setError('Lista zapasów niedostępna. Sprawdź migrację Supabase.'); }
    finally { setLoading(false); }
  }, [warCallId]);

  useEffect(() => { void load(); const timer = window.setInterval(() => { if (document.visibilityState === 'visible') void load(); }, 30_000); return () => window.clearInterval(timer); }, [load]);
  const complete = useMemo(() => rows.filter(r => fields.every(([key]) => r[key])).length, [rows]);

  const save = async () => {
    const clientId = window.localStorage.getItem('battle_command_client_id');
    if (!clientId) { setError('Najpierw zaznacz status READY / ON MY WAY / AFK przy swoim nicku.'); return; }
    setSaving(true); setError(null); setSaved(false);
    try {
      const response = await fetch('/api/battle-command', { method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'supplies', warCallId, clientId,
          potions: checked.potions, runes: checked.runes, amulets: checked.amulets,
          backpack: checked.backpack, voiceComms: checked.voice_comms, note }) });
      const json = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(json.error || 'Nie można zapisać checklisty');
      setSaved(true); await load();
    } catch (e) { setError(e instanceof Error ? e.message : 'Błąd zapisu'); }
    finally { setSaving(false); }
  };

  return <Card className="rounded-3xl border-2 border-purple-200 bg-white/90 shadow-bubbly">
    <CardHeader>
      <CardTitle className="flex items-center gap-2 text-lg"><Backpack className="size-5 text-purple-500" /> Battle Supplies Checklist</CardTitle>
      <CardDescription>Lista samodzielnie zgłoszonych przygotowań. Najpierw zaznacz gotowość na aktywnym War Callu.</CardDescription>
    </CardHeader>
    <CardContent className="space-y-4">
      <div className="rounded-xl bg-purple-50 border border-purple-200 p-3 text-sm font-bold text-purple-700">
        {loading || error ? '—' : `${complete} / ${rows.length} graczy potwierdziło komplet zapasów`}
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        {fields.map(([field, label]) => <label key={field} className="flex cursor-pointer items-center gap-3 rounded-xl border border-purple-200 bg-purple-50/50 p-3 text-sm">
          <input type="checkbox" checked={checked[field]} onChange={e => { setSaved(false); setChecked(v => ({ ...v, [field]: e.target.checked })); }} className="size-4 accent-purple-600" />{label}
        </label>)}
      </div>
      <Input value={note} maxLength={240} onChange={e => { setSaved(false); setNote(e.target.value); }} placeholder="Brakuje mi... / Będę gotowy za 5 minut" className="rounded-xl" aria-label="Supply note" />
      <Button type="button" onClick={save} disabled={saving || loading || !!error} className="rounded-xl bg-purple-600 hover:bg-purple-700">
        {saving ? <Loader2 className="mr-2 size-4 animate-spin" /> : <ClipboardCheck className="mr-2 size-4" />} Zapisz przygotowanie
      </Button>
      {saved && <p className="text-xs font-semibold text-emerald-700">Zapisano checklistę.</p>}
      {error && <p role="alert" className="text-xs text-rose-700">{error}</p>}
      <div className="space-y-2 max-h-64 overflow-y-auto">
        {rows.map(row => <div key={row.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-purple-200 px-3 py-2 text-xs">
          <span className="font-bold text-foreground">{row.player_name}</span>
          <span className={fields.every(([field]) => row[field]) ? 'font-bold text-emerald-700' : 'text-amber-700'}>{fields.every(([field]) => row[field]) ? '✅ Fully supplied' : `${fields.filter(([field]) => row[field]).length}/5 ready`}</span>
          {row.note && <span className="w-full text-muted-foreground">{row.note}</span>}
        </div>)}
      </div>
      <p className="text-xs text-muted-foreground">Deklaracje, nie potwierdzenie przedmiotów w grze. Status jest współdzielony między odwiedzającymi.</p>
    </CardContent>
  </Card>;
}
