'use client';

import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { ArrowRight, CheckCircle2, RadioTower, ShieldAlert, Users } from 'lucide-react';
import type { TeamWarCall, TeamWarCallResponse } from '@/lib/types';
import type { OnlineSummary } from '@/lib/queries';
import { getActiveTeamWarCall, getTeamWarCallResponses } from '@/lib/queries';
import { vocationAbbr } from '@/lib/tibia';

export function TeamRallyMini({ online }: { online: OnlineSummary | null }) {
  const [call, setCall] = useState<TeamWarCall | null>(null);
  const [responses, setResponses] = useState<TeamWarCallResponse[]>([]);
  const [status, setStatus] = useState<'loading' | 'ok' | 'error'>('loading');
  const load = useCallback(async () => {
    try {
      const active = await getActiveTeamWarCall();
      const ready = active ? await getTeamWarCallResponses(active.id) : [];
      setCall(active);
      setResponses(ready);
      setStatus('ok');
    } catch { setStatus('error'); }
  }, []);
  useEffect(() => {
    void load();
    const id = window.setInterval(() => { if (document.visibilityState === 'visible') void load(); }, 30000);
    return () => window.clearInterval(id);
  }, [load]);
  const onlineAllies = online ? [...online.everlastMembers, ...online.allyMembers].filter(c => c.online) : [];
  const ready = responses.filter(r => r.readiness_status === 'ready');
  return (
    <section className="rounded-3xl border-2 border-violet-200 bg-gradient-to-r from-violet-50 via-white to-emerald-50 p-4 shadow-bubbly" aria-label="Candy Battle Command rally summary">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2"><RadioTower className="size-5 text-violet-600" /><h2 className="text-sm font-black text-violet-700">⚔️ Team Rally — Everlast + Terrory</h2></div>
        <Link href="/battle-command" className="inline-flex items-center gap-1 rounded-xl border-2 border-violet-200 bg-white px-3 py-1.5 text-xs font-bold text-violet-700 hover:bg-violet-50">Open Battle Command <ArrowRight className="size-3" /></Link>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
        <div className="rounded-xl bg-emerald-100/70 p-3"><div className="text-xs text-emerald-700">Alliance online</div><div className="text-2xl font-black text-emerald-700">{online ? online.friendlyOnline : '—'}</div></div>
        <div className="rounded-xl bg-rose-100/70 p-3"><div className="text-xs text-rose-700">Enemy online</div><div className="text-2xl font-black text-rose-700">{online ? online.enemyOnline : '—'}</div></div>
        <div className="rounded-xl bg-violet-100/70 p-3"><div className="text-xs text-violet-700">Ready / OMW</div><div className="text-2xl font-black text-violet-700">{status === 'ok' ? `${ready.length}/${responses.filter(r=>r.readiness_status==='omw').length}` : '—'}</div></div>
        <div className="rounded-xl bg-amber-100/70 p-3"><div className="text-xs text-amber-700">War Call</div><div className="text-sm font-black text-amber-800 mt-1 truncate">{status !== 'ok' ? '—' : call ? call.title : 'No active call'}</div></div>
      </div>
      {status === 'error' && <p className="mt-2 flex items-center gap-1 text-xs text-amber-700"><ShieldAlert className="size-3.5" /> War Call data unavailable. Check migration / API.</p>}
      {status === 'ok' && call && <p className="mt-2 text-xs font-bold text-violet-700">📣 Meeting: {call.meeting_point || 'TBA'} {call.starts_at ? `· ${new Date(call.starts_at).toLocaleString('pl-PL')}` : '· ASAP'}</p>}
      <div className="mt-3 flex flex-wrap gap-1.5">
        {onlineAllies.slice(0, 12).map(c => <span key={c.id} className="rounded-full border border-emerald-200 bg-white px-2 py-1 text-[11px] font-bold text-emerald-700">{c.name} <span className="font-normal">{vocationAbbr(c.vocation)}</span></span>)}
        {!online && <span className="text-xs text-muted-foreground">Online roster unavailable</span>}
        {online && onlineAllies.length === 0 && <span className="text-xs text-muted-foreground">No alliance members currently reported online</span>}
      </div>
      <p className="mt-2 text-[11px] text-muted-foreground">Online data follows the latest TibiaData sync. READY is a self-reported status, not verified identity.</p>
    </section>
  );
}
