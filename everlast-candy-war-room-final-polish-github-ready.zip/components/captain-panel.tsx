'use client';

import { useEffect, useState } from 'react';
import { Crown, LockKeyhole, LogOut, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function CaptainPanel({ onChange }: { onChange: (active: boolean) => void }) {
  const [configured, setConfigured] = useState<boolean | null>(null);
  const [active, setActive] = useState(false);
  const [password, setPassword] = useState('');
  const [team, setTeam] = useState<'everlast' | 'terrory' | 'owner'>('everlast');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let mounted = true;
    void fetch('/api/captain', { cache: 'no-store', credentials: 'same-origin' })
      .then(async (r) => { if (!r.ok) throw new Error('Captain status unavailable'); return r.json(); })
      .then((r) => {
        if (!mounted) return;
        setConfigured(Boolean(r.configured));
        setActive(Boolean(r.captain));
        onChange(Boolean(r.captain));
      })
      .catch(() => {
        if (mounted) { setConfigured(null); setActive(false); onChange(false); setError('Nie udało się pobrać statusu kapitana.'); }
      });
    return () => { mounted = false; };
  }, [onChange]);

  const unlock = async () => {
    if (busy || !password) return;
    setBusy(true); setError('');
    try {
      const res = await fetch('/api/captain', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password, team }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json.error || 'Nieprawidłowe hasło kapitana');
      setActive(true); onChange(true); setPassword('');
    } catch (e) { setError(e instanceof Error ? e.message : 'Captain login failed'); }
    finally { setBusy(false); }
  };
  const lock = async () => {
    setBusy(true);
    try {
      const res = await fetch('/api/captain', { method: 'DELETE', credentials: 'same-origin' });
      if (!res.ok) throw new Error('Nie udało się wylogować kapitana');
      setActive(false); onChange(false);
    } catch(e) { setError(e instanceof Error ? e.message : 'Captain logout failed'); }
    finally { setBusy(false); }
  };

  return <div className="rounded-3xl border-2 border-amber-200 bg-gradient-to-r from-amber-50 to-pink-50 p-4 space-y-2" aria-label="Captain Mode">
    <div className="flex flex-wrap items-center justify-between gap-2">
      <div className="flex items-center gap-2 text-sm font-black text-amber-800"><Crown className="size-5" /> Captain Mode</div>
      {active ? <span className="flex items-center gap-1 text-xs font-bold text-emerald-700"><ShieldCheck className="size-4" /> UNLOCKED</span> : <span className="flex items-center gap-1 text-xs font-bold text-amber-800"><LockKeyhole className="size-4" /> LOCKED</span>}
    </div>
    {active ? <div className="flex flex-wrap items-center justify-between gap-2">
      <p className="text-xs text-muted-foreground">Możesz zarządzać War Callami i ręcznym Frag Guardem. Sesja kapitana wygasa po 8 godzinach.</p>
      <Button size="sm" variant="outline" onClick={lock} disabled={busy} className="rounded-xl"><LogOut className="mr-1 size-3" /> Lock captain</Button>
    </div> : configured === false ? <p className="text-sm text-amber-800">Captain Mode wymaga hasha hasła kapitana w konfiguracji serwera (Everlast, Terrory lub Owner). Nie używaj wspólnego hasła Candy.</p>
    : <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
      <select value={team} onChange={e => setTeam(e.target.value as typeof team)} aria-label="Captain team" className="rounded-xl border border-amber-200 bg-white px-3 py-2 text-sm"><option value="everlast">Everlast captain</option><option value="terrory">Terrory captain</option><option value="owner">Owner</option></select>
      <Input type="password" autoComplete="current-password" value={password} maxLength={256} onChange={e => setPassword(e.target.value)} onKeyDown={e => { if(e.key === 'Enter') void unlock(); }} placeholder="Hasło kapitana" className="rounded-xl bg-white" aria-label="Captain password" />
      <Button size="sm" onClick={unlock} disabled={busy || !password || configured === null} className="rounded-xl bg-amber-600 hover:bg-amber-700">Unlock Captain</Button>
    </div>}
    {error && <p role="alert" className="text-xs text-red-700">{error}</p>}
  </div>;
}
