'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { Eye, WifiOff } from 'lucide-react';

const POLL_INTERVAL_MS = 25_000;
const ACTIVE_WINDOW_SECONDS = 90;

type PresenceState =
  | { status: 'loading' | 'unavailable'; count: null }
  | { status: 'online'; count: number };

/**
 * A private, approximate count of recently ACTIVE shared-password sessions.
 * Hidden tabs stop sending heartbeats and expire server-side after 90 seconds.
 * The server derives the anonymous identifier from the verified HttpOnly cookie.
 * The browser does not generate visitor IDs or send authentication secrets.
 */
export function CandyVisitors() {
  const [presence, setPresence] = useState<PresenceState>({ status: 'loading', count: null });
  const lastSuccess = useRef(0);
  const retryAfter = useRef(0);
  const activeSignal = useRef<AbortSignal | null>(null);

  const refresh = useCallback(async (signal?: AbortSignal) => {
    if (document.visibilityState !== 'visible' || signal?.aborted || Date.now() < retryAfter.current) return;
    // A cancelled request from a previous effect must not block a new one
    // (particularly during React Strict Mode's development double-mount).
    if (activeSignal.current && !activeSignal.current.aborted) return;
    activeSignal.current = signal ?? null;
    try {
      const response = await fetch('/api/presence', {
        method: 'POST',
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { Accept: 'application/json' },
        signal,
      });
      if (!response.ok) {
        // Until the optional Supabase migration is installed, the server returns
        // 503. Retry slowly so the incomplete setup cannot spam the backend.
        retryAfter.current = Date.now() + (response.status === 503 ? 180_000 : 45_000);
        throw new Error(`Presence ${response.status}`);
      }
      const result: unknown = await response.json();
      if (
        !result || typeof result !== 'object' ||
        !('count' in result) || typeof result.count !== 'number' ||
        !Number.isSafeInteger(result.count) || result.count < 0
      ) {
        throw new Error('Invalid presence response');
      }
      if (signal?.aborted || document.visibilityState !== 'visible') return;
      lastSuccess.current = Date.now();
      retryAfter.current = 0;
      setPresence({ status: 'online', count: result.count });
    } catch (error) {
      if (signal?.aborted) return;
      // A failed request is NEVER a real count of zero. Do not display a stale
      // count as live while the authenticated API is unavailable.
      setPresence({ status: 'unavailable', count: null });
    } finally {
      if (activeSignal.current === signal) activeSignal.current = null;
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    const onVisibility = () => {
      if (document.visibilityState === 'visible') {
        // Immediately reconnect after foregrounding.
        void refresh(controller.signal);
      } else {
        setPresence({ status: 'loading', count: null });
      }
    };
    void refresh(controller.signal);
    document.addEventListener('visibilitychange', onVisibility);
    const interval = window.setInterval(() => {
      if (document.visibilityState === 'visible') {
        // If an earlier request has stalled, the count is not trustworthy.
        if (lastSuccess.current && Date.now() - lastSuccess.current > ACTIVE_WINDOW_SECONDS * 1000) {
          setPresence({ status: 'unavailable', count: null });
        }
        void refresh(controller.signal);
      }
    }, POLL_INTERVAL_MS);
    return () => {
      controller.abort();
      window.clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [refresh]);

  const isOnline = presence.status === 'online';
  return (
    <div
      className="flex shrink-0 items-center gap-1.5 rounded-full border-2 border-purple-200 bg-gradient-to-r from-purple-50 to-pink-50 px-2.5 py-1.5 shadow-bubbly sm:gap-2 sm:px-3"
      title={`Przybliżona liczba aktywnych sesji zalogowanych w ciągu ostatnich ${ACTIVE_WINDOW_SECONDS} sekund. Kilka kart tej samej sesji liczy się jako jedna.`}
      aria-label={isOnline ? `Candy Visitors: ${presence.count} aktywnych sesji` : 'Candy Visitors: licznik niedostępny'}
      role="status"
      aria-live="polite"
    >
      <Eye aria-hidden="true" className="size-3.5 text-purple-500" />
      <span className="hidden xl:inline text-[11px] font-bold text-purple-600">Candy Visitors</span>
      {isOnline ? (
        <>
          <span className="text-xs font-extrabold tabular-nums text-purple-700">{presence.count}</span>
          <span className="size-1.5 rounded-full bg-emerald-400 motion-safe:animate-pulse" aria-hidden="true" />
          <span className="hidden sm:inline text-[10px] font-semibold text-emerald-600">LIVE</span>
        </>
      ) : (
        <>
          <span className="text-xs font-bold text-purple-400">—</span>
          <WifiOff aria-hidden="true" className="size-3 text-purple-300" />
        </>
      )}
    </div>
  );
}
