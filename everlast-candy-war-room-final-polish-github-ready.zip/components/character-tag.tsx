import { cn } from '@/lib/utils';
import { vocationAbbr, vocationColor } from '@/lib/tibia';
import { Crown, Star, Heart } from 'lucide-react';
import type { WarSide } from '@/lib/types';

interface CharacterTagProps {
  name: string;
  vocation?: string | null;
  level?: number | null;
  side?: WarSide;
  rank?: string | null;
  className?: string;
}

export function CharacterTag({ name, vocation, level, side, rank, className }: CharacterTagProps) {
  return (
    <div className={cn('flex items-center gap-2.5 min-w-0', className)}>
      <div
        className={cn(
          'flex size-8 shrink-0 items-center justify-center rounded-xl text-xs font-bold border-2',
          side === 'everlast' && 'bg-emerald-100 text-emerald-600 border-emerald-300',
          side === 'ally' && 'bg-purple-100 text-purple-500 border-purple-300',
          side === 'enemy' && 'bg-pink-100 text-pink-500 border-pink-300',
          (!side || side === 'neutral') && 'bg-purple-50 text-purple-400 border-purple-200',
        )}
      >
        {vocationAbbr(vocation)}
      </div>
      <div className="min-w-0">
        <div className="flex items-center gap-1.5">
          {rank === 'Leader' && <Crown className="size-3 shrink-0 text-amber-400" fill="currentColor" />}
          {rank === 'Vice Leader' && <Star className="size-3 shrink-0 text-sky-400" fill="currentColor" />}
          <span className="truncate text-sm font-bold text-foreground">{name}</span>
        </div>
        {vocation && (
          <div className={cn('text-[11px] font-semibold', vocationColor(vocation))}>
            {vocation}
            {level != null && <span className="text-muted-foreground"> · Lv {level}</span>}
          </div>
        )}
      </div>
    </div>
  );
}

export function OnlineIndicator({ online, className }: { online: boolean; className?: string }) {
  return (
    <div className={cn('flex items-center gap-1.5', className)}>
      <span
        className={cn(
          'size-2.5 rounded-full',
          online ? 'bg-emerald-400 animate-pulse-soft' : 'bg-gray-300',
        )}
      />
      <span className={cn('text-[11px] font-bold', online ? 'text-emerald-500' : 'text-muted-foreground')}>
        {online ? 'Online' : 'Offline'}
      </span>
    </div>
  );
}

export function SideBadge({ side }: { side: WarSide }) {
  const styles: Record<WarSide, string> = {
    everlast: 'bg-emerald-100 text-emerald-600 border-emerald-300',
    ally: 'bg-purple-100 text-purple-500 border-purple-300',
    enemy: 'bg-pink-100 text-pink-500 border-pink-300',
    neutral: 'bg-purple-50 text-purple-400 border-purple-200',
  };
  const labels: Record<WarSide, string> = {
    everlast: 'Everlast',
    ally: 'Terrory',
    enemy: 'Mandatory Again',
    neutral: 'Neutral',
  };
  return (
    <span className={cn('inline-flex items-center rounded-lg border-2 px-2 py-0.5 text-[10px] font-bold', styles[side])}>
      {labels[side]}
    </span>
  );
}

export function LevelDelta({ delta }: { delta: number | null }) {
  if (delta === null) return null;
  if (delta === 0) return null;
  return (
    <span className={cn('text-[11px] font-bold', delta > 0 ? 'text-emerald-500' : 'text-pink-500')}>
      {delta > 0 ? `+${delta}` : delta}
    </span>
  );
}
