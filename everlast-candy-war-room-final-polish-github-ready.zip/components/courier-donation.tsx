'use client';

import { useState } from 'react';
import { Check, Copy, Gift, Heart } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

const CHARACTER = 'Terror Parcel Courier';

/** In-game Tibia Coins support: informational only, never a checkout. */
export function CourierDonation() {
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState(false);

  async function copyName() {
    try {
      await navigator.clipboard.writeText(CHARACTER);
      setCopied(true);
      setError(false);
    } catch {
      setCopied(false);
      setError(true);
    }
  }

  return (
    <Popover onOpenChange={() => { setCopied(false); setError(false); }}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="inline-flex items-center gap-1.5 rounded-full border-2 border-pink-200 bg-gradient-to-r from-pink-50 to-purple-50 px-3 py-1.5 text-[11px] font-bold text-pink-500 shadow-bubbly transition-transform hover:-translate-y-0.5 hover:from-pink-100 hover:to-purple-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-pink-400 motion-reduce:transform-none"
          aria-label="Wsparcie strony Tibia Coins w grze"
        >
          <Heart aria-hidden="true" className="size-3.5" fill="currentColor" />
          Donate Tibia Coins
        </button>
      </PopoverTrigger>
      <PopoverContent
        side="top"
        align="center"
        sideOffset={10}
        className="z-[80] w-[min(20rem,calc(100vw-2rem))] rounded-3xl border-2 border-pink-200 bg-gradient-to-br from-white via-pink-50 to-purple-50 p-4 shadow-xl"
      >
        <div className="space-y-3 text-center">
          <div className="mx-auto flex size-10 items-center justify-center rounded-2xl bg-pink-100">
            <Gift aria-hidden="true" className="size-5 text-pink-500" />
          </div>
          <h2 className="text-sm font-extrabold text-purple-700">💝 Support Everlast Candy War Room</h2>
          <p className="text-xs leading-relaxed text-purple-600">
            Donate Tibia Coins in-game to <strong>Terror Parcel Courier</strong> to keep improving this website and adding more features! 🍬💖
          </p>
          <div className="rounded-2xl border border-purple-200 bg-white/80 p-3">
            <p className="text-[10px] font-semibold uppercase tracking-wider text-purple-400">🎮 In-game character</p>
            <p className="mt-1 select-all text-sm font-bold text-purple-700">{CHARACTER}</p>
            <button
              type="button"
              onClick={() => { void copyName(); }}
              className="mt-2 inline-flex items-center gap-1.5 rounded-xl bg-pink-100 px-3 py-1.5 text-xs font-bold text-pink-600 transition-colors hover:bg-pink-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-pink-400"
            >
              {copied ? <Check aria-hidden="true" className="size-3.5" /> : <Copy aria-hidden="true" className="size-3.5" />}
              {copied ? 'Copied!' : 'Copy Name'}
            </button>
            {error && <p role="alert" className="mt-2 text-[11px] text-pink-600">Nie udało się skopiować — zaznacz nick powyżej.</p>}
          </div>
          <p className="text-[10px] text-purple-400">Voluntary in-game support only • No real-money payments</p>
        </div>
      </PopoverContent>
    </Popover>
  );
}
