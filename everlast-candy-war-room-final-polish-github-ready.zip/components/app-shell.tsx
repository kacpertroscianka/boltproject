'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import {
  LayoutDashboard,
  Crosshair,
  Radar,
  BarChart3,
  Bell,
  BellRing,
  Menu,
  X,
  Globe,
  LogIn,
  Lock,
  Heart,
  Star,
  Sparkles,
  Candy,
  Mail,
  ShieldCheck,
  Tv,
  Swords,
  Clock,
  Skull,
  Trophy,
  TrendingUp,
  Users,
  ShieldAlert,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/lib/auth-context';
import { useGlobalAlerts } from '@/lib/global-alerts-context';
import { CandyVisitors } from '@/components/candy-visitors';
import { WarCallNotifier } from '@/components/war-call-notifier';
import { CourierDonation } from '@/components/courier-donation';

const NAV_ITEMS = [
  { href: '/', label: 'Dashboard', icon: LayoutDashboard, emoji: '🏠' },
  { href: '/war-tv', label: 'War TV', icon: Tv, emoji: '📺' },
  { href: '/battle-command', label: 'Battle Command', icon: Users, emoji: '🫡' },
  { href: '/war-sessions', label: 'War Sessions', icon: Swords, emoji: '⚔️' },
  { href: '/war-replay', label: 'War Replay', icon: Clock, emoji: '⏪' },
  { href: '/nemesis', label: 'Nemesis Board', icon: Skull, emoji: '💀' },
  { href: '/death-radar', label: 'Death Radar', icon: Radar, emoji: '📡' },
  { href: '/enemy-tracker', label: 'Enemy Tracker', icon: Crosshair, emoji: '🎯' },
  { href: '/level-tracker', label: 'Level Tracker', icon: TrendingUp, emoji: '📈' },
  { href: '/analytics', label: 'War Analytics', icon: BarChart3, emoji: '📊' },
  { href: '/retro-frag-guard', label: 'Retro Frag Guard', icon: ShieldAlert, emoji: '☠️' },
  { href: '/candy-awards', label: 'Candy Awards', icon: Trophy, emoji: '🏆' },
  { href: '/war-verification', label: 'War Verification', icon: ShieldCheck, emoji: '🛡️' },
  { href: '/alerts', label: 'Candy Alerts', icon: BellRing, emoji: '🔔' },
  { href: '/watchlist', label: 'Watchlist', icon: Bell, emoji: '📋' },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, loading, lockCandy, candyUnlocked } = useAuth();
  const { unreadCount } = useGlobalAlerts();

  useEffect(() => { setMobileOpen(false); }, [pathname]);

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };

  return (
    <div className="min-h-screen bg-background bg-candy-dots">
      <div className="pointer-events-none fixed inset-0 overflow-hidden z-0">
        <Star className="absolute top-[10%] left-[5%] size-6 text-yellow-300/40 animate-sparkle" fill="currentColor" />
        <Heart className="absolute top-[20%] right-[8%] size-5 text-pink-300/40 animate-bounce-soft" fill="currentColor" />
        <Sparkles className="absolute top-[50%] left-[3%] size-7 text-purple-300/30 animate-sparkle" style={{ animationDelay: '0.5s' }} />
        <Star className="absolute top-[70%] right-[5%] size-5 text-blue-300/40 animate-sparkle" fill="currentColor" style={{ animationDelay: '1s' }} />
        <Heart className="absolute top-[85%] left-[7%] size-4 text-pink-300/30 animate-bounce-soft" fill="currentColor" style={{ animationDelay: '0.3s' }} />
      </div>

      <header className="sticky top-0 z-40 border-2 border-pink-200/60 bg-white/80 backdrop-blur-xl rounded-b-3xl">
        <div className="flex h-16 items-center justify-between px-4 lg:px-6">
          <div className="flex items-center gap-3">
            <button
              className="lg:hidden p-2 rounded-xl hover:bg-pink-100 transition-colors"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="size-5 text-pink-400" /> : <Menu className="size-5 text-pink-400" />}
            </button>
            <Link href="/" className="flex items-center gap-3 group">
              <div className="relative">
                <div className="flex size-10 items-center justify-center rounded-2xl bg-gradient-to-br from-pink-300 to-purple-300 shadow-bubbly group-hover:animate-wiggle">
                  <Candy className="size-5 text-white" />
                </div>
                <Sparkles className="absolute -top-1 -right-1 size-3 text-yellow-300 animate-sparkle" />
              </div>
              <div className="hidden sm:block">
                <div className="text-sm font-bold tracking-tight text-foreground leading-none">
                  EVERLAST <span className="text-rainbow">CANDY</span> WAR ROOM
                </div>
                <div className="text-[10px] text-muted-foreground uppercase tracking-widest mt-0.5 flex items-center gap-1">
                  <Heart className="size-2.5 text-pink-400" fill="currentColor" /> Sinistra Intelligence
                </div>
              </div>
            </Link>
          </div>

          <div className="flex items-center gap-2">
            {candyUnlocked && pathname !== '/unlock' && pathname !== '/login' && <WarCallNotifier />}
            {candyUnlocked && pathname !== '/unlock' && pathname !== '/login' && <CandyVisitors />}
            <div className="hidden md:flex items-center gap-2 rounded-full border-2 border-pink-200 bg-white/60 px-3 py-1.5 shadow-bubbly">
              <Globe className="size-3.5 text-purple-400" />
              <span className="text-xs font-bold text-foreground">Sinistra</span>
              <span className="size-2 rounded-full bg-violet-300" title="Świat: Sinistra. To nie jest wskaźnik statusu serwera." />
            </div>
            {candyUnlocked && <button
              onClick={() => lockCandy()}
              className="flex items-center gap-1.5 rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-1.5 text-xs font-bold text-pink-400 hover:bg-pink-50 transition-colors shadow-bubbly"
              title="Zablokuj Candy War Room"
            >
              <Lock className="size-3.5" />
              <span className="hidden sm:inline">🔒 Zablokuj</span>
            </button>}
            {loading ? (
              <div className="size-8 rounded-full bg-pink-100 animate-pulse" />
            ) : user ? (
              <Link
                href="/watchlist"
                className="flex items-center gap-2 rounded-full border-2 border-emerald-300 bg-emerald-50 px-3 py-1.5 hover:bg-emerald-100 transition-colors shadow-bubbly-everlast"
              >
                <Heart className="size-4 text-emerald-500" fill="currentColor" />
                <span className="text-xs font-bold text-emerald-600">
                  {user.email?.split('@')[0]}
                </span>
              </Link>
            ) : (
              <Link
                href="/login"
                className="flex items-center gap-2 rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-1.5 text-xs font-bold hover:bg-pink-50 transition-colors shadow-bubbly"
              >
                <LogIn className="size-4 text-pink-400" />
                Sign In
              </Link>
            )}
          </div>
        </div>
      </header>

      <div className="flex relative z-10">
        <aside className="hidden lg:flex w-60 flex-col border-r-2 border-pink-200/60 bg-white/40 min-h-[calc(100vh-4rem)] sticky top-16 overflow-y-auto">
          <nav aria-label="Main navigation" className="flex flex-col gap-1.5 p-4">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  aria-current={active ? 'page' : undefined}
                  className={cn(
                    'group flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-bold transition-all',
                    active
                      ? 'bg-gradient-to-r from-pink-100 to-purple-100 text-pink-500 border-2 border-pink-300 shadow-bubbly'
                      : 'text-purple-400 hover:bg-pink-50 hover:text-pink-400 border-2 border-transparent',
                  )}
                >
                  <Icon className={cn('size-4.5 shrink-0', active && 'text-pink-500')} />
                  <span>{item.label}</span>
                  <span className="ml-auto flex items-center gap-1.5">
                    {item.href === '/alerts' && unreadCount > 0 && <span className="rounded-full bg-pink-500 px-1.5 py-0.5 text-[10px] font-black tabular-nums text-white" aria-label={`${unreadCount} unread alerts`}>{unreadCount > 99 ? '99+' : unreadCount}</span>}
                    <span className="text-base opacity-60" aria-hidden="true">{item.emoji}</span>
                  </span>
                </Link>
              );
            })}
          </nav>
          <div className="mt-auto p-4">
            <div className="rounded-2xl border-2 border-pink-200 bg-gradient-to-br from-pink-50 to-purple-50 p-4 shadow-bubbly">
              <div className="flex items-center gap-2 mb-2">
                <Heart className="size-4 text-pink-400 animate-heartbeat" fill="currentColor" />
                <span className="text-xs font-bold text-foreground">War Status</span>
              </div>
              <div className="text-[11px] text-muted-foreground leading-relaxed">
                Everlast Alliance (Everlast + Terrory) vs Mandatory Again. Data syncs from TibiaData API.
              </div>
              <div className="mt-2 flex items-center gap-1.5">
                <span className="size-2 rounded-full bg-emerald-400 animate-pulse-soft" />
                <span className="text-[10px] text-muted-foreground font-bold uppercase tracking-wider">
                  Live monitoring
                </span>
              </div>
            </div>
          </div>
        </aside>

        {mobileOpen && (
          <div className="lg:hidden fixed inset-0 z-50 bg-white/95 backdrop-blur-xl">
            <div className="flex h-16 items-center justify-between px-4 border-b-2 border-pink-200">
              <span className="text-sm font-bold tracking-tight flex items-center gap-2">
                <Candy className="size-5 text-pink-400" /> Navigation
              </span>
              <button onClick={() => setMobileOpen(false)} className="p-2 rounded-xl hover:bg-pink-100">
                <X className="size-5 text-pink-400" />
              </button>
            </div>
            <nav aria-label="Mobile navigation" className="flex flex-col gap-1.5 p-4 overflow-y-auto max-h-[calc(100vh-4rem)]">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = isActive(item.href);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setMobileOpen(false)}
                    className={cn(
                      'flex items-center gap-3 rounded-2xl px-3 py-3 text-sm font-bold transition-all',
                      active
                        ? 'bg-gradient-to-r from-pink-100 to-purple-100 text-pink-500 border-2 border-pink-300'
                        : 'text-purple-400 hover:bg-pink-50',
                    )}
                  >
                    <Icon className="size-5" />
                    {item.label}
                    <span className="ml-auto flex items-center gap-1.5">
                    {item.href === '/alerts' && unreadCount > 0 && <span className="rounded-full bg-pink-500 px-1.5 py-0.5 text-[10px] font-black tabular-nums text-white" aria-label={`${unreadCount} unread alerts`}>{unreadCount > 99 ? '99+' : unreadCount}</span>}
                    <span className="text-base opacity-60" aria-hidden="true">{item.emoji}</span>
                  </span>
                  </Link>
                );
              })}
            </nav>
          </div>
        )}

        <main className="flex-1 min-w-0 p-4 lg:p-8">{children}</main>
      </div>

      <footer className="relative z-10 border-t-2 border-pink-200/60 bg-white/60 backdrop-blur-sm">
        <div className="flex flex-wrap items-center justify-center gap-3 py-3 px-4">
          <span
            className="text-xs font-semibold tracking-wide"
            style={{
              color: 'hsl(330 80% 70%)',
            }}
          >
            <Mail className="inline-block size-3 mr-1 -translate-y-px" />
            powered by Courier
          </span>
          <CourierDonation />
        </div>
      </footer>
    </div>
  );
}
