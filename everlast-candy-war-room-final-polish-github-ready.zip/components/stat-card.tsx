import { cn } from '@/lib/utils';
import { AlertCircle, Database, Clock, Sparkles, Heart } from 'lucide-react';
import type { ReactNode } from 'react';

export function StatCard({
  label,
  value,
  sublabel,
  icon: Icon,
  side = 'neutral',
  className,
}: {
  label: string;
  value: ReactNode;
  sublabel?: string;
  icon?: React.ComponentType<{ className?: string }>;
  side?: 'everlast' | 'enemy' | 'ally' | 'neutral';
  className?: string;
}) {
  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-2xl border-2 bg-white/70 p-5 transition-all hover:bg-white/90 shadow-bubbly',
        side === 'everlast' && 'border-emerald-200 hover:border-emerald-300 shadow-bubbly-everlast',
        side === 'ally' && 'border-purple-200 hover:border-purple-300 shadow-bubbly',
        side === 'enemy' && 'border-pink-200 hover:border-pink-300 shadow-bubbly-enemy',
        side === 'neutral' && 'border-purple-200 hover:border-purple-300',
        className,
      )}
    >
      <div className="flex items-start justify-between">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            {label}
          </div>
          <div
            className={cn(
              'mt-2 text-3xl font-bold tabular-nums',
              side === 'everlast' && 'text-emerald-500',
              side === 'ally' && 'text-purple-500',
              side === 'enemy' && 'text-pink-500',
              side === 'neutral' && 'text-foreground',
            )}
          >
            {value}
          </div>
          {sublabel && <div className="mt-1 text-xs text-muted-foreground font-semibold">{sublabel}</div>}
        </div>
        {Icon && (
          <div
            className={cn(
              'flex size-10 items-center justify-center rounded-xl',
              side === 'everlast' && 'bg-emerald-100 text-emerald-500',
              side === 'ally' && 'bg-purple-100 text-purple-500',
              side === 'enemy' && 'bg-pink-100 text-pink-400',
              side === 'neutral' && 'bg-purple-100 text-purple-400',
            )}
          >
            <Icon className="size-5" />
          </div>
        )}
      </div>
    </div>
  );
}

export function DataUnavailable({ message, lastUpdated }: { message: string; lastUpdated?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border-2 border-pink-200 bg-white/50 p-8 text-center shadow-bubbly">
      <AlertCircle className="size-8 text-pink-300" />
      <div className="text-sm text-muted-foreground font-semibold">{message}</div>
      {lastUpdated && (
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Clock className="size-3" />
          Last updated: {lastUpdated}
        </div>
      )}
    </div>
  );
}

export function MockDataBadge({ show }: { show: boolean }) {
  if (!show) return null;
  return (
    <div className="inline-flex items-center gap-1.5 rounded-lg border-2 border-amber-200 bg-amber-50 px-2.5 py-1 text-[10px] font-bold text-amber-600">
      <Database className="size-3" />
      Mock Dev Data
    </div>
  );
}

export function LoadingState({ label = 'Loading...' }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 p-8">
      <div className="size-6 animate-spin rounded-full border-3 border-pink-200 border-t-pink-400" />
      <span className="text-sm font-bold text-muted-foreground flex items-center gap-1.5">
        <Sparkles className="size-4 text-pink-300 animate-sparkle" />
        {label}
      </span>
    </div>
  );
}
