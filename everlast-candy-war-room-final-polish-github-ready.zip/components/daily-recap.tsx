'use client';

import { useState, useMemo, useEffect } from 'react';
import {
  Swords, Skull, Heart, TrendingUp, TrendingDown, Star,
  Zap, AlertCircle, Calendar, Download, Sparkles,
} from 'lucide-react';
import {
  getRecentDeaths, getCanonicalWarEvents,
  getRecentLevelUps, getRecentLevelDowns,
} from '@/lib/queries';
import type { DeathEvent, CanonicalWarEvent, LevelEvent } from '@/lib/types';
import { isFriendlySide, isEnemySide } from '@/lib/tibia';
import {
  computeLastHitScore, computeParticipationScore, buildSideLookup,
} from '@/lib/scoring';
import { computeTopKillers } from '@/lib/queries';
import { cn } from '@/lib/utils';

type Period = 'today' | '24h' | '7d';

export function DailyWarRecap() {
  const [period, setPeriod] = useState<Period>('today');
  const [deaths, setDeaths] = useState<DeathEvent[]>([]);
  const [events, setEvents] = useState<CanonicalWarEvent[]>([]);
  const [levelUps, setLevelUps] = useState<LevelEvent[]>([]);
  const [levelDowns, setLevelDowns] = useState<LevelEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    Promise.allSettled([
      getRecentDeaths(2000),
      getCanonicalWarEvents(2000),
      getRecentLevelUps(500),
      getRecentLevelDowns(500),
    ]).then(([dR, ceR, luR, ldR]) => {
      if (dR.status === 'fulfilled') setDeaths(dR.value);
      if (ceR.status === 'fulfilled') setEvents(ceR.value);
      if (luR.status === 'fulfilled') setLevelUps(luR.value);
      if (ldR.status === 'fulfilled') setLevelDowns(ldR.value);
      setError([dR, ceR, luR, ldR].some((r) => r.status === 'rejected'));
      setLoading(false);
    });
  }, []);

  const { startTime, label } = useMemo(() => {
    const now = new Date();
    if (period === 'today') {
      // Tibia server save is at 10:00 CET. Use UTC midnight as approximation.
      const start = new Date(now);
      start.setHours(0, 0, 0, 0);
      return { startTime: start.getTime(), label: 'Today (UTC midnight)' };
    }
    if (period === '24h') {
      return { startTime: now.getTime() - 24 * 60 * 60 * 1000, label: 'Last 24 hours' };
    }
    return { startTime: now.getTime() - 7 * 24 * 60 * 60 * 1000, label: 'Last 7 days' };
  }, [period]);

  const stats = useMemo(() => {
    const sessionDeaths = deaths.filter((d) => new Date(d.death_time).getTime() >= startTime);
    const sessionEvents = events.filter((e) => new Date(e.death_time).getTime() >= startTime);
    const sessionUps = levelUps.filter((e) => new Date(e.observed_at).getTime() >= startTime);
    const sessionDowns = levelDowns.filter((e) => new Date(e.observed_at).getTime() >= startTime);

    const sideLookup = buildSideLookup(sessionEvents);
    const lastHit = computeLastHitScore(sessionEvents);
    const participation = computeParticipationScore(sessionEvents, sideLookup);

    const friendlyDeaths = sessionDeaths.filter((d) => isFriendlySide(d.character_side)).length;
    const enemyDeaths = sessionDeaths.filter((d) => isEnemySide(d.character_side)).length;
    const pvpDeaths = sessionDeaths.filter((d) => d.is_pvp).length;
    const pveDeaths = sessionDeaths.filter((d) => !d.is_pvp).length;

    const topKillers = computeTopKillers(sessionDeaths, 5);

    return {
      friendlyKills: lastHit.friendlyKills,
      enemyKills: lastHit.enemyKills,
      participationFriendly: participation.friendlyKills,
      participationEnemy: participation.enemyKills,
      friendlyDeaths,
      enemyDeaths,
      pvpDeaths,
      pveDeaths,
      levelUps: sessionUps.length,
      levelDowns: sessionDowns.length,
      unknown: lastHit.unknown,
      topKillers,
      totalEvents: sessionEvents.length,
    };
  }, [deaths, events, levelUps, levelDowns, startTime]);

  if (loading) {
    return (
      <div className="rounded-3xl border-2 border-pink-200 bg-white/70 p-6 shadow-bubbly">
        <div className="text-sm text-muted-foreground font-semibold">Loading recap...</div>
      </div>
    );
  }

  if (error && events.length === 0) {
    return (
      <div className="rounded-3xl border-2 border-amber-200 bg-amber-50/50 p-6 shadow-bubbly">
        <div className="flex items-center gap-2 text-sm font-bold text-amber-600">
          <AlertCircle className="size-4" />
          Failed to load war recap data. Retrying on next refresh.
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-3xl border-2 border-pink-200 bg-gradient-to-br from-pink-50/80 to-purple-50/40 p-6 shadow-bubbly">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Sparkles className="size-5 text-pink-400" />
          <h2 className="text-lg font-bold text-foreground">🍭 Today&apos;s War Recap</h2>
        </div>
        <div className="flex items-center gap-1">
          {(['today', '24h', '7d'] as Period[]).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={cn('rounded-lg border-2 px-2.5 py-1 text-[10px] font-bold transition-colors', period === p ? 'border-pink-300 bg-pink-50 text-pink-500' : 'border-pink-100 bg-white/40 text-muted-foreground')}
            >
              {p === 'today' ? 'Today' : p === '24h' ? '24h' : '7d'}
            </button>
          ))}
        </div>
      </div>

      <div className="text-xs text-muted-foreground font-semibold mb-4 flex items-center gap-1">
        <Calendar className="size-3" />
        {label} · {stats.totalEvents} events
      </div>

      {/* Main score */}
      <div className="flex items-center justify-center gap-6 mb-4">
        <div className="text-center">
          <div className="text-4xl font-extrabold tabular-nums text-emerald-500">{stats.friendlyKills}</div>
          <div className="text-[10px] font-bold text-emerald-600">Friendly Kills</div>
        </div>
        <div className="text-xl text-muted-300">:</div>
        <div className="text-center">
          <div className="text-4xl font-extrabold tabular-nums text-pink-500">{stats.enemyKills}</div>
          <div className="text-[10px] font-bold text-pink-600">Enemy Kills</div>
        </div>
      </div>

      {/* Participation comparison */}
      {stats.participationFriendly !== stats.friendlyKills && (
        <div className="text-center text-[10px] text-muted-foreground font-semibold mb-3">
          Participation: {stats.participationFriendly} friendly · {stats.participationEnemy} enemy
        </div>
      )}

      {/* Stat grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
        <RecapStat label="Friendly Deaths" value={stats.friendlyDeaths} color="blue" />
        <RecapStat label="Enemy Deaths" value={stats.enemyDeaths} color="pink" />
        <RecapStat label="PvP" value={stats.pvpDeaths} color="purple" />
        <RecapStat label="PvE" value={stats.pveDeaths} color="gray" />
        <RecapStat label="Level Ups" value={stats.levelUps} color="emerald" />
        <RecapStat label="Level Downs" value={stats.levelDowns} color="pink" />
        <RecapStat label="Unknown" value={stats.unknown} color="amber" />
        <RecapStat label="Total Events" value={stats.totalEvents} color="purple" />
      </div>

      {/* Top killers */}
      {stats.topKillers.length > 0 && (
        <div className="mt-4">
          <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Most Active Killers</div>
          <div className="space-y-1">
            {stats.topKillers.slice(0, 3).map((k, i) => (
              <div key={k.name} className="flex items-center gap-2 text-xs">
                <span className={cn('flex size-5 items-center justify-center rounded-lg text-[10px] font-bold', i === 0 ? 'bg-amber-100 text-amber-500' : 'bg-purple-100 text-purple-400')}>{i + 1}</span>
                <span className="font-bold text-foreground truncate">{k.name}</span>
                <span className="ml-auto font-bold tabular-nums text-emerald-500">{k.kills} kills</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mt-3 text-[10px] text-muted-foreground">
        Uses Last Hit scoring. Scores computed from canonical events within the time window. Times are UTC.
      </div>
    </div>
  );
}

function RecapStat({ label, value, color }: { label: string; value: number; color: string }) {
  const colorMap: Record<string, string> = {
    emerald: 'border-emerald-200 bg-emerald-50/50 text-emerald-600',
    pink: 'border-pink-200 bg-pink-50/50 text-pink-600',
    blue: 'border-blue-200 bg-blue-50/50 text-blue-600',
    purple: 'border-purple-200 bg-purple-50/50 text-purple-600',
    amber: 'border-amber-200 bg-amber-50/50 text-amber-600',
    gray: 'border-gray-200 bg-gray-50/50 text-gray-600',
  };
  return (
    <div className={cn('rounded-xl border-2 p-2 text-center', colorMap[color])}>
      <div className="text-lg font-extrabold tabular-nums">{value}</div>
      <div className="text-[9px] font-bold uppercase tracking-wider opacity-70">{label}</div>
    </div>
  );
}
