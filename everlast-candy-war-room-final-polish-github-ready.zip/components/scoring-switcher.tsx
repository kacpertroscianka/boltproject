'use client';

import { Swords, Users, GitCompare } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { ScoringMode } from '@/lib/scoring';
import { SCORING_MODE_LABELS } from '@/lib/scoring';

const MODE_ICONS: Record<ScoringMode, typeof Swords> = {
  'last-hit': Swords,
  'participation': Users,
  'compare': GitCompare,
};

const MODES: ScoringMode[] = ['last-hit', 'participation', 'compare'];

export function ScoringSwitcher({
  mode,
  onChange,
}: {
  mode: ScoringMode;
  onChange: (mode: ScoringMode) => void;
}) {
  return (
    <div
      className="inline-flex gap-1.5 rounded-full border-2 border-pink-200 bg-white/80 p-1.5 shadow-bubbly"
      role="tablist"
      aria-label="War scoring mode"
    >
      {MODES.map((m) => {
        const Icon = MODE_ICONS[m];
        const active = mode === m;
        const info = SCORING_MODE_LABELS[m];
        return (
          <button
            key={m}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(m)}
            className={cn(
              'flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-bold transition-all duration-300',
              active
                ? 'bg-gradient-to-r from-pink-200 via-purple-200 to-blue-200 text-foreground shadow-[0_0_12px_rgba(236,72,153,0.3)] scale-105'
                : 'text-purple-400 hover:bg-pink-50 hover:text-pink-400',
            )}
          >
            <Icon className={cn('size-3.5 transition-transform', active && 'scale-110')} />
            <span className="hidden sm:inline">{info.label}</span>
            <span className="sm:hidden">{info.emoji}</span>
          </button>
        );
      })}
    </div>
  );
}
