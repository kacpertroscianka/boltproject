// Usage: node scripts/generate-captain-hash.cjs
// Prints ONLY the scrypt hash. Run individually for Owner, Everlast and Terrory.
const crypto = require('crypto');
const readline = require('readline');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: !!process.stdin.isTTY });
if (process.stdin.isTTY) {
  process.stdout.write('Enter captain password (min 12 chars; input hidden): ');
  rl._writeToOutput = function() {}; // Suppress echo of input while reading.
}
rl.question(process.stdin.isTTY ? '' : 'Captain password (min 12 chars): ', password => {
  rl.close();
  if (process.stdin.isTTY) process.stdout.write('\n');
  if (password.length < 12 || password.length > 256) { console.error('Length must be 12-256'); process.exitCode=1; return; }
  const salt = crypto.randomBytes(16).toString('hex');
  console.log('scrypt:' + salt + ':' + crypto.scryptSync(password, salt, 64).toString('hex'));
});
