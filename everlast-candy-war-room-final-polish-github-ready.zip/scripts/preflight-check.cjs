/**
 * Zero-dependency source preflight for projects that cannot install npm yet.
 * Does NOT replace `npm run typecheck`, `npm run lint`, `npm run build` or live DB tests.
 * Run from project root: node scripts/preflight-check.cjs
 */
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const paths = ['app', 'components', 'lib', 'hooks'];
const files = [];
const errors = [];
function walk(dir) {
  for (const child of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, child.name);
    if (child.isDirectory()) walk(full);
    else if (/\.(ts|tsx)$/.test(full)) files.push(full);
  }
}
paths.forEach(d => walk(path.join(root, d)));
const isFile = p => fs.existsSync(p) && fs.statSync(p).isFile();
const resolveModule = (file, moduleName) => {
  const target = moduleName.startsWith('@/')
    ? path.join(root, moduleName.slice(2))
    : path.resolve(path.dirname(file), moduleName);
  return ['.ts', '.tsx', '.js', '.jsx', '/index.ts', '/index.tsx'].some(suffix => isFile(target + suffix));
};
let imports = 0;
for (const file of files) {
  const body = fs.readFileSync(file, 'utf8');
  const importsFound = [...body.matchAll(/(?:import\s+(?:[\s\S]*?\s+from\s+)?|import\()['"]([^'"]+)['"]/g)];
  for (const item of importsFound) {
    const moduleName = item[1];
    if (moduleName.startsWith('@/') || moduleName.startsWith('.')) {
      imports++;
      if (!resolveModule(file, moduleName)) errors.push(`Broken import ${moduleName} in ${path.relative(root, file)}`);
    }
  }
}
const app = path.join(root, 'app');
const nav = fs.readFileSync(path.join(root, 'components/app-shell.tsx'), 'utf8');
for (const found of nav.matchAll(/href: '(\/[^']*)'/g)) {
  const route = found[1];
  const f = path.join(app, route.slice(1), 'page.tsx');
  if (!isFile(f)) errors.push(`Navigation route ${route} has no app page`);
}
const rootLayout = fs.readFileSync(path.join(app, 'layout.tsx'), 'utf8');
const alertsPage = fs.readFileSync(path.join(app, 'alerts/page.tsx'), 'utf8');
const provider = fs.readFileSync(path.join(root, 'lib/global-alerts-context.tsx'), 'utf8');
if (!rootLayout.includes('<GlobalAlertsProvider>') || !alertsPage.includes('useGlobalAlerts()') || !provider.includes('useAlertEngine('))
  errors.push('Global Alerts must be provided by the persistent root layout and consumed by Alerts page');
const toast = fs.readFileSync(path.join(root, 'components/alert-toast.tsx'), 'utf8');
if (!toast.includes('z-[100]')) errors.push('War TV overlay may obscure global toast');
for (const sql of ['20261026170000_battle_command_and_frag_guard.sql', '20261026185000_team_rally_quality.sql', '20261027140000_captain_supplies_after_battle.sql']) {
  if (!isFile(path.join(root, 'supabase/migrations', sql))) errors.push(`Missing new SQL migration ${sql}`);
}
if (isFile(path.join(root, '.env'))) errors.push('Unsafe: .env must not be in distribution');
const summary = { tsTsxFiles: files.length, localImports: imports, pages: [...new Set([...nav.matchAll(/href: '(\/[^']*)'/g)].map(a => a[1]))].length, failures: errors.length };
console.log('Everlast Final Polish preflight', summary);
errors.forEach(x => console.error('ERROR', x));
if (errors.length) process.exitCode = 1;
