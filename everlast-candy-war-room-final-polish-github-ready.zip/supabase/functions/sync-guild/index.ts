// sync-guild — fetches guild rosters + world online status from TibiaData.
// Syncs Everlast, Terror Squad (ally), and Mandatory Again (enemy) on Sinistra.
// Updates character records, records activity snapshots, and repopulates the
// sync_queue with priority based on online status and level changes.

import { createClient } from "npm:@supabase/supabase-js@2.58.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const TIBIADATA_BASE = "https://api.tibiadata.com/v5";
const WORLD = "Sinistra";
const GUILD_EVERLAST = "Everlast";
const GUILD_ALLY = "Terror Squad";
const GUILD_ENEMY = "Mandatory Again";

interface TibiaDataGuildMember {
  name: string;
  title: string;
  rank: string;
  vocation: string;
  level: number;
  joined: string;
  status: string;
}

interface TibiaDataGuildResponse {
  guild: {
    name: string;
    world: string;
    members: TibiaDataGuildMember[];
    players_online: number;
    players_offline: number;
    members_total: number;
  };
}

interface TibiaDataWorldResponse {
  world: {
    name: string;
    online_players: { name: string; level: number; vocation: string }[];
  };
}

function getSupabase() {
  const url = Deno.env.get("SUPABASE_URL") ?? Deno.env.get("NEXT_PUBLIC_SUPABASE_URL");
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false } });
}

async function tibiadataFetch(path: string): Promise<any | null> {
  const headers: Record<string, string> = { "Accept": "application/json" };
  const apiKey = Deno.env.get("TIBIADATA_API_KEY");
  if (apiKey) headers["Authorization"] = `Bearer ${apiKey}`;
  try {
    const resp = await fetch(`${TIBIADATA_BASE}${path}`, { headers });
    if (!resp.ok) {
      console.error(`TibiaData ${path} returned ${resp.status}`);
      return null;
    }
    return await resp.json();
  } catch {
    return null;
  }
}

const GUILD_CONFIG: { name: string; side: string; alliance: string | null; displayLabel: string }[] = [
  { name: GUILD_EVERLAST, side: "everlast", alliance: "Everlast Alliance", displayLabel: "Everlast" },
  { name: GUILD_ALLY, side: "ally", alliance: "Everlast Alliance", displayLabel: "Terrory" },
  { name: GUILD_ENEMY, side: "enemy", alliance: null, displayLabel: "Mandatory Again" },
];

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = getSupabase();
    if (!supabase) {
      return new Response(JSON.stringify({ error: "Server not configured" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const logStart = await supabase.from("sync_log").insert({
      job: "sync_guilds", status: "running", started_at: new Date().toISOString(),
    }).select("id").single();
    const logId = logStart.data?.id;

    const [everlastData, allyData, enemyData, worldData] = await Promise.all([
      tibiadataFetch(`/guild/${encodeURIComponent(GUILD_EVERLAST)}`),
      tibiadataFetch(`/guild/${encodeURIComponent(GUILD_ALLY)}`),
      tibiadataFetch(`/guild/${encodeURIComponent(GUILD_ENEMY)}`),
      tibiadataFetch(`/world/${WORLD}`),
    ]);

    const onlineNames = new Set<string>();
    if (worldData?.world?.online_players) {
      for (const p of worldData.world.online_players) {
        onlineNames.add(p.name);
      }
    }

    const guildDataMap: Record<string, any> = {
      [GUILD_EVERLAST]: everlastData,
      [GUILD_ALLY]: allyData,
      [GUILD_ENEMY]: enemyData,
    };

    let totalMembers = 0;
    const onlineByGuild: Record<string, number> = {};
    let levelChanges = 0;
    const nowIso = new Date().toISOString();
    const queueEntries: { character_id: string | null; character_name: string; side: string; priority: number }[] = [];

    for (const cfg of GUILD_CONFIG) {
      const data = guildDataMap[cfg.name];
      if (!data?.guild?.members) {
        console.error(`No members for ${cfg.name}`);
        continue;
      }

      const guild = data.guild;

      // Verify guild belongs to Sinistra
      if (guild.world && guild.world !== WORLD) {
        console.error(`Guild ${cfg.name} is on ${guild.world}, expected ${WORLD}`);
        continue;
      }

      const { data: guildRow } = await supabase.from("guilds").upsert({
        name: guild.name,
        world: guild.world ?? WORLD,
        side: cfg.side,
        alliance: cfg.alliance,
        display_label: cfg.displayLabel,
        member_count: guild.members_total ?? guild.members.length,
        last_synced_at: nowIso,
        updated_at: nowIso,
      }, { onConflict: "name" }).select("id").single();

      const guildId = guildRow?.id;
      if (!guildId) continue;

      const { data: existing } = await supabase
        .from("characters")
        .select("id, name, level, previous_level, last_observed_level, online")
        .eq("guild_name", cfg.name);

      const existingMap = new Map((existing ?? []).map((c) => [c.name, c]));

      const members = guild.members;
      let guildOnline = 0;

      for (const member of members) {
        const isOnline = onlineNames.has(member.name);
        if (isOnline) guildOnline++;

        const prev = existingMap.get(member.name);
        const prevObserved = prev?.last_observed_level ?? prev?.level ?? null;

        // Record level change if level differs from last observation
        if (prevObserved != null && member.level !== prevObserved) {
          const diff = member.level - prevObserved;
          if (diff !== 0) {
            await supabase.from("character_level_events").insert({
              character_id: prev?.id ?? null,
              character_name: member.name,
              previous_level: prevObserved,
              new_level: member.level,
              level_diff: diff,
              observed_at: nowIso,
              source: "tibiadata",
              world: WORLD,
            }).select("id").maybeSingle();
            levelChanges++;
          }
        }

        await supabase.from("characters").upsert({
          name: member.name,
          world: WORLD,
          vocation: member.vocation,
          level: member.level,
          guild_id: guildId,
          guild_name: cfg.name,
          side: cfg.side,
          rank: member.rank,
          online: isOnline,
          last_seen_at: isOnline ? nowIso : (prev?.last_seen_at ?? null),
          last_observed_level: member.level,
          previous_level: prevObserved,
          deleted: false,
          updated_at: nowIso,
        }, { onConflict: "name" });

        let priority = 5;
        if (isOnline) priority = 0;
        else if (prevObserved != null && member.level !== prevObserved) priority = 1;

        const charId = prev?.id ?? null;
        queueEntries.push({ character_id: charId, character_name: member.name, side: cfg.side, priority });

        totalMembers++;
      }

      onlineByGuild[cfg.name] = guildOnline;

      // Mark characters that left the guild
      const memberNames = new Set(members.map((m) => m.name));
      for (const ex of existing ?? []) {
        if (!memberNames.has(ex.name)) {
          await supabase.from("characters")
            .update({ guild_id: null, guild_name: null, side: "neutral", updated_at: nowIso })
            .eq("id", ex.id);
        }
      }

      // Record activity snapshot
      await supabase.from("activity_snapshots").insert({
        guild_id: guildId,
        guild_name: cfg.name,
        side: cfg.side,
        online_count: guildOnline,
        total_members: guild.members_total ?? members.length,
        snapshot_at: nowIso,
      });
    }

    // Upsert queue entries — only update priority/side, preserve processing state
    // (status, attempts, last_attempted_at, last_cached_at) so sync-deaths progress
    // is not wiped every 2 minutes.
    for (const entry of queueEntries) {
      if (!entry.character_id) continue;
      await supabase.from("sync_queue").upsert({
        character_id: entry.character_id,
        character_name: entry.character_name,
        side: entry.side,
        priority: entry.priority,
        updated_at: nowIso,
      }, { onConflict: "character_id" });
    }

    const elOnline = onlineByGuild[GUILD_EVERLAST] ?? 0;
    const allyOnline = onlineByGuild[GUILD_ALLY] ?? 0;
    const enemyOnline = onlineByGuild[GUILD_ENEMY] ?? 0;

    await supabase.from("sync_log").update({
      status: "success",
      message: `Synced ${totalMembers} members. EL online: ${elOnline}, TS online: ${allyOnline}, MA online: ${enemyOnline}. ${levelChanges} level changes. Queue: ${queueEntries.length} entries.`,
      records_processed: totalMembers,
      finished_at: new Date().toISOString(),
    }).eq("id", logId);

    return new Response(JSON.stringify({
      success: true,
      totalMembers,
      everlastOnline: elOnline,
      allyOnline,
      enemyOnline,
      worldOnline: onlineNames.size,
      levelChanges,
      queueSize: queueEntries.length,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message ?? "Internal error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
