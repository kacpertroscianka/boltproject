// tibiadata-proxy — proxies TibiaData API calls from the frontend
// Keeps any API keys server-side and applies rate-limit headers.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const TIBIADATA_BASE = "https://api.tibiadata.com/v5";

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const path = url.searchParams.get("path");
    if (!path) {
      return new Response(JSON.stringify({ error: "Missing 'path' query parameter" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Only allow safe TibiaData v4 paths
    if (!path.startsWith("/") || path.includes("..")) {
      return new Response(JSON.stringify({ error: "Invalid path" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const targetUrl = `${TIBIADATA_BASE}${path}`;
    const response = await fetch(targetUrl, {
      headers: {
        "Accept": "application/json",
        // TibiaData may require an API key header if configured
        ...(Deno.env.get("TIBIADATA_API_KEY")
          ? { "Authorization": `Bearer ${Deno.env.get("TIBIADATA_API_KEY")}` }
          : {}),
      },
    });

    if (!response.ok) {
      return new Response(
        JSON.stringify({ error: `TibiaData API returned ${response.status}`, unavailable: true }),
        {
          status: response.status,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        },
      );
    }

    const data = await response.json();
    return new Response(JSON.stringify(data), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message ?? "Internal error", unavailable: true }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
