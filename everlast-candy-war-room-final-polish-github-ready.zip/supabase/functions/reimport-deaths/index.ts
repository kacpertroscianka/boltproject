// reimport-deaths — clean reimport of character death data from TibiaData v5.
// Processes characters from the existing characters table in resumable batches.
// Each invocation processes a small batch (5 chars) to stay within the
// 60-second edge function timeout. Call repeatedly until complete=true.

import { createClient } from "npm:@supabase/supabase-js@2.58.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const TIBIADATA_BASE = "https://api.tibiadata.com/v5";
const BATCH_SIZE = 5;
const DELAY_MS = 1100;

interface TibiaKiller {
  name: string;
  player: boolean;
  vocation?: string;
  level?: number;
  summon?: string;
  traded?: boolean;
}

interface TibiaDeath {
  time: string;
  level: number;
  reason: string;
  killers: TibiaKiller[];
  assists?: TibiaKiller[];
}

interface TibiaCharacterResponse {
  character: {
    character: {
      name: string;
      level: number;
      vocation: string;
      world: string;
    };
    deaths: TibiaDeath[];
    deaths_truncated?: boolean;
  };
}

function getSupabase() {
  const url = Deno.env.get("SUPABASE_URL") ?? Deno.env.get("NEXT_PUBLIC_SUPABASE_URL");
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false } });
}

async function tibiadataFetch(path: string): Promise<any | null> {
  const headers: Record<string, string> = { "Accept": "application/json" };
  const apiKey = Deno.env.get("TIBIADATA_API_KEY");
  if (apiKey) headers["Authorization"] = `Bearer ${apiKey}`;
  try {
    const resp = await fetch(`${TIBIADATA_BASE}${path}`, { headers });
    if (!resp.ok) return null;
    return await resp.json();
  } catch {
    return null;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = getSupabase();
    if (!supabase) {
      return new Response(JSON.stringify({ error: "Server not configured" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get all war guild characters from the existing roster
    const { data: roster } = await supabase
      .from("characters")
      .select("id, name, side, guild_name, vocation, level")
      .in("side", ["everlast", "ally", "enemy"])
      .order("level", { ascending: false });

    if (!roster || roster.length === 0) {
      return new Response(JSON.stringify({ error: "No roster characters found" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Find which characters haven't been scanned yet
    const { data: scanned } = await supabase
      .from("staging_scan_log")
      .select("character_name")
      .in("status", ["done", "failed"]);
    const scannedSet = new Set((scanned ?? []).map((s) => s.character_name.toLowerCase()));

    const toProcess = roster.filter((c) => !scannedSet.has(c.name.toLowerCase())).slice(0, BATCH_SIZE);

    if (toProcess.length === 0) {
      const { count: totalDeaths } = await supabase
        .from("staging_death_events")
        .select("*", { count: "exact", head: true });
      const { data: doneScans } = await supabase
        .from("staging_scan_log")
        .select("status")
        .eq("status", "done");
      const { data: failedScans } = await supabase
        .from("staging_scan_log")
        .select("character_name, error_message")
        .eq("status", "failed");

      return new Response(JSON.stringify({
        complete: true,
        rosterTotal: roster.length,
        charactersScanned: doneScans?.length ?? 0,
        charactersFailed: failedScans?.length ?? 0,
        failedDetails: failedScans ?? [],
        totalDeathsImported: totalDeaths ?? 0,
      }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Build killer lookup from roster
    const charLookup = new Map<string, { side: string; guild_name: string | null; vocation: string | null; level: number | null }>();
    for (const c of roster) {
      charLookup.set(c.name, { side: c.side, guild_name: c.guild_name, vocation: c.vocation, level: c.level });
    }

    let success = 0;
    let failed = 0;
    let deathsImported = 0;

    for (const char of toProcess) {
      try {
        const data = await tibiadataFetch(`/character/${encodeURIComponent(char.name)}`) as TibiaCharacterResponse | null;

        if (!data?.character?.character) {
          await supabase.from("staging_scan_log").upsert({
            character_name: char.name,
            guild: char.guild_name,
            side: char.side,
            status: "failed",
            error_message: "No data returned from API",
            scanned_at: new Date().toISOString(),
          }, { onConflict: "character_name" });
          failed++;
          await new Promise((r) => setTimeout(r, DELAY_MS));
          continue;
        }

        const ch = data.character.character;
        const deaths = data.character.deaths ?? [];

        // Set verified level baseline (no invented history)
        await supabase.from("characters").update({
          last_observed_level: ch.level,
          previous_level: ch.level,
          level: ch.level,
          vocation: ch.vocation,
          updated_at: new Date().toISOString(),
        }).eq("id", char.id);

        for (const death of deaths) {
          const playerKillers = death.killers.filter((k) => k.player === true && k.name !== char.name);
          const playerAssists = (death.assists ?? []).filter((k) => k.player === true && k.name !== char.name);
          const isPvp = playerKillers.length > 0;
          const primaryKiller = playerKillers[0] ?? null;
          const reason = death.reason?.trim() || (playerKillers.length > 0
            ? `Killed by ${playerKillers.map((k) => k.name).join(", ")}`
            : `Died at level ${death.level}`);

          let killerSide: string | null = null;
          let killerGuildName: string | null = null;
          let killerVocation: string | null = null;
          let killerLevel: number | null = null;
          if (primaryKiller) {
            const ki = charLookup.get(primaryKiller.name);
            if (ki) { killerSide = ki.side; killerGuildName = ki.guild_name; killerVocation = ki.vocation; killerLevel = ki.level; }
          }

          const killersJson = death.killers.map((k) => ({ name: k.name, player: k.player, summon: k.summon ?? "", traded: k.traded ?? false }));
          const assistsJson = (death.assists ?? []).map((k) => ({ name: k.name, player: k.player, summon: k.summon ?? "", traded: k.traded ?? false }));

          const { error } = await supabase.from("staging_death_events").upsert({
            character_id: char.id,
            character_name: char.name,
            character_level: death.level,
            character_vocation: ch.vocation,
            character_side: char.side as any,
            killer_name: primaryKiller?.name ?? null,
            killer_vocation: killerVocation,
            killer_level: killerLevel,
            killer_guild_name: killerGuildName,
            killer_side: killerSide as any,
            reason,
            is_pvp: isPvp,
            is_player_kill: isPvp,
            death_time: death.time,
            killers: killersJson,
            assists: assistsJson,
            participated_players: playerKillers.map((k) => k.name),
            assisted_players: playerAssists.map((k) => k.name),
            source: "tibiadata-v5-reimport",
            world: ch.world,
            updated_at: new Date().toISOString(),
          }, { onConflict: "character_name,death_time" });

          if (!error) deathsImported++;
        }

        await supabase.from("staging_scan_log").upsert({
          character_name: char.name,
          guild: char.guild_name,
          side: char.side,
          status: "done",
          deaths_found: deaths.length,
          deaths_truncated: data.character.deaths_truncated ?? false,
          character_level: ch.level,
          scanned_at: new Date().toISOString(),
        }, { onConflict: "character_name" });

        success++;
      } catch (err) {
        await supabase.from("staging_scan_log").upsert({
          character_name: char.name,
          guild: char.guild_name,
          side: char.side,
          status: "failed",
          error_message: err.message?.slice(0, 200) ?? "Unknown error",
          scanned_at: new Date().toISOString(),
        }, { onConflict: "character_name" });
        failed++;
      }
      await new Promise((r) => setTimeout(r, DELAY_MS));
    }

    const totalScanned = scannedSet.size + success + failed;

    return new Response(JSON.stringify({
      complete: false,
      rosterTotal: roster.length,
      processedThisBatch: success + failed,
      successThisBatch: success,
      failedThisBatch: failed,
      deathsImportedThisBatch: deathsImported,
      totalScannedSoFar: totalScanned,
      remaining: roster.length - totalScanned,
      invokeAgain: true,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message ?? "Internal error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
