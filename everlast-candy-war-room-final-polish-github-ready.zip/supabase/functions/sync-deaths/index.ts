// sync-deaths — batched death + level monitoring from TibiaData API.
// Processes characters from a persistent queue (sync_queue table).
// Each invocation grabs a batch of pending characters, fetches their
// death data from TibiaData, upserts into canonical_death_events
// (idempotent via unique constraint on character_name + death_time),
// records level changes, and marks queue items done.
//
// KEY FIXES (v2):
// - Uses death.reason (not death.cause) — the API field is "reason"
// - Stores full killers AND assists arrays separately
// - Writes to canonical_death_events with ON CONFLICT DO UPDATE
// - Participated players = player killers only; assisted players = player assists only
// - The victim is excluded from the killer list for PvP classification

import { createClient } from "npm:@supabase/supabase-js@2.58.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const TIBIADATA_BASE = "https://api.tibiadata.com/v5";
const CACHE_TTL_MS = 5 * 60 * 1000;
const BATCH_SIZE = 20;
const DELAY_MS = 1100;

interface TibiaKiller {
  name: string;
  player: boolean;
  vocation?: string;
  level?: number;
  summon?: string;
  traded?: boolean;
}

interface TibiaDeath {
  time: string;
  level: number;
  reason: string;
  killers: TibiaKiller[];
  assists?: TibiaKiller[];
}

interface TibiaCharacterResponse {
  character: {
    character: {
      name: string;
      level: number;
      vocation: string;
      world: string;
      guild?: { name: string; rank: string };
    };
    deaths: TibiaDeath[];
    deaths_truncated?: boolean;
  };
}

function getSupabase() {
  const url = Deno.env.get("SUPABASE_URL") ?? Deno.env.get("NEXT_PUBLIC_SUPABASE_URL");
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false } });
}

async function tibiadataFetch(path: string): Promise<any | null> {
  const headers: Record<string, string> = { "Accept": "application/json" };
  const apiKey = Deno.env.get("TIBIADATA_API_KEY");
  if (apiKey) headers["Authorization"] = `Bearer ${apiKey}`;
  try {
    const resp = await fetch(`${TIBIADATA_BASE}${path}`, { headers });
    if (!resp.ok) return null;
    return await resp.json();
  } catch {
    return null;
  }
}

function classifyDeath(death: TibiaDeath, characterName: string): {
  isPvp: boolean;
  isPlayerKill: boolean;
  killerName: string | null;
  killerVocation: string | null;
  killerLevel: number | null;
  reason: string;
  playerKillers: string[];
  playerAssists: string[];
  killersJson: object[];
  assistsJson: object[];
} {
  const playerKillers = death.killers.filter(
    (k) => k.player === true && k.name !== characterName,
  );
  const playerAssists = (death.assists ?? []).filter(
    (k) => k.player === true && k.name !== characterName,
  );
  const isPvp = playerKillers.length > 0;
  const isPlayerKill = isPvp;

  const primaryKiller = playerKillers[0] ?? null;

  const reason = death.reason && death.reason.trim()
    ? death.reason
    : playerKillers.length > 0
      ? `Killed by ${playerKillers.map((k) => k.name).join(", ")}`
      : `Died at level ${death.level}`;

  const killersJson = death.killers.map((k) => ({
    name: k.name,
    player: k.player,
    summon: k.summon ?? "",
    traded: k.traded ?? false,
  }));

  const assistsJson = (death.assists ?? []).map((k) => ({
    name: k.name,
    player: k.player,
    summon: k.summon ?? "",
    traded: k.traded ?? false,
  }));

  return {
    isPvp,
    isPlayerKill,
    killerName: primaryKiller?.name ?? null,
    killerVocation: primaryKiller?.vocation ?? null,
    killerLevel: primaryKiller?.level ?? null,
    reason,
    playerKillers: playerKillers.map((k) => k.name),
    playerAssists: playerAssists.map((k) => k.name),
    killersJson,
    assistsJson,
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = getSupabase();
    if (!supabase) {
      return new Response(JSON.stringify({ error: "Server not configured" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const logStart = await supabase.from("sync_log").insert({
      job: "sync_deaths", status: "running", started_at: new Date().toISOString(),
    }).select("id").single();
    const logId = logStart.data?.id;

    const tenMinAgo = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    await supabase.from("sync_queue")
      .update({ status: "pending", error_message: "Recovered from stale in_progress" })
      .eq("status", "in_progress")
      .lt("updated_at", tenMinAgo);

    const now = new Date();
    const cacheCutoff = new Date(now.getTime() - CACHE_TTL_MS).toISOString();

    const { data: batch } = await supabase
      .from("sync_queue")
      .select("id, character_id, character_name, side, priority, attempts")
      .eq("status", "pending")
      .in("side", ["everlast", "ally", "enemy"])
      .or(`last_cached_at.is.null,last_cached_at.lt.${cacheCutoff}`)
      .order("priority", { ascending: true })
      .order("updated_at", { ascending: true })
      .limit(BATCH_SIZE);

    if (!batch || batch.length === 0) {
      await supabase.from("sync_log").update({
        status: "success", message: "No characters due for refresh",
        records_processed: 0, finished_at: new Date().toISOString(),
      }).eq("id", logId);
      return new Response(JSON.stringify({ synced: 0, newDeaths: 0, queueEmpty: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const batchIds = batch.map((b) => b.id);
    await supabase.from("sync_queue")
      .update({ status: "in_progress", updated_at: new Date().toISOString() })
      .in("id", batchIds);

    const { data: allChars } = await supabase
      .from("characters")
      .select("name, side, guild_name, vocation, level")
      .in("side", ["everlast", "ally", "enemy"]);

    const charLookup = new Map<string, { side: string; guild_name: string | null; vocation: string | null; level: number | null }>();
    for (const c of allChars ?? []) {
      charLookup.set(c.name, { side: c.side, guild_name: c.guild_name, vocation: c.vocation, level: c.level });
    }

    let totalProcessed = 0;
    let newDeaths = 0;
    let levelChanges = 0;
    let errors = 0;

    for (const item of batch) {
      try {
        const data = await tibiadataFetch(`/character/${encodeURIComponent(item.character_name)}`) as TibiaCharacterResponse | null;

        if (!data?.character?.character) {
          await supabase.from("sync_queue").update({
            status: "done",
            last_attempted_at: new Date().toISOString(),
            last_cached_at: new Date().toISOString(),
            attempts: (item.attempts ?? 0) + 1,
            error_message: "No data returned",
            updated_at: new Date().toISOString(),
          }).eq("id", item.id);
          totalProcessed++;
          await new Promise((r) => setTimeout(r, DELAY_MS));
          continue;
        }

        const charInfo = data.character.character;
        const deaths = data.character.deaths ?? [];
        const nowIso = new Date().toISOString();

        const { data: currentChar } = await supabase
          .from("characters")
          .select("id, level, last_observed_level, previous_level, vocation")
          .eq("id", item.character_id)
          .maybeSingle();

        if (currentChar && currentChar.last_observed_level != null && charInfo.level !== currentChar.last_observed_level) {
          const prevLevel = currentChar.last_observed_level;
          const newLevel = charInfo.level;
          const diff = newLevel - prevLevel;

          if (diff !== 0) {
            await supabase.from("character_level_events").insert({
              character_id: item.character_id,
              character_name: item.character_name,
              previous_level: prevLevel,
              new_level: newLevel,
              level_diff: diff,
              observed_at: nowIso,
              source: "tibiadata",
              world: "Sinistra",
            }).select("id").maybeSingle();
            levelChanges++;
          }
        }

        if (currentChar) {
          const prevObserved = currentChar.last_observed_level ?? currentChar.level ?? charInfo.level;
          await supabase.from("characters").update({
            previous_level: prevObserved,
            last_observed_level: charInfo.level,
            level: charInfo.level,
            vocation: charInfo.vocation,
            updated_at: nowIso,
          }).eq("id", item.character_id);
        }

        for (const death of deaths) {
          const classified = classifyDeath(death, item.character_name);
          const deathTime = death.time;

          let killerSide: string | null = null;
          let killerGuildName: string | null = null;
          let killerVocation: string | null = classified.killerVocation;
          let killerLevel: number | null = classified.killerLevel;

          if (classified.killerName) {
            const killerInfo = charLookup.get(classified.killerName);
            if (killerInfo) {
              killerSide = killerInfo.side;
              killerGuildName = killerInfo.guild_name;
              killerVocation = killerVocation ?? killerInfo.vocation;
              killerLevel = killerLevel ?? killerInfo.level;
            }
          }

          // Upsert to canonical_death_events — idempotent via unique constraint
          const { error } = await supabase
            .from("canonical_death_events")
            .upsert({
              character_id: item.character_id,
              character_name: item.character_name,
              character_level: death.level,
              character_vocation: charInfo.vocation,
              character_side: item.side,
              killer_name: classified.killerName,
              killer_vocation: killerVocation,
              killer_level: killerLevel,
              killer_guild_name: killerGuildName,
              killer_side: killerSide as any,
              reason: classified.reason,
              is_pvp: classified.isPvp,
              is_player_kill: classified.isPlayerKill,
              death_time: deathTime,
              killers: classified.killersJson,
              assists: classified.assistsJson,
              participated_players: classified.playerKillers,
              assisted_players: classified.playerAssists,
              source: "tibiadata",
              world: charInfo.world,
              updated_at: nowIso,
            }, {
              onConflict: "character_name,death_time",
            });

          if (!error) {
            newDeaths++;
          }
        }

        await supabase.from("sync_queue").update({
          status: "done",
          last_attempted_at: nowIso,
          last_cached_at: nowIso,
          attempts: (item.attempts ?? 0) + 1,
          error_message: null,
          updated_at: nowIso,
        }).eq("id", item.id);

        totalProcessed++;
        await new Promise((r) => setTimeout(r, DELAY_MS));
      } catch (err) {
        console.error(`Error syncing ${item.character_name}:`, err.message);
        errors++;
        await supabase.from("sync_queue").update({
          status: "pending",
          attempts: (item.attempts ?? 0) + 1,
          error_message: err.message?.slice(0, 200) ?? "Unknown error",
          updated_at: new Date().toISOString(),
        }).eq("id", item.id);
        totalProcessed++;
      }
    }

    await supabase.from("sync_queue")
      .update({ status: "pending", updated_at: new Date().toISOString() })
      .eq("status", "done")
      .in("id", batchIds);

    await supabase.from("sync_log").update({
      status: "success",
      message: `Processed ${totalProcessed} characters, ${newDeaths} deaths, ${levelChanges} level changes, ${errors} errors`,
      records_processed: newDeaths,
      finished_at: new Date().toISOString(),
    }).eq("id", logId);

    return new Response(JSON.stringify({
      synced: totalProcessed,
      newDeaths,
      levelChanges,
      errors,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message ?? "Internal error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
