/*
# Add canonical_death_events to Supabase Realtime publication

The table was renamed from staging_death_events to canonical_death_events
during the cutover, so it needs to be added to the Realtime publication
to support live updates in the dashboard.
*/
ALTER PUBLICATION supabase_realtime ADD TABLE canonical_death_events;
