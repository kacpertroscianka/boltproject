/*
# Create backup and staging tables for clean reimport

## Purpose
1. Creates backup snapshots of canonical_death_events, death_events, 
   character_level_events, and characters tables — all prefixed with `backup_`
   so the original data can be restored if the reimport fails.
2. Creates `staging_death_events` — an isolated table for the fresh import
   that will NOT mix with production data until validated and cut over.

## Backup tables (created via SELECT INTO, preserving all existing data)
- backup_canonical_death_events_20261025
- backup_death_events_20261025
- backup_character_level_events_20261025
- backup_characters_20261025

## Staging table
- staging_death_events — same schema as canonical_death_events
  Used for the fresh import. After validation, we swap this into production
  by renaming canonical_death_events → canonical_death_events_old and
  staging_death_events → canonical_death_events.
*/
-- Backups: created with SELECT INTO (only runs if table doesn't exist)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'backup_canonical_death_events_20261025') THEN
    CREATE TABLE backup_canonical_death_events_20261025 AS SELECT * FROM canonical_death_events;
    ALTER TABLE backup_canonical_death_events_20261025 ENABLE ROW LEVEL SECURITY;
    GRANT SELECT ON backup_canonical_death_events_20261025 TO anon, authenticated, service_role;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'backup_death_events_20261025') THEN
    CREATE TABLE backup_death_events_20261025 AS SELECT * FROM death_events;
    ALTER TABLE backup_death_events_20261025 ENABLE ROW LEVEL SECURITY;
    GRANT SELECT ON backup_death_events_20261025 TO anon, authenticated, service_role;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'backup_character_level_events_20261025') THEN
    CREATE TABLE backup_character_level_events_20261025 AS SELECT * FROM character_level_events;
    ALTER TABLE backup_character_level_events_20261025 ENABLE ROW LEVEL SECURITY;
    GRANT SELECT ON backup_character_level_events_20261025 TO anon, authenticated, service_role;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'backup_characters_20261025') THEN
    CREATE TABLE backup_characters_20261025 AS SELECT * FROM characters;
    ALTER TABLE backup_characters_20261025 ENABLE ROW LEVEL SECURITY;
    GRANT SELECT ON backup_characters_20261025 TO anon, authenticated, service_role;
  END IF;
END $$;

-- Staging table: same structure as canonical_death_events
CREATE TABLE IF NOT EXISTS staging_death_events (
  LIKE canonical_death_events INCLUDING ALL
);

ALTER TABLE staging_death_events ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON staging_death_events TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "anon_select_staging_deaths" ON staging_death_events;
CREATE POLICY "anon_select_staging_deaths" ON staging_death_events FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_staging_deaths" ON staging_death_events;
CREATE POLICY "anon_insert_staging_deaths" ON staging_death_events FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_staging_deaths" ON staging_death_events;
CREATE POLICY "anon_update_staging_deaths" ON staging_death_events FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_staging_deaths" ON staging_death_events;
CREATE POLICY "anon_delete_staging_deaths" ON staging_death_events FOR DELETE
  TO anon, authenticated USING (true);
