/*
# Create canonical war events view and war_attribution function

## Purpose
Create a database view that deduplicates death_events and classifies each
unique death with war attribution confidence levels. This is the single
source of truth for war score calculations, replacing the previous
application-level computeWarScore which counted duplicate rows.

## New Objects

### View: canonical_war_events
Deduplicates death_events by (character_name, death_time), keeping the
most recently created row. Adds computed columns:
- victim_guild: current guild of the victim (from characters table)
- killer_guild: current guild of the killer (from characters table)
- killer_current_side: current side of the killer
- attribution: 'confirmed' | 'inferred' | 'ambiguous' | 'unknown' | 'same_alliance' | 'pve'
- war_category: 'friendly_kills_enemy' | 'enemy_kills_friendly' | 'excluded'
- participant_count: number of player participants

### Attribution Rules
1. confirmed: killer_side and character_side are both set to opposing war alliances
   (friendly=everlast+ally, enemy=enemy). Uses stored killer_side which was set
   at sync time using current guild membership.
2. inferred: killer_side is null/neutral but killer_name matches a current war
   guild member. Guild attribution is inferred from current membership, not
   verified at death time.
3. ambiguous: killer is a player but not in any war guild, or killer_side
   conflicts with current membership.
4. same_alliance: killer and victim are both in the friendly alliance.
5. pve: not a player kill.
6. unknown: killer_side is null and killer is not in any war guild.

## Security
- Grant SELECT on the view to anon and authenticated (no-auth app, public data)
- The view is read-only (computed from death_events + characters)
*/

CREATE OR REPLACE VIEW canonical_war_events AS
WITH deduped AS (
  SELECT DISTINCT ON (character_name, death_time) *
  FROM death_events
  ORDER BY character_name, death_time, created_at DESC
)
SELECT
  d.id AS event_id,
  d.character_id,
  d.character_name,
  d.character_level,
  d.character_vocation,
  d.character_side,
  d.killer_name,
  d.killer_vocation,
  d.killer_level,
  d.killer_guild_name AS stored_killer_guild,
  d.killer_side AS stored_killer_side,
  d.cause,
  d.is_pvp,
  d.is_player_kill,
  d.death_time,
  d.participated_players,
  d.source,
  d.created_at,
  -- Current guild membership (not historical)
  c_victim.guild_name AS victim_guild,
  c_victim.side AS victim_current_side,
  c_killer.guild_name AS killer_current_guild,
  c_killer.side AS killer_current_side,
  -- Attribution confidence
  CASE
    WHEN NOT d.is_player_kill THEN 'pve'
    WHEN d.killer_side IN ('everlast','ally') AND d.character_side IN ('everlast','ally') THEN 'same_alliance'
    WHEN d.killer_side IN ('everlast','ally') AND d.character_side = 'enemy' THEN 'confirmed'
    WHEN d.killer_side = 'enemy' AND d.character_side IN ('everlast','ally') THEN 'confirmed'
    WHEN (d.killer_side IS NULL OR d.killer_side = 'neutral') AND c_killer.side IN ('everlast','ally','enemy') THEN 'inferred'
    ELSE 'unknown'
  END AS attribution,
  -- War category
  CASE
    WHEN NOT d.is_player_kill THEN 'pve'
    WHEN d.killer_side IN ('everlast','ally') AND d.character_side IN ('everlast','ally') THEN 'same_alliance'
    WHEN d.killer_side IN ('everlast','ally') AND d.character_side = 'enemy' THEN 'friendly_kills_enemy'
    WHEN d.killer_side = 'enemy' AND d.character_side IN ('everlast','ally') THEN 'enemy_kills_friendly'
    WHEN (d.killer_side IS NULL OR d.killer_side = 'neutral') AND c_killer.side IN ('everlast','ally') AND d.character_side = 'enemy' THEN 'friendly_kills_enemy_inferred'
    WHEN (d.killer_side IS NULL OR d.killer_side = 'neutral') AND c_killer.side = 'enemy' AND d.character_side IN ('everlast','ally') THEN 'enemy_kills_friendly_inferred'
    ELSE 'excluded'
  END AS war_category,
  -- Participant count
  COALESCE(jsonb_array_length(
    CASE 
      WHEN jsonb_typeof(d.participated_players::jsonb) = 'array' 
      THEN d.participated_players::jsonb 
      ELSE '[]'::jsonb 
    END
  ), 0) AS participant_count
FROM deduped d
LEFT JOIN characters c_victim ON c_victim.name = d.character_name
LEFT JOIN characters c_killer ON c_killer.name = d.killer_name;

GRANT SELECT ON canonical_war_events TO anon, authenticated;
