/*
# Safe cutover: replace canonical_death_events with staging_death_events

## What this does
1. Renames the current canonical_death_events to canonical_death_events_old
   (preserving the old data as a recoverable backup)
2. Renames staging_death_events to canonical_death_events
   (making the fresh import the production dataset)
3. Re-creates the staging_scan_log as-is (no changes needed)
4. Grants and RLS are already on the staging table (it was created with
   LIKE canonical_death_events INCLUDING ALL, which copies indexes,
   constraints, and defaults — but NOT RLS or grants, so we re-apply them)

## Recovery
If the fresh dataset has issues, run:
  ALTER TABLE canonical_death_events RENAME TO canonical_death_events_fresh;
  ALTER TABLE canonical_death_events_old RENAME TO canonical_death_events;
The old data is also preserved in backup_canonical_death_events_20261025.
*/
-- Rename current canonical to _old
ALTER TABLE canonical_death_events RENAME TO canonical_death_events_old;

-- Rename staging to canonical
ALTER TABLE staging_death_events RENAME TO canonical_death_events;

-- Re-enable RLS and grants on the new canonical table
ALTER TABLE canonical_death_events ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON canonical_death_events TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON canonical_death_events TO service_role;

DROP POLICY IF EXISTS "anon_select_canonical_deaths" ON canonical_death_events;
CREATE POLICY "anon_select_canonical_deaths" ON canonical_death_events FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_canonical_deaths" ON canonical_death_events;
CREATE POLICY "anon_insert_canonical_deaths" ON canonical_death_events FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_canonical_deaths" ON canonical_death_events;
CREATE POLICY "anon_update_canonical_deaths" ON canonical_death_events FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);
DROP POLICY IF EXISTS "anon_delete_canonical_deaths" ON canonical_death_events;
CREATE POLICY "anon_delete_canonical_deaths" ON canonical_death_events FOR DELETE
  TO anon, authenticated USING (true);

-- RLS on the old table (read-only backup)
ALTER TABLE canonical_death_events_old ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON canonical_death_events_old TO anon, authenticated, service_role;

-- Rebuild the canonical_war_events view to read from the new canonical table
DROP VIEW IF EXISTS canonical_war_events;

CREATE VIEW canonical_war_events AS
SELECT
  c.id AS event_id,
  c.character_id,
  c.character_name,
  c.character_level,
  c.character_vocation,
  c.character_side,
  c.killer_name,
  c.killer_vocation,
  c.killer_level,
  c.killer_guild_name AS stored_killer_guild,
  c.killer_side AS stored_killer_side,
  c.reason AS cause,
  c.is_pvp,
  c.is_player_kill,
  c.death_time,
  c.killers,
  c.assists,
  c.participated_players,
  c.assisted_players,
  c.source,
  c.world,
  c.created_at,
  cv.guild_name AS victim_guild,
  cv.side AS victim_current_side,
  ck.guild_name AS killer_current_guild,
  ck.side AS killer_current_side,
  CASE
    WHEN NOT c.is_player_kill THEN 'pve'
    WHEN c.killer_side IN ('everlast','ally') AND c.character_side IN ('everlast','ally') THEN 'same_alliance'
    WHEN c.killer_side IN ('everlast','ally') AND c.character_side = 'enemy' THEN 'confirmed'
    WHEN c.killer_side = 'enemy' AND c.character_side IN ('everlast','ally') THEN 'confirmed'
    WHEN (c.killer_side IS NULL OR c.killer_side = 'neutral') AND ck.side IN ('everlast','ally','enemy') THEN 'inferred'
    ELSE 'unknown'
  END AS attribution,
  CASE
    WHEN NOT c.is_player_kill THEN 'pve'
    WHEN c.killer_side IN ('everlast','ally') AND c.character_side IN ('everlast','ally') THEN 'same_alliance'
    WHEN c.killer_side IN ('everlast','ally') AND c.character_side = 'enemy' THEN 'friendly_kills_enemy'
    WHEN c.killer_side = 'enemy' AND c.character_side IN ('everlast','ally') THEN 'enemy_kills_friendly'
    WHEN (c.killer_side IS NULL OR c.killer_side = 'neutral') AND ck.side IN ('everlast','ally') AND c.character_side = 'enemy' THEN 'friendly_kills_enemy_inferred'
    WHEN (c.killer_side IS NULL OR c.killer_side = 'neutral') AND ck.side = 'enemy' AND c.character_side IN ('everlast','ally') THEN 'enemy_kills_friendly_inferred'
    ELSE 'excluded'
  END AS war_category,
  COALESCE(jsonb_array_length(
    CASE WHEN jsonb_typeof(c.participated_players) = 'array'
         THEN c.participated_players ELSE '[]'::jsonb END
  ), 0) AS participant_count,
  COALESCE(jsonb_array_length(
    CASE WHEN jsonb_typeof(c.assisted_players) = 'array'
         THEN c.assisted_players ELSE '[]'::jsonb END
  ), 0) AS assist_count
FROM canonical_death_events c
LEFT JOIN characters cv ON cv.name = c.character_name
LEFT JOIN characters ck ON ck.name = c.killer_name;

GRANT SELECT ON canonical_war_events TO anon, authenticated;
GRANT SELECT ON canonical_war_events TO service_role;
