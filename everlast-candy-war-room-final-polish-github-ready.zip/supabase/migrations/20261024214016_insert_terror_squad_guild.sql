/*
# Insert Terror Squad guild record

1. Data Changes
- Inserts the Terror Squad guild record with side='ally',
  alliance='Everlast Alliance', display_label='Terrory'.
2. Security
- No RLS or privilege changes.
3. Notes
- This must be a separate migration from the enum addition because
  Postgres requires new enum values to be committed before use.
*/

INSERT INTO guilds (name, world, side, alliance, display_label, member_count)
VALUES ('Terror Squad', 'Sinistra', 'ally', 'Everlast Alliance', 'Terrory', 0)
ON CONFLICT (name) DO UPDATE SET
  alliance = EXCLUDED.alliance,
  display_label = EXCLUDED.display_label,
  side = EXCLUDED.side;
