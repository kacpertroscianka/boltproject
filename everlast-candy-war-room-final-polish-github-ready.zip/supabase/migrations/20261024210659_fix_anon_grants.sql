-- Revoke excessive grants from anon role on public tables.
-- The original migration only granted SELECT to anon, but the current
-- database state shows anon has INSERT/UPDATE/DELETE/TRUNCATE/REFERENCES/TRIGGER
-- on every table. This is a security risk — anonymous visitors could
-- modify or delete data if they found a way past RLS.
-- service_role (used by edge functions) bypasses RLS and is unaffected.

-- Public read-only tables: only SELECT for anon
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON guilds FROM anon;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON characters FROM anon;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON death_events FROM anon;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON activity_snapshots FROM anon;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON sync_log FROM anon;

-- User-scoped tables: no access at all for anon
REVOKE SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON watchlists FROM anon;
REVOKE SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER ON discord_webhooks FROM anon;