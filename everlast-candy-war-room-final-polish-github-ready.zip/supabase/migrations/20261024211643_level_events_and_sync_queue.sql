/*
# Level Events Table + Discord Cleanup + Sync Queue

## 1. New Table: character_level_events
- Records observed level changes (up or down) for monitored characters.
- One row per observed transition between two snapshots — NOT per individual level.
- If a character goes from 500 to 503 between observations, a single +3 event is stored.
- Columns: id, character_id, character_name, previous_level, new_level, level_diff,
  observed_at, source, world.
- Unique constraint on (character_id, observed_at) to prevent duplicate events
  from re-processed sync runs.

## 2. New Table: sync_queue
- Persistent work queue for the death-monitoring scheduler.
- Each row represents a character that needs to be fetched from TibiaData.
- Columns: id, character_id, character_name, priority, status, last_attempted_at,
  last_cached_at, attempts, error_message, created_at, updated_at.
- status: 'pending' | 'in_progress' | 'done' | 'failed'
- priority: 0 (highest) to 10 (lowest). Online characters get priority 0,
  recently changed get priority 1, offline get priority 5.

## 3. Security Changes
- discord_webhooks table: revoke all access from authenticated role (effectively
  disabling Discord integration without deleting existing data).
- character_level_events: RLS enabled, public read-only (like death_events).
- sync_queue: RLS enabled, no access for anon/authenticated (service_role only).

## 4. Indexes
- character_level_events: index on character_id, observed_at DESC, level_diff
- sync_queue: index on status+priority for efficient queue queries
*/

-- ===== CHARACTER LEVEL EVENTS =====
CREATE TABLE IF NOT EXISTS character_level_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  character_id uuid REFERENCES characters(id) ON DELETE CASCADE,
  character_name text NOT NULL,
  previous_level int,
  new_level int,
  level_diff int NOT NULL,
  observed_at timestamptz NOT NULL DEFAULT now(),
  source text DEFAULT 'tibiadata',
  world text DEFAULT 'Sinistra',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE character_level_events ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON character_level_events TO anon, authenticated;
GRANT ALL ON character_level_events TO service_role;

CREATE UNIQUE INDEX IF NOT EXISTS idx_level_events_dedup
  ON character_level_events(character_id, observed_at);
CREATE INDEX IF NOT EXISTS idx_level_events_char
  ON character_level_events(character_id);
CREATE INDEX IF NOT EXISTS idx_level_events_time
  ON character_level_events(observed_at DESC);
CREATE INDEX IF NOT EXISTS idx_level_events_diff
  ON character_level_events(level_diff DESC);

DROP POLICY IF EXISTS "public_read_level_events" ON character_level_events;
CREATE POLICY "public_read_level_events" ON character_level_events FOR SELECT
  TO anon, authenticated USING (true);

-- ===== SYNC QUEUE =====
CREATE TABLE IF NOT EXISTS sync_queue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  character_id uuid REFERENCES characters(id) ON DELETE CASCADE,
  character_name text NOT NULL,
  side war_side NOT NULL DEFAULT 'neutral',
  priority int NOT NULL DEFAULT 5,
  status text NOT NULL DEFAULT 'pending',
  last_attempted_at timestamptz,
  last_cached_at timestamptz,
  attempts int DEFAULT 0,
  error_message text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE sync_queue ENABLE ROW LEVEL SECURITY;
GRANT ALL ON sync_queue TO service_role;

CREATE INDEX IF NOT EXISTS idx_sync_queue_pending
  ON sync_queue(status, priority, updated_at);

-- ===== DISABLE DISCORD WEBHOOKS =====
-- Revoke all access from authenticated role. The table data is preserved
-- but no user can read or write webhook URLs anymore.
REVOKE SELECT, INSERT, UPDATE, DELETE ON discord_webhooks FROM authenticated;