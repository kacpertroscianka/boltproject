-- Create a secure config table for the candy session secret
-- This is only accessible to the service role (no anon/authenticated grants)
CREATE TABLE IF NOT EXISTS public.app_config (
  key text PRIMARY KEY,
  value text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE public.app_config ENABLE ROW LEVEL SECURITY;

-- No policies = no access for anon or authenticated (service_role bypasses RLS)

-- Set the secret explicitly through a PRIVATE deployment configuration step.
-- Do not commit a real CANDY_SESSION_SECRET to a SQL migration or source archive.
-- The app_config row must match the server's CANDY_SESSION_SECRET value.
-- See CHANGELOG-REVIEW.md for the one-time administrator action.

-- Update verify_candy_secret to check against the table instead of GUC
CREATE OR REPLACE FUNCTION public.verify_candy_secret(p_secret text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p_secret IS NOT NULL
    AND p_secret = (SELECT value FROM public.app_config WHERE key = 'candy_session_secret')
$$;
