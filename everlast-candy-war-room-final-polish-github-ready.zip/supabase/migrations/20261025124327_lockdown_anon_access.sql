-- LOCKDOWN: Remove all anonymous SELECT access to protected intelligence tables.
-- The anon key is used by the browser and must NOT be able to read any data directly.
-- All data access now goes through server-side API routes that use the service role key.
-- Per-user tables (watchlist) remain accessible to authenticated Supabase auth users only.

-- Revoke ALL privileges from anon on every public table
DO $$
DECLARE t record;
BEGIN
  FOR t IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' LOOP
    EXECUTE format('REVOKE ALL ON public.%I FROM anon', t.tablename);
  END LOOP;
  FOR t IN SELECT viewname FROM pg_views WHERE schemaname = 'public' LOOP
    EXECUTE format('REVOKE ALL ON public.%I FROM anon', t.viewname);
  END LOOP;
END $$;

-- Drop any existing anon policies on intelligence tables
DO $$
DECLARE p record;
BEGIN
  FOR p IN 
    SELECT policyname, tablename, cmd 
    FROM pg_policies 
    WHERE schemaname = 'public' 
      AND (cmd = 'SELECT' OR cmd = 'ALL')
      AND 'anon' = ANY(roles)
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON public.%I', p.policyname, p.tablename);
  END LOOP;
END $$;

-- Verify: anon should have NO privileges on any public table/view
SELECT 'post-lockdown' AS check,
  count(*) FILTER (WHERE grantee = 'anon') AS anon_grants_remaining
FROM information_schema.table_privileges
WHERE table_schema = 'public';
