/*
# Reschedule cron jobs with hardcoded edge function URL

1. Changes
- Unschedules the previous cron jobs that relied on a database setting.
- Reschedules both jobs with the edge function URL hardcoded, since
  ALTER DATABASE SET is not permitted in this environment.
2. Notes
- The edge function base URL is specific to this Supabase project.
- Edge functions have verify_jwt = false so they accept cron invocations.
*/

SELECT cron.unschedule('sync_guilds');
SELECT cron.unschedule('sync_deaths');

SELECT cron.schedule(
  'sync_guilds',
  '*/2 * * * *',
  $$SELECT net.http_post(
    url := 'https://qfsoxezxfefjxxufwnmo.supabase.co/functions/v1/sync-guild',
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := jsonb_build_object('source', 'pg_cron')
  )$$
);

SELECT cron.schedule(
  'sync_deaths',
  '* * * * *',
  $$SELECT net.http_post(
    url := 'https://qfsoxezxfefjxxufwnmo.supabase.co/functions/v1/sync-deaths',
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := jsonb_build_object('source', 'pg_cron')
  )$$
);
