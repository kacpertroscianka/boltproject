/*
# Create staging_scan_log table and helper function

## staging_scan_log
Tracks the progress of the clean reimport — one row per roster character,
recording whether the scan succeeded, how many deaths were found, and
whether the death list was truncated by TibiaData.

## ensure_staging_scan_log function
A no-op RPC that creates the table if it doesn't exist. Called by the
reimport-deaths edge function at startup to ensure the table exists.
*/
CREATE TABLE IF NOT EXISTS staging_scan_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  character_name text UNIQUE NOT NULL,
  guild text,
  side text,
  status text NOT NULL DEFAULT 'pending',
  deaths_found integer DEFAULT 0,
  deaths_truncated boolean DEFAULT false,
  character_level integer,
  error_message text,
  scanned_at timestamptz DEFAULT now()
);

ALTER TABLE staging_scan_log ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON staging_scan_log TO anon, authenticated, service_role;

DROP POLICY IF EXISTS "anon_select_staging_scan" ON staging_scan_log;
CREATE POLICY "anon_select_staging_scan" ON staging_scan_log FOR SELECT
  TO anon, authenticated USING (true);
DROP POLICY IF EXISTS "anon_insert_staging_scan" ON staging_scan_log;
CREATE POLICY "anon_insert_staging_scan" ON staging_scan_log FOR INSERT
  TO anon, authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "anon_update_staging_scan" ON staging_scan_log;
CREATE POLICY "anon_update_staging_scan" ON staging_scan_log FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

CREATE OR REPLACE FUNCTION ensure_staging_scan_log()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  CREATE TABLE IF NOT EXISTS staging_scan_log (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    character_name text UNIQUE NOT NULL,
    guild text,
    side text,
    status text NOT NULL DEFAULT 'pending',
    deaths_found integer DEFAULT 0,
    deaths_truncated boolean DEFAULT false,
    character_level integer,
    error_message text,
    scanned_at timestamptz DEFAULT now()
  );
  ALTER TABLE staging_scan_log ENABLE ROW LEVEL SECURITY;
  GRANT SELECT, INSERT, UPDATE, DELETE ON staging_scan_log TO anon, authenticated, service_role;
END;
$$;

GRANT EXECUTE ON FUNCTION ensure_staging_scan_log() TO anon, authenticated, service_role;
