/*
# Fix war_sessions RPC functions to use verify_candy_secret

The original create_war_sessions.sql used `current_setting('app.candy_secret', true)`
which returns NULL because the secret is stored in app_config, not as a GUC.
This replaces all war_sessions RPCs to use the same verify_candy_secret() function
that every other RPC in the project uses.

1. Changes
- get_war_sessions, get_war_session, create_war_session, end_war_session,
  update_war_session, delete_war_session: replaced inline secret check with
  `public.verify_candy_secret(p_secret)`.
- No data changes, no schema changes.
- All functions remain SECURITY DEFINER with search_path = public.
- Execute grants remain revoked from PUBLIC/anon (unchanged).
*/

CREATE OR REPLACE FUNCTION get_war_sessions(p_secret text, p_limit int DEFAULT 50)
RETURNS SETOF war_sessions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
  SELECT * FROM war_sessions
  ORDER BY started_at DESC
  LIMIT p_limit;
END;
$$;

CREATE OR REPLACE FUNCTION get_war_session(p_secret text, p_id uuid)
RETURNS war_sessions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result war_sessions;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  SELECT * INTO result FROM war_sessions WHERE id = p_id;
  RETURN result;
END;
$$;

CREATE OR REPLACE FUNCTION create_war_session(
  p_secret text,
  p_name text,
  p_scoring_mode text DEFAULT 'last-hit',
  p_notes text DEFAULT NULL
)
RETURNS war_sessions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result war_sessions;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  IF p_name IS NULL OR length(trim(p_name)) = 0 THEN
    RAISE EXCEPTION 'Session name required';
  END IF;
  IF p_scoring_mode NOT IN ('last-hit', 'participation') THEN
    RAISE EXCEPTION 'Invalid scoring mode';
  END IF;
  INSERT INTO war_sessions (name, scoring_mode, notes, status, started_at)
  VALUES (trim(p_name), p_scoring_mode, p_notes, 'active', now())
  RETURNING * INTO result;
  RETURN result;
END;
$$;

CREATE OR REPLACE FUNCTION end_war_session(
  p_secret text,
  p_id uuid,
  p_notes text DEFAULT NULL
)
RETURNS war_sessions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result war_sessions;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  UPDATE war_sessions
  SET status = 'ended', ended_at = now(), updated_at = now(),
      notes = COALESCE(p_notes, notes)
  WHERE id = p_id AND status = 'active'
  RETURNING * INTO result;
  IF result IS NULL THEN
    RAISE EXCEPTION 'Session not found or already ended';
  END IF;
  RETURN result;
END;
$$;

CREATE OR REPLACE FUNCTION update_war_session(
  p_secret text,
  p_id uuid,
  p_name text DEFAULT NULL,
  p_notes text DEFAULT NULL,
  p_scoring_mode text DEFAULT NULL
)
RETURNS war_sessions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result war_sessions;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  UPDATE war_sessions
  SET name = COALESCE(NULLIF(p_name, ''), name),
      notes = COALESCE(p_notes, notes),
      scoring_mode = COALESCE(NULLIF(p_scoring_mode, ''), scoring_mode),
      updated_at = now()
  WHERE id = p_id
  RETURNING * INTO result;
  IF result IS NULL THEN
    RAISE EXCEPTION 'Session not found';
  END IF;
  RETURN result;
END;
$$;

CREATE OR REPLACE FUNCTION delete_war_session(p_secret text, p_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  DELETE FROM war_sessions WHERE id = p_id;
  RETURN FOUND;
END;
$$;
