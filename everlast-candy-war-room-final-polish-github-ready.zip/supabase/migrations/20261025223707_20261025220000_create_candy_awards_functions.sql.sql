/*
# Candy Awards server-side aggregation functions

1. New Functions
- `get_candy_awards(p_secret text, p_since timestamptz, p_guild_filter text)`
  Returns all six Candy Awards in a single authenticated call, computed
  server-side from canonical_war_events and character_level_events.
  Replaces the previous approach of fetching 4500 raw records to the browser
  and filtering client-side, reducing response size from ~4500 rows to ~30.

  Awards returned:
  - killer_rankings: Last Hit credited kills per player (war_category based)
  - participation_rankings: distinct opposing deaths where player participated
  - oopsie_rankings: characters with most deaths (PvP + PvE split)
  - level_hero_entries: largest observed level gains (net diff per character)
  - biggest_trophy: highest-level enemy killed by a friendly player
  - summary: counts for the selected period

  p_guild_filter: 'all', 'everlast', 'ally', or 'enemy'.
  Filters killer/participation rankings by the killer's side, and
  oopsie/level hero by the character's side.

2. Security
- SECURITY DEFINER, checks verify_candy_secret before returning data.
- GRANT EXECUTE to anon + authenticated (secret-gated like all other RPCs).
*/

CREATE OR REPLACE FUNCTION public.get_candy_awards(
  p_secret text,
  p_since timestamptz,
  p_guild_filter text DEFAULT 'all'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_killer_rankings jsonb;
  v_participation_rankings jsonb;
  v_oopsie_rankings jsonb;
  v_level_hero_entries jsonb;
  v_biggest_trophy jsonb;
  v_summary jsonb;
  v_guild_side_filter text := CASE
    WHEN p_guild_filter = 'everlast' THEN 'everlast'
    WHEN p_guild_filter = 'ally' THEN 'ally'
    WHEN p_guild_filter = 'enemy' THEN 'enemy'
    ELSE NULL
  END;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  -- Award 1/5/6: Last Hit killer rankings
  SELECT COALESCE(jsonb_agg(sub ORDER BY sub.kills DESC), '[]'::jsonb) INTO v_killer_rankings
  FROM (
    SELECT
      w.killer_name AS name,
      w.stored_killer_side AS side,
      w.stored_killer_guild AS guild,
      w.killer_vocation AS vocation,
      w.killer_level AS level,
      COUNT(*) AS kills,
      jsonb_agg(w.event_id ORDER BY w.death_time DESC) AS event_ids
    FROM canonical_war_events w
    WHERE w.death_time >= p_since
      AND w.is_player_kill = true
      AND w.war_category IN (
        'friendly_kills_enemy', 'friendly_kills_enemy_inferred',
        'enemy_kills_friendly', 'enemy_kills_friendly_inferred'
      )
      AND w.killer_name IS NOT NULL
      AND (
        v_guild_side_filter IS NULL OR
        CASE
          WHEN w.war_category LIKE 'friendly_kills%' THEN
            COALESCE(w.stored_killer_side::text, 'everlast') = v_guild_side_filter
          WHEN w.war_category LIKE 'enemy_kills%' THEN
            COALESCE(w.stored_killer_side::text, 'enemy') = v_guild_side_filter
          ELSE false
        END
      )
    GROUP BY w.killer_name, w.stored_killer_side, w.stored_killer_guild, w.killer_vocation, w.killer_level
  ) sub;

  -- Award 1/5/6: Participation rankings
  SELECT COALESCE(jsonb_agg(sub ORDER BY sub.kills DESC), '[]'::jsonb) INTO v_participation_rankings
  FROM (
    SELECT
      elem.name AS name,
      (SELECT c.side::text FROM characters c WHERE lower(c.name) = lower(elem.name) LIMIT 1) AS side,
      (SELECT c.guild_name FROM characters c WHERE lower(c.name) = lower(elem.name) LIMIT 1) AS guild,
      (SELECT c.vocation FROM characters c WHERE lower(c.name) = lower(elem.name) LIMIT 1) AS vocation,
      (SELECT c.level FROM characters c WHERE lower(c.name) = lower(elem.name) LIMIT 1) AS level,
      COUNT(DISTINCT w.event_id) AS kills,
      jsonb_agg(DISTINCT w.event_id) AS event_ids
    FROM canonical_war_events w,
    LATERAL (
      SELECT player_name AS name FROM jsonb_array_elements(
        COALESCE(w.participated_players, '[]'::jsonb)
      ) AS je(player_name)
      WHERE je.player_name::text != to_jsonb(w.character_name)
      UNION
      SELECT player_name AS name FROM jsonb_array_elements(
        COALESCE(w.assisted_players, '[]'::jsonb)
      ) AS je(player_name)
      WHERE je.player_name::text != to_jsonb(w.character_name)
    ) elem
    WHERE w.death_time >= p_since
      AND w.is_player_kill = true
      AND (
        (w.war_category LIKE 'friendly_kills%' AND is_enemy_side(w.character_side))
        OR (w.war_category LIKE 'enemy_kills%' AND is_friendly_side(w.character_side))
      )
      AND (
        v_guild_side_filter IS NULL OR
        COALESCE(
          (SELECT c.side::text FROM characters c WHERE lower(c.name) = lower(elem.name) LIMIT 1),
          ''
        ) = v_guild_side_filter
      )
    GROUP BY elem.name
  ) sub;

  -- Award 2: Oopsie rankings (most deaths)
  SELECT COALESCE(jsonb_agg(sub ORDER BY sub.total_deaths DESC), '[]'::jsonb) INTO v_oopsie_rankings
  FROM (
    SELECT
      d.character_name AS name,
      d.character_side::text AS side,
      d.character_vocation AS vocation,
      MAX(d.character_level) AS level,
      COUNT(*) AS total_deaths,
      COUNT(*) FILTER (WHERE d.is_pvp) AS pvp_deaths,
      COUNT(*) FILTER (WHERE NOT d.is_pvp) AS pve_deaths,
      MAX(d.death_time) AS last_death_time
    FROM canonical_death_events d
    WHERE d.death_time >= p_since
      AND (
        v_guild_side_filter IS NULL OR
        d.character_side::text = v_guild_side_filter
      )
    GROUP BY d.character_name, d.character_side, d.character_vocation
  ) sub;

  -- Award 3: Level Hero (largest net observed level gains)
  SELECT COALESCE(jsonb_agg(sub ORDER BY sub.total_diff DESC), '[]'::jsonb) INTO v_level_hero_entries
  FROM (
    SELECT
      e.character_name AS name,
      MAX(COALESCE(c.side::text, 'neutral')) AS side,
      MAX(c.guild_name) AS guild,
      MAX(c.vocation) AS vocation,
      (array_agg(e.previous_level ORDER BY e.observed_at ASC))[1] AS start_level,
      (array_agg(e.new_level ORDER BY e.observed_at DESC))[1] AS end_level,
      SUM(e.level_diff) AS total_diff,
      COUNT(*) AS event_count,
      MIN(e.observed_at) AS first_observed,
      MAX(e.observed_at) AS last_observed
    FROM character_level_events e
    LEFT JOIN characters c ON lower(c.name) = lower(e.character_name)
    WHERE e.observed_at >= p_since
      AND (
        v_guild_side_filter IS NULL OR
        COALESCE(c.side::text, '') = v_guild_side_filter
      )
    GROUP BY e.character_name
    HAVING SUM(e.level_diff) > 0
  ) sub;

  -- Award 4: Biggest Trophy (highest-level enemy killed by friendly)
  SELECT to_jsonb(sub) INTO v_biggest_trophy
  FROM (
    SELECT
      w.character_name AS victim,
      w.character_side::text AS victim_side,
      w.victim_guild AS victim_guild,
      w.character_level AS victim_level,
      w.killer_name AS killer,
      w.stored_killer_side::text AS killer_side,
      COALESCE(w.killer_current_guild, w.stored_killer_guild) AS killer_guild,
      w.death_time,
      w.event_id::text AS event_id
    FROM canonical_war_events w
    WHERE w.death_time >= p_since
      AND w.is_player_kill = true
      AND w.war_category IN ('friendly_kills_enemy', 'friendly_kills_enemy_inferred')
    ORDER BY w.character_level DESC
    LIMIT 1
  ) sub;

  -- Summary counts
  SELECT jsonb_build_object(
    'total_events', COUNT(*),
    'pvp_events', COUNT(*) FILTER (WHERE is_player_kill),
    'friendly_kills', COUNT(*) FILTER (WHERE war_category IN ('friendly_kills_enemy','friendly_kills_enemy_inferred')),
    'enemy_kills', COUNT(*) FILTER (WHERE war_category IN ('enemy_kills_friendly','enemy_kills_friendly_inferred')),
    'level_events', (SELECT COUNT(*) FROM character_level_events WHERE observed_at >= p_since)
  ) INTO v_summary
  FROM canonical_war_events
  WHERE death_time >= p_since;

  RETURN jsonb_build_object(
    'killer_rankings', v_killer_rankings,
    'participation_rankings', v_participation_rankings,
    'oopsie_rankings', v_oopsie_rankings,
    'level_hero_entries', v_level_hero_entries,
    'biggest_trophy', COALESCE(v_biggest_trophy, 'null'::jsonb),
    'summary', v_summary
  );
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_candy_awards(text, timestamptz, text) TO anon, authenticated;
