-- Phase 12. Requires Phase 10 and Phase 11 migrations.
-- No existing death data, scoring, guild rosters or user tables are changed.

ALTER TABLE public.team_war_calls ADD COLUMN IF NOT EXISTS ended_at timestamptz;

-- Phase 10 create_team_war_call also closes an earlier active call. Capture its finish time.
CREATE OR REPLACE FUNCTION public.stamp_team_call_end()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF OLD.status = 'active' AND NEW.status <> 'active' AND NEW.ended_at IS NULL THEN
    NEW.ended_at = now();
  END IF;
  RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS team_call_finished_at ON public.team_war_calls;
CREATE TRIGGER team_call_finished_at BEFORE UPDATE ON public.team_war_calls
FOR EACH ROW EXECUTE FUNCTION public.stamp_team_call_end();

-- For older ended calls, do NOT invent a precise battle end timestamp.
-- Report RPC returns 'available: false' when ended_at is missing.

CREATE TABLE IF NOT EXISTS public.team_supply_checklists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  war_call_id uuid NOT NULL REFERENCES public.team_war_calls(id) ON DELETE CASCADE,
  client_id text NOT NULL,
  player_name text NOT NULL,
  player_side text NOT NULL CHECK (player_side IN ('everlast','ally')),
  potions boolean NOT NULL DEFAULT false,
  runes boolean NOT NULL DEFAULT false,
  amulets boolean NOT NULL DEFAULT false,
  backpack boolean NOT NULL DEFAULT false,
  voice_comms boolean NOT NULL DEFAULT false,
  note text NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT team_supplies_unique UNIQUE (war_call_id, client_id)
);
ALTER TABLE public.team_supply_checklists ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.team_supply_checklists FROM PUBLIC, anon, authenticated;

CREATE OR REPLACE FUNCTION public.get_team_supply_checklists(p_secret text, p_war_call_id uuid)
RETURNS SETOF public.team_supply_checklists
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  RETURN QUERY SELECT * FROM public.team_supply_checklists
  WHERE war_call_id = p_war_call_id ORDER BY updated_at DESC;
END; $$;

CREATE OR REPLACE FUNCTION public.upsert_team_supply_checklist(
  p_secret text, p_war_call_id uuid, p_client_id text,
  p_potions boolean, p_runes boolean, p_amulets boolean, p_backpack boolean,
  p_voice_comms boolean, p_note text DEFAULT NULL
)
RETURNS public.team_supply_checklists
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_player public.team_war_call_responses%ROWTYPE;
  v_result public.team_supply_checklists;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.team_war_calls WHERE id = p_war_call_id AND status = 'active')
    THEN RAISE EXCEPTION 'War Call is not active'; END IF;
  IF length(coalesce(p_client_id, '')) < 8 OR length(p_client_id) > 100 OR length(coalesce(p_note, '')) > 240
    THEN RAISE EXCEPTION 'Invalid supply fields'; END IF;
  SELECT * INTO v_player FROM public.team_war_call_responses
    WHERE war_call_id = p_war_call_id AND client_id = p_client_id AND player_side IN ('everlast','ally');
  IF NOT FOUND THEN RAISE EXCEPTION 'Mark your readiness before submitting supplies'; END IF;

  INSERT INTO public.team_supply_checklists (
    war_call_id, client_id, player_name, player_side, potions, runes, amulets, backpack, voice_comms, note
  ) VALUES (
    p_war_call_id, p_client_id, v_player.player_name, v_player.player_side,
    coalesce(p_potions, false), coalesce(p_runes, false), coalesce(p_amulets, false),
    coalesce(p_backpack, false), coalesce(p_voice_comms, false), p_note
  ) ON CONFLICT (war_call_id, client_id) DO UPDATE SET
    player_name=EXCLUDED.player_name, player_side=EXCLUDED.player_side,
    potions=EXCLUDED.potions, runes=EXCLUDED.runes, amulets=EXCLUDED.amulets,
    backpack=EXCLUDED.backpack, voice_comms=EXCLUDED.voice_comms,
    note=EXCLUDED.note, updated_at=now()
  RETURNING * INTO v_result;
  RETURN v_result;
END; $$;

-- Read-only summary for completed calls, association strictly by the call's time interval.
CREATE OR REPLACE FUNCTION public.get_team_after_battle_report(p_secret text, p_war_call_id uuid)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_call public.team_war_calls;
  v_start timestamptz;
  v_end timestamptz;
  v_summary jsonb;
  v_events jsonb;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  SELECT * INTO v_call FROM public.team_war_calls WHERE id = p_war_call_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'War Call not found'; END IF;
  IF v_call.status <> 'ended' OR v_call.ended_at IS NULL THEN
    RETURN jsonb_build_object('available', false, 'reason', 'Call is active or end time is unknown');
  END IF;
  v_end := v_call.ended_at;
  v_start := CASE WHEN v_call.starts_at IS NOT NULL AND v_call.starts_at > v_call.created_at AND v_call.starts_at < v_end
                  THEN v_call.starts_at ELSE v_call.created_at END;
  IF v_end <= v_start THEN
    RETURN jsonb_build_object('available', false, 'reason', 'Invalid call time window');
  END IF;

  SELECT jsonb_build_object(
    'totalEvents', count(*),
    'allianceConfirmed', count(*) FILTER (WHERE e.war_category = 'friendly_kills_enemy'),
    'enemyConfirmed', count(*) FILTER (WHERE e.war_category = 'enemy_kills_friendly'),
    'allianceInferred', count(*) FILTER (WHERE e.war_category = 'friendly_kills_enemy_inferred'),
    'enemyInferred', count(*) FILTER (WHERE e.war_category = 'enemy_kills_friendly_inferred'),
    'allianceDeaths', count(*) FILTER (WHERE e.victim_current_side IN ('everlast','ally')),
    'enemyDeaths', count(*) FILTER (WHERE e.victim_current_side = 'enemy'),
    'pveDeaths', count(*) FILTER (WHERE e.war_category = 'pve'),
    'sameAlliance', count(*) FILTER (WHERE e.war_category = 'same_alliance')
  ) INTO v_summary
  FROM public.canonical_war_events e
  WHERE e.death_time >= v_start AND e.death_time <= v_end AND e.world = 'Sinistra';

  SELECT coalesce(jsonb_agg(jsonb_build_object(
    'eventId', sub.event_id,
    'time', sub.death_time,
    'victim', sub.character_name,
    'killer', sub.killer_name,
    'category', sub.war_category,
    'victimLevel', sub.character_level
  ) ORDER BY sub.death_time DESC), '[]'::jsonb)
  INTO v_events FROM (
    SELECT event_id, death_time, character_name, killer_name, war_category, character_level
    FROM public.canonical_war_events
    WHERE death_time >= v_start AND death_time <= v_end AND world = 'Sinistra'
    ORDER BY death_time DESC LIMIT 30
  ) sub;

  RETURN jsonb_build_object(
    'available', true, 'callId', v_call.id, 'callTitle', v_call.title,
    'windowStart', v_start, 'windowEnd', v_end,
    'summary', v_summary, 'events', v_events,
    'method', 'Time-window matching only. Not proof that any event belongs to this War Call.'
  );
END; $$;

REVOKE ALL ON FUNCTION public.get_team_supply_checklists(text, uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.upsert_team_supply_checklist(text, uuid, text, boolean, boolean, boolean, boolean, boolean, text) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.get_team_after_battle_report(text, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_team_supply_checklists(text, uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.upsert_team_supply_checklist(text, uuid, text, boolean, boolean, boolean, boolean, boolean, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_team_after_battle_report(text, uuid) TO anon, authenticated;
