/*
# Everlast War Room - Core Schema

## Overview
Creates the full database structure for the Tibia guild war intelligence app
for the Sinistra server, tracking the war between Everlast (primary) and
Mandatory Again (enemy).

## New Tables
1. `guilds` - Guild records (id, name, world, side, logo_url, motd)
2. `characters` - Tibia characters (id, name, world, vocation, level, guild_id, side, online, last_seen)
3. `death_events` - Death records deduplicated by character + time + cause (id, character_id, killer_name, killer_vocation, killer_level, killer_guild_id, cause, pvp, time, level_at_death)
4. `activity_snapshots` - Point-in-time online activity (id, guild_id, online_count, snapshot_at)
5. `watchlists` - Authenticated user follow lists (id, user_id, character_id, created_at)
6. `discord_webhooks` - User Discord notification config (id, user_id, url, label, active)
7. `sync_log` - Sync job audit trail (id, job, status, message, started_at, finished_at)

## Side Convention
- `side` enum: 'everlast' (allied) | 'enemy' (Mandatory Again) | 'neutral'

## Security
- This is a multi-user app (watchlists + webhooks are user-scoped), but the
  core intelligence tables (guilds, characters, death_events, activity_snapshots,
  sync_log) are intentionally public/read-only to all visitors (no sign-in needed
  to view war stats). So those use TO anon, authenticated SELECT-only policies.
- watchlists + discord_webhooks are owner-scoped to authenticated users with
  full CRUD, user_id DEFAULT auth.uid().
- service_role granted for edge-function sync jobs.
*/



-- ===== ENUM TYPES =====
DO $$ BEGIN
  CREATE TYPE war_side AS ENUM ('everlast', 'enemy', 'neutral');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ===== GUILDS =====
CREATE TABLE IF NOT EXISTS guilds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  world text NOT NULL DEFAULT 'Sinistra',
  side war_side NOT NULL DEFAULT 'neutral',
  logo_url text,
  motd text,
  member_count int DEFAULT 0,
  last_synced_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE guilds ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON guilds TO anon, authenticated;
GRANT ALL ON guilds TO service_role;
DROP POLICY IF EXISTS "public_read_guilds" ON guilds;
CREATE POLICY "public_read_guilds" ON guilds FOR SELECT
  TO anon, authenticated USING (true);

-- ===== CHARACTERS =====
CREATE TABLE IF NOT EXISTS characters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  world text NOT NULL DEFAULT 'Sinistra',
  vocation text,
  level int,
  sex text,
  guild_id uuid REFERENCES guilds(id) ON DELETE SET NULL,
  guild_name text,
  side war_side NOT NULL DEFAULT 'neutral',
  online boolean DEFAULT false,
  last_seen_at timestamptz,
  last_observed_level int,
  previous_level int,
  rank text,
  deleted boolean DEFAULT false,
  tibidata_id text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE characters ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON characters TO anon, authenticated;
GRANT ALL ON characters TO service_role;
CREATE INDEX IF NOT EXISTS idx_characters_guild ON characters(guild_id);
CREATE INDEX IF NOT EXISTS idx_characters_side ON characters(side);
CREATE INDEX IF NOT EXISTS idx_characters_online ON characters(online);
CREATE INDEX IF NOT EXISTS idx_characters_name_lower ON characters(lower(name));
DROP POLICY IF EXISTS "public_read_characters" ON characters;
CREATE POLICY "public_read_characters" ON characters FOR SELECT
  TO anon, authenticated USING (true);

-- ===== DEATH EVENTS =====
CREATE TABLE IF NOT EXISTS death_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  character_id uuid REFERENCES characters(id) ON DELETE CASCADE,
  character_name text NOT NULL,
  character_level int NOT NULL,
  character_vocation text,
  character_side war_side NOT NULL DEFAULT 'neutral',
  killer_name text,
  killer_vocation text,
  killer_level int,
  killer_guild_id uuid REFERENCES guilds(id) ON DELETE SET NULL,
  killer_guild_name text,
  killer_side war_side,
  cause text NOT NULL,
  is_pvp boolean DEFAULT false,
  is_player_kill boolean DEFAULT false,
  death_time timestamptz NOT NULL,
  participated_players jsonb DEFAULT '[]'::jsonb,
  source text DEFAULT 'tibiadata',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE death_events ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON death_events TO anon, authenticated;
GRANT ALL ON death_events TO service_role;
CREATE UNIQUE INDEX IF NOT EXISTS idx_death_dedup
  ON death_events(character_name, death_time, cause);
CREATE INDEX IF NOT EXISTS idx_death_time ON death_events(death_time DESC);
CREATE INDEX IF NOT EXISTS idx_death_char ON death_events(character_id);
CREATE INDEX IF NOT EXISTS idx_death_side ON death_events(character_side);
CREATE INDEX IF NOT EXISTS idx_death_pvp ON death_events(is_pvp);
CREATE INDEX IF NOT EXISTS idx_death_killer_guild ON death_events(killer_guild_id);
DROP POLICY IF EXISTS "public_read_deaths" ON death_events;
CREATE POLICY "public_read_deaths" ON death_events FOR SELECT
  TO anon, authenticated USING (true);

-- ===== ACTIVITY SNAPSHOTS =====
CREATE TABLE IF NOT EXISTS activity_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  guild_id uuid REFERENCES guilds(id) ON DELETE CASCADE,
  guild_name text NOT NULL,
  side war_side NOT NULL,
  online_count int NOT NULL DEFAULT 0,
  total_members int DEFAULT 0,
  online_members text[] DEFAULT '{}',
  snapshot_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE activity_snapshots ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON activity_snapshots TO anon, authenticated;
GRANT ALL ON activity_snapshots TO service_role;
CREATE INDEX IF NOT EXISTS idx_activity_guild_time ON activity_snapshots(guild_id, snapshot_at DESC);
DROP POLICY IF EXISTS "public_read_activity" ON activity_snapshots;
CREATE POLICY "public_read_activity" ON activity_snapshots FOR SELECT
  TO anon, authenticated USING (true);

-- ===== WATCHLISTS (user-scoped) =====
CREATE TABLE IF NOT EXISTS watchlists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  character_id uuid NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
  notify_on_death boolean DEFAULT true,
  notify_on_level_change boolean DEFAULT false,
  last_notified_death_id uuid REFERENCES death_events(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE watchlists ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON watchlists TO authenticated;
GRANT ALL ON watchlists TO service_role;
CREATE INDEX IF NOT EXISTS idx_watchlist_user ON watchlists(user_id);
CREATE INDEX IF NOT EXISTS idx_watchlist_char ON watchlists(character_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_watchlist_unique ON watchlists(user_id, character_id);
DROP POLICY IF EXISTS "select_own_watchlist" ON watchlists;
CREATE POLICY "select_own_watchlist" ON watchlists FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_watchlist" ON watchlists;
CREATE POLICY "insert_own_watchlist" ON watchlists FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_watchlist" ON watchlists;
CREATE POLICY "update_own_watchlist" ON watchlists FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_watchlist" ON watchlists;
CREATE POLICY "delete_own_watchlist" ON watchlists FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ===== DISCORD WEBHOOKS (user-scoped) =====
CREATE TABLE IF NOT EXISTS discord_webhooks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  url text NOT NULL,
  label text,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE discord_webhooks ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON discord_webhooks TO authenticated;
GRANT ALL ON discord_webhooks TO service_role;
CREATE INDEX IF NOT EXISTS idx_webhook_user ON discord_webhooks(user_id);
DROP POLICY IF EXISTS "select_own_webhook" ON discord_webhooks;
CREATE POLICY "select_own_webhook" ON discord_webhooks FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_webhook" ON discord_webhooks;
CREATE POLICY "insert_own_webhook" ON discord_webhooks FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_webhook" ON discord_webhooks;
CREATE POLICY "update_own_webhook" ON discord_webhooks FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_webhook" ON discord_webhooks;
CREATE POLICY "delete_own_webhook" ON discord_webhooks FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- ===== SYNC LOG =====
CREATE TABLE IF NOT EXISTS sync_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job text NOT NULL,
  status text NOT NULL,
  message text,
  records_processed int DEFAULT 0,
  started_at timestamptz DEFAULT now(),
  finished_at timestamptz
);
ALTER TABLE sync_log ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON sync_log TO anon, authenticated;
GRANT ALL ON sync_log TO service_role;
CREATE INDEX IF NOT EXISTS idx_sync_log_job_time ON sync_log(job, started_at DESC);
DROP POLICY IF EXISTS "public_read_sync_log" ON sync_log;
CREATE POLICY "public_read_sync_log" ON sync_log FOR SELECT
  TO anon, authenticated USING (true);

-- ===== updated_at helper =====
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;
DROP TRIGGER IF EXISTS trg_guilds_updated ON guilds;
CREATE TRIGGER trg_guilds_updated BEFORE UPDATE ON guilds
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
DROP TRIGGER IF EXISTS trg_characters_updated ON characters;
CREATE TRIGGER trg_characters_updated BEFORE UPDATE ON characters
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
