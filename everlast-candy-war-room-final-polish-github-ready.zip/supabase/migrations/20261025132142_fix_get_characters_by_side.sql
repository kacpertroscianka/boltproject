-- Fix get_characters_by_side: cast side to text before comparing with text array
CREATE OR REPLACE FUNCTION public.get_characters_by_side(p_secret text, p_sides text[])
RETURNS SETOF public.characters
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.characters
    WHERE side::text = ANY(p_sides)
    ORDER BY level DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_characters_by_side(text, text[]) TO anon, authenticated;
