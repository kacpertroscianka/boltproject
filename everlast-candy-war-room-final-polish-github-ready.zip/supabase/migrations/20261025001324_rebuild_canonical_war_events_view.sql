/*
# Rebuild canonical_war_events view from canonical_death_events

## What changed
The view now reads from the new canonical_death_events table (deduplicated, with
assists) instead of running DISTINCT ON over the original death_events table.
This eliminates the duplicate-row problem at the source.

## New fields in the view
- `assisted_players` — player assistants (separate from killers)
- `killers` — full killers array from the API
- `assists` — full assists array from the API
- `participant_count` — count of player killers
- `assist_count` — count of player assists
- `attribution` — confirmed / inferred / unknown / same_alliance / pve
  (same logic as before, now using canonical table)
- `war_category` — same category logic as before

## Attribution confidence
- "confirmed": killer_side was stored at import time and matches a war guild
- "inferred": killer_side was null but killer's current guild places them in a war faction
  (confidence: inferred, not historically confirmed)
- "same_alliance": both victim and killer are friendly
- "pve": not a player kill
- "unknown": killer could not be attributed to any war guild
*/
DROP VIEW IF EXISTS canonical_war_events;

CREATE VIEW canonical_war_events AS
SELECT
  c.id AS event_id,
  c.character_id,
  c.character_name,
  c.character_level,
  c.character_vocation,
  c.character_side,
  c.killer_name,
  c.killer_vocation,
  c.killer_level,
  c.killer_guild_name AS stored_killer_guild,
  c.killer_side AS stored_killer_side,
  c.reason AS cause,
  c.is_pvp,
  c.is_player_kill,
  c.death_time,
  c.killers,
  c.assists,
  c.participated_players,
  c.assisted_players,
  c.source,
  c.world,
  c.created_at,
  cv.guild_name AS victim_guild,
  cv.side AS victim_current_side,
  ck.guild_name AS killer_current_guild,
  ck.side AS killer_current_side,
  CASE
    WHEN NOT c.is_player_kill THEN 'pve'
    WHEN c.killer_side IN ('everlast','ally') AND c.character_side IN ('everlast','ally') THEN 'same_alliance'
    WHEN c.killer_side IN ('everlast','ally') AND c.character_side = 'enemy' THEN 'confirmed'
    WHEN c.killer_side = 'enemy' AND c.character_side IN ('everlast','ally') THEN 'confirmed'
    WHEN (c.killer_side IS NULL OR c.killer_side = 'neutral') AND ck.side IN ('everlast','ally','enemy') THEN 'inferred'
    ELSE 'unknown'
  END AS attribution,
  CASE
    WHEN NOT c.is_player_kill THEN 'pve'
    WHEN c.killer_side IN ('everlast','ally') AND c.character_side IN ('everlast','ally') THEN 'same_alliance'
    WHEN c.killer_side IN ('everlast','ally') AND c.character_side = 'enemy' THEN 'friendly_kills_enemy'
    WHEN c.killer_side = 'enemy' AND c.character_side IN ('everlast','ally') THEN 'enemy_kills_friendly'
    WHEN (c.killer_side IS NULL OR c.killer_side = 'neutral') AND ck.side IN ('everlast','ally') AND c.character_side = 'enemy' THEN 'friendly_kills_enemy_inferred'
    WHEN (c.killer_side IS NULL OR c.killer_side = 'neutral') AND ck.side = 'enemy' AND c.character_side IN ('everlast','ally') THEN 'enemy_kills_friendly_inferred'
    ELSE 'excluded'
  END AS war_category,
  COALESCE(jsonb_array_length(
    CASE WHEN jsonb_typeof(c.participated_players) = 'array'
         THEN c.participated_players ELSE '[]'::jsonb END
  ), 0) AS participant_count,
  COALESCE(jsonb_array_length(
    CASE WHEN jsonb_typeof(c.assisted_players) = 'array'
         THEN c.assisted_players ELSE '[]'::jsonb END
  ), 0) AS assist_count
FROM canonical_death_events c
LEFT JOIN characters cv ON cv.name = c.character_name
LEFT JOIN characters ck ON ck.name = c.killer_name;

GRANT SELECT ON canonical_war_events TO anon, authenticated;
GRANT SELECT ON canonical_war_events TO service_role;
