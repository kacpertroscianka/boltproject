CREATE TABLE IF NOT EXISTS public.team_war_calls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  meeting_point text NULL,
  starts_at timestamptz NULL,
  notes text NULL,
  created_by text NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended', 'cancelled')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_team_war_calls_status ON public.team_war_calls(status, updated_at DESC);

CREATE TABLE IF NOT EXISTS public.team_war_call_responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  war_call_id uuid NOT NULL REFERENCES public.team_war_calls(id) ON DELETE CASCADE,
  client_id text NOT NULL,
  player_name text NOT NULL,
  player_side text NOT NULL CHECK (player_side IN ('everlast', 'ally', 'enemy', 'neutral')),
  readiness_status text NOT NULL CHECK (readiness_status IN ('ready', 'omw', 'afk')),
  note text NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (war_call_id, client_id)
);

CREATE INDEX IF NOT EXISTS idx_team_war_call_responses_call ON public.team_war_call_responses(war_call_id, updated_at DESC);

CREATE TABLE IF NOT EXISTS public.retro_frag_guard_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  character_name text NOT NULL UNIQUE,
  side text NOT NULL CHECK (side IN ('everlast', 'ally', 'enemy', 'neutral')),
  unjust_24h integer NOT NULL DEFAULT 0,
  unjust_7d integer NOT NULL DEFAULT 0,
  unjust_30d integer NOT NULL DEFAULT 0,
  notes text NULL,
  updated_by text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_retro_frag_guard_entries_updated ON public.retro_frag_guard_entries(updated_at DESC);

ALTER TABLE public.team_war_calls ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.team_war_call_responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.retro_frag_guard_entries ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.get_team_war_calls(p_secret text)
RETURNS SETOF public.team_war_calls
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT *
    FROM public.team_war_calls
    ORDER BY CASE WHEN status = 'active' THEN 0 ELSE 1 END, COALESCE(starts_at, created_at) DESC;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_team_war_call_responses(p_secret text, p_war_call_id uuid)
RETURNS SETOF public.team_war_call_responses
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT *
    FROM public.team_war_call_responses
    WHERE war_call_id = p_war_call_id
    ORDER BY updated_at DESC;
END;
$$;

CREATE OR REPLACE FUNCTION public.create_team_war_call(
  p_secret text,
  p_title text,
  p_meeting_point text DEFAULT NULL,
  p_starts_at timestamptz DEFAULT NULL,
  p_notes text DEFAULT NULL,
  p_created_by text DEFAULT NULL
)
RETURNS public.team_war_calls
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row public.team_war_calls;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  UPDATE public.team_war_calls
  SET status = 'ended', updated_at = now()
  WHERE status = 'active';

  INSERT INTO public.team_war_calls (title, meeting_point, starts_at, notes, created_by, status)
  VALUES (p_title, p_meeting_point, p_starts_at, p_notes, p_created_by, 'active')
  RETURNING * INTO v_row;

  RETURN v_row;
END;
$$;

CREATE OR REPLACE FUNCTION public.upsert_team_war_call_response(
  p_secret text,
  p_war_call_id uuid,
  p_client_id text,
  p_player_name text,
  p_player_side text,
  p_readiness_status text,
  p_note text DEFAULT NULL
)
RETURNS public.team_war_call_responses
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row public.team_war_call_responses;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  INSERT INTO public.team_war_call_responses (war_call_id, client_id, player_name, player_side, readiness_status, note, updated_at)
  VALUES (p_war_call_id, p_client_id, p_player_name, p_player_side, p_readiness_status, p_note, now())
  ON CONFLICT (war_call_id, client_id)
  DO UPDATE SET
    player_name = EXCLUDED.player_name,
    player_side = EXCLUDED.player_side,
    readiness_status = EXCLUDED.readiness_status,
    note = EXCLUDED.note,
    updated_at = now()
  RETURNING * INTO v_row;

  RETURN v_row;
END;
$$;

CREATE OR REPLACE FUNCTION public.end_team_war_call(p_secret text, p_war_call_id uuid)
RETURNS public.team_war_calls
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row public.team_war_calls;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  UPDATE public.team_war_calls
  SET status = 'ended', updated_at = now()
  WHERE id = p_war_call_id
  RETURNING * INTO v_row;

  RETURN v_row;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_retro_frag_guard_entries(p_secret text)
RETURNS SETOF public.retro_frag_guard_entries
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.retro_frag_guard_entries
    ORDER BY updated_at DESC, character_name ASC;
END;
$$;

CREATE OR REPLACE FUNCTION public.upsert_retro_frag_guard_entry(
  p_secret text,
  p_character_name text,
  p_side text,
  p_unjust_24h integer DEFAULT 0,
  p_unjust_7d integer DEFAULT 0,
  p_unjust_30d integer DEFAULT 0,
  p_notes text DEFAULT NULL,
  p_updated_by text DEFAULT NULL
)
RETURNS public.retro_frag_guard_entries
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_row public.retro_frag_guard_entries;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  INSERT INTO public.retro_frag_guard_entries (
    character_name, side, unjust_24h, unjust_7d, unjust_30d, notes, updated_by, updated_at
  )
  VALUES (
    p_character_name, p_side, GREATEST(COALESCE(p_unjust_24h, 0), 0), GREATEST(COALESCE(p_unjust_7d, 0), 0),
    GREATEST(COALESCE(p_unjust_30d, 0), 0), p_notes, p_updated_by, now()
  )
  ON CONFLICT (character_name)
  DO UPDATE SET
    side = EXCLUDED.side,
    unjust_24h = EXCLUDED.unjust_24h,
    unjust_7d = EXCLUDED.unjust_7d,
    unjust_30d = EXCLUDED.unjust_30d,
    notes = EXCLUDED.notes,
    updated_by = EXCLUDED.updated_by,
    updated_at = now()
  RETURNING * INTO v_row;

  RETURN v_row;
END;
$$;

CREATE OR REPLACE FUNCTION public.delete_retro_frag_guard_entry(p_secret text, p_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  DELETE FROM public.retro_frag_guard_entries WHERE id = p_id;
  RETURN FOUND;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_team_war_calls(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_team_war_call_responses(text, uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.create_team_war_call(text, text, text, timestamptz, text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.upsert_team_war_call_response(text, uuid, text, text, text, text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.end_team_war_call(text, uuid) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_retro_frag_guard_entries(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.upsert_retro_frag_guard_entry(text, text, text, integer, integer, integer, text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.delete_retro_frag_guard_entry(text, uuid) TO anon, authenticated;
