/*
# Create War Sessions table

1. New Tables
- `war_sessions`: Stores manually recorded war session time windows.
  - id (uuid, PK)
  - name (text, not null) — session label
  - notes (text, nullable) — optional session notes
  - scoring_mode (text, not null, default 'last-hit') — 'last-hit' | 'participation'
  - status (text, not null, default 'active') — 'active' | 'ended'
  - started_at (timestamptz, not null) — session start timestamp
  - ended_at (timestamptz, nullable) — session end timestamp
  - created_at (timestamptz, default now())
  - updated_at (timestamptz, default now())

2. Security
- Enable RLS on war_sessions.
- NO direct grants to anon/authenticated — all access through SECURITY DEFINER RPC functions
  that verify the CANDY_SESSION_SECRET server-side token, same pattern as all other tables.
- Grant service_role full access for server-side operations.

3. RPC Functions (all SECURITY DEFINER, verify p_secret)
- get_war_sessions(p_secret, p_limit) — list sessions
- get_war_session(p_secret, p_id) — single session by id
- create_war_session(p_secret, p_name, p_scoring_mode, p_notes) — create active session
- end_war_session(p_secret, p_id, p_notes) — end a session
- update_war_session(p_secret, p_id, p_name, p_notes, p_scoring_mode) — update session details
- delete_war_session(p_secret, p_id) — delete a session

4. Notes
- Sessions are time windows; event association is computed at read time
  using canonical_death_events.death_time and character_level_events.observed_at
  falling between started_at and ended_at (NULL ended_at = now).
- No data is copied or duplicated — sessions reference canonical events by time range.
- Multiple authorized visitors see the same sessions (shared data, not per-user).
*/

CREATE TABLE IF NOT EXISTS war_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  notes text,
  scoring_mode text NOT NULL DEFAULT 'last-hit' CHECK (scoring_mode IN ('last-hit', 'participation')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'ended')),
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE war_sessions ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON war_sessions TO service_role;

-- Helper: verify candy secret
-- Reuse the existing verify_candy_secret pattern from create_secure_data_functions.sql
-- We inline the check here for independence.

-- List sessions
CREATE OR REPLACE FUNCTION get_war_sessions(p_secret text, p_limit int DEFAULT 50)
RETURNS SETOF war_sessions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF p_secret IS NULL OR p_secret <> current_setting('app.candy_secret', true) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
  SELECT * FROM war_sessions
  ORDER BY started_at DESC
  LIMIT p_limit;
END;
$$;

-- Get single session
CREATE OR REPLACE FUNCTION get_war_session(p_secret text, p_id uuid)
RETURNS war_sessions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result war_sessions;
BEGIN
  IF p_secret IS NULL OR p_secret <> current_setting('app.candy_secret', true) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  SELECT * INTO result FROM war_sessions WHERE id = p_id;
  RETURN result;
END;
$$;

-- Create session
CREATE OR REPLACE FUNCTION create_war_session(
  p_secret text,
  p_name text,
  p_scoring_mode text DEFAULT 'last-hit',
  p_notes text DEFAULT NULL
)
RETURNS war_sessions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result war_sessions;
BEGIN
  IF p_secret IS NULL OR p_secret <> current_setting('app.candy_secret', true) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  IF p_name IS NULL OR length(trim(p_name)) = 0 THEN
    RAISE EXCEPTION 'Session name required';
  END IF;
  IF p_scoring_mode NOT IN ('last-hit', 'participation') THEN
    RAISE EXCEPTION 'Invalid scoring mode';
  END IF;
  INSERT INTO war_sessions (name, scoring_mode, notes, status, started_at)
  VALUES (trim(p_name), p_scoring_mode, p_notes, 'active', now())
  RETURNING * INTO result;
  RETURN result;
END;
$$;

-- End session
CREATE OR REPLACE FUNCTION end_war_session(
  p_secret text,
  p_id uuid,
  p_notes text DEFAULT NULL
)
RETURNS war_sessions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result war_sessions;
BEGIN
  IF p_secret IS NULL OR p_secret <> current_setting('app.candy_secret', true) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  UPDATE war_sessions
  SET status = 'ended', ended_at = now(), updated_at = now(),
      notes = COALESCE(p_notes, notes)
  WHERE id = p_id AND status = 'active'
  RETURNING * INTO result;
  IF result IS NULL THEN
    RAISE EXCEPTION 'Session not found or already ended';
  END IF;
  RETURN result;
END;
$$;

-- Update session details
CREATE OR REPLACE FUNCTION update_war_session(
  p_secret text,
  p_id uuid,
  p_name text DEFAULT NULL,
  p_notes text DEFAULT NULL,
  p_scoring_mode text DEFAULT NULL
)
RETURNS war_sessions
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result war_sessions;
BEGIN
  IF p_secret IS NULL OR p_secret <> current_setting('app.candy_secret', true) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  UPDATE war_sessions
  SET name = COALESCE(NULLIF(p_name, ''), name),
      notes = COALESCE(p_notes, notes),
      scoring_mode = COALESCE(NULLIF(p_scoring_mode, ''), scoring_mode),
      updated_at = now()
  WHERE id = p_id
  RETURNING * INTO result;
  IF result IS NULL THEN
    RAISE EXCEPTION 'Session not found';
  END IF;
  RETURN result;
END;
$$;

-- Delete session
CREATE OR REPLACE FUNCTION delete_war_session(p_secret text, p_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF p_secret IS NULL OR p_secret <> current_setting('app.candy_secret', true) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  DELETE FROM war_sessions WHERE id = p_id;
  RETURN FOUND;
END;
$$;

-- Revoke public execute, grant only via RPC calls from server
REVOKE EXECUTE ON FUNCTION get_war_sessions(text, int) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION get_war_session(text, uuid) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION create_war_session(text, text, text, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION end_war_session(text, uuid, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION update_war_session(text, uuid, text, text, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION delete_war_session(text, uuid) FROM PUBLIC, anon;
