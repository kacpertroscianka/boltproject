-- Candy Visitors: distinct active SHARED-PASSWORD SESSIONS in the last 90 seconds.
-- IMPORTANT: This migration is provided for later controlled deployment.
-- The web app degrades to "—" until it is installed on the target Supabase DB.
-- No existing death, level, guild, auth or sync tables are modified.

CREATE TABLE IF NOT EXISTS public.candy_presence (
  session_hash text PRIMARY KEY CHECK (session_hash ~ '^[0-9a-f]{64}$'),
  last_seen timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS candy_presence_last_seen_idx
  ON public.candy_presence (last_seen);

ALTER TABLE public.candy_presence ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.candy_presence FROM PUBLIC, anon, authenticated;

-- The Next.js server authenticates the visitor cookie, creates a non-reversible
-- per-session keyed HMAC, then calls this RPC with its server-side secret.
-- The underlying table is never directly accessible to anonymous clients.
CREATE OR REPLACE FUNCTION public.touch_candy_presence(
  p_secret text,
  p_session_hash text
)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  active_count integer;
BEGIN
  IF NOT COALESCE(public.verify_candy_secret(p_secret), false) THEN
    RAISE EXCEPTION 'Unauthorized' USING ERRCODE = '42501';
  END IF;

  IF p_session_hash IS NULL OR p_session_hash !~ '^[0-9a-f]{64}$' THEN
    RAISE EXCEPTION 'Invalid presence identifier' USING ERRCODE = '22023';
  END IF;

  -- Stale sessions are removed opportunistically, so a separate cron job
  -- and any additional background infrastructure are unnecessary.
  DELETE FROM public.candy_presence
    WHERE last_seen < now() - interval '90 seconds';

  INSERT INTO public.candy_presence(session_hash, last_seen)
  VALUES (p_session_hash, now())
  ON CONFLICT (session_hash)
  DO UPDATE SET last_seen = EXCLUDED.last_seen;

  SELECT COUNT(*)::integer INTO active_count
  FROM public.candy_presence
  WHERE last_seen >= now() - interval '90 seconds';

  RETURN active_count;
END;
$$;

REVOKE ALL ON FUNCTION public.touch_candy_presence(text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.touch_candy_presence(text, text) TO anon, authenticated;
