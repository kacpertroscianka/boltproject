-- Read-only, authenticated lookup for a character's recorded PvP events.
-- Fixes incomplete profile statistics caused by filtering a limited global feed.
-- Deploy this migration to the existing Supabase project before using the new profile.
CREATE OR REPLACE FUNCTION public.get_combat_events_for_char(
  p_secret text,
  p_name text,
  p_limit integer DEFAULT 5000
)
RETURNS SETOF public.canonical_war_events
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  RETURN QUERY
  SELECT w.*
  FROM public.canonical_war_events w
  WHERE w.is_player_kill = true
    AND lower(w.character_name) <> lower(p_name)
    AND (
      lower(w.killer_name) = lower(p_name)
      OR EXISTS (
        SELECT 1 FROM jsonb_array_elements_text(
          CASE WHEN jsonb_typeof(w.participated_players) = 'array'
            THEN w.participated_players ELSE '[]'::jsonb END
        ) AS participant(name)
        WHERE lower(participant.name) = lower(p_name)
      )
      OR EXISTS (
        SELECT 1 FROM jsonb_array_elements_text(
          CASE WHEN jsonb_typeof(w.assisted_players) = 'array'
            THEN w.assisted_players ELSE '[]'::jsonb END
        ) AS assistant(name)
        WHERE lower(assistant.name) = lower(p_name)
      )
    )
  ORDER BY w.death_time DESC, w.event_id
  LIMIT LEAST(GREATEST(COALESCE(p_limit, 5000), 1), 5000);
END;
$$;

REVOKE ALL ON FUNCTION public.get_combat_events_for_char(text, text, integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_combat_events_for_char(text, text, integer) TO anon, authenticated;
