/*
# Fix advisor findings: sync_queue policies, search_path, pg_net schema

1. Security Changes
- Adds RLS policies to `sync_queue` for `service_role` only. This table
  is used exclusively by edge functions (which use the service role key
  and bypass RLS), so no anon/authenticated policies are needed. The
  policies exist to satisfy the linter and make the access model explicit.
- Sets a fixed `search_path` on the `set_updated_at()` trigger function
  to address the mutable search_path warning.
- Moves the `pg_net` extension from `public` to `extensions` schema.
2. Notes
- `sync_queue` policies are scoped to `service_role` because the table
  is internal infrastructure — only the edge functions read/write it.
- `set_updated_at` is updated with `search_path = public, extensions`
  to match the default expected schema order.
*/

-- sync_queue policies (service_role only — edge functions bypass RLS)
GRANT SELECT, INSERT, UPDATE, DELETE ON sync_queue TO service_role;

DROP POLICY IF EXISTS "service_role_all_sync_queue" ON sync_queue;
CREATE POLICY "service_role_all_sync_queue"
ON sync_queue FOR SELECT
TO service_role USING (true);

DROP POLICY IF EXISTS "service_role_insert_sync_queue" ON sync_queue;
CREATE POLICY "service_role_insert_sync_queue"
ON sync_queue FOR INSERT
TO service_role WITH CHECK (true);

DROP POLICY IF EXISTS "service_role_update_sync_queue" ON sync_queue;
CREATE POLICY "service_role_update_sync_queue"
ON sync_queue FOR UPDATE
TO service_role USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "service_role_delete_sync_queue" ON sync_queue;
CREATE POLICY "service_role_delete_sync_queue"
ON sync_queue FOR DELETE
TO service_role USING (true);

-- Fix mutable search_path on set_updated_at
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public, extensions
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Move pg_net from public to extensions schema
DROP EXTENSION IF EXISTS pg_net;
CREATE EXTENSION pg_net SCHEMA extensions;
