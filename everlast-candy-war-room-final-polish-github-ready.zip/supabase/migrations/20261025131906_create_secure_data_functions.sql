-- Create a SECURITY DEFINER function that verifies a server-side secret token
-- before returning any protected data. The anon key is public (in the browser bundle),
-- but the CANDY_SESSION_SECRET is server-only, so only the Next.js API route can
-- successfully call this function.

-- Helper function to verify the secret token
CREATE OR REPLACE FUNCTION public.verify_candy_secret(p_secret text)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p_secret IS NOT NULL
    AND p_secret = current_setting('app.candy_session_secret', true)
$$;

-- Main function: returns canonical_war_events
CREATE OR REPLACE FUNCTION public.get_war_events(p_secret text, p_limit int DEFAULT 2000)
RETURNS SETOF public.canonical_war_events
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.canonical_war_events
    ORDER BY death_time DESC
    LIMIT p_limit;
END;
$$;

-- Function: returns canonical_death_events
CREATE OR REPLACE FUNCTION public.get_death_events(p_secret text, p_limit int DEFAULT 200)
RETURNS SETOF public.canonical_death_events
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.canonical_death_events
    ORDER BY death_time DESC
    LIMIT p_limit;
END;
$$;

-- Function: returns characters by side
CREATE OR REPLACE FUNCTION public.get_characters_by_side(p_secret text, p_sides text[])
RETURNS SETOF public.characters
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.characters
    WHERE side = ANY(p_sides)
    ORDER BY level DESC;
END;
$$;

-- Function: returns character by name
CREATE OR REPLACE FUNCTION public.get_character_by_name(p_secret text, p_name text)
RETURNS public.characters
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_result public.characters;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  SELECT * INTO v_result FROM public.characters
    WHERE lower(name) = lower(p_name) LIMIT 1;
  RETURN v_result;
END;
$$;

-- Function: search characters
CREATE OR REPLACE FUNCTION public.search_characters(p_secret text, p_query text, p_limit int DEFAULT 20)
RETURNS SETOF public.characters
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.characters
    WHERE name ILIKE '%' || p_query || '%'
    ORDER BY level DESC
    LIMIT p_limit;
END;
$$;

-- Function: returns guilds
CREATE OR REPLACE FUNCTION public.get_guilds(p_secret text)
RETURNS SETOF public.guilds
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.guilds ORDER BY name;
END;
$$;

-- Function: returns activity snapshots
CREATE OR REPLACE FUNCTION public.get_activity_snapshots(p_secret text, p_limit int DEFAULT 20)
RETURNS SETOF public.activity_snapshots
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.activity_snapshots
    ORDER BY snapshot_at DESC
    LIMIT p_limit;
END;
$$;

-- Function: returns sync logs
CREATE OR REPLACE FUNCTION public.get_sync_logs(p_secret text, p_limit int DEFAULT 10)
RETURNS SETOF public.sync_log
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.sync_log
    ORDER BY started_at DESC
    LIMIT p_limit;
END;
$$;

-- Function: returns level events (ups or downs)
CREATE OR REPLACE FUNCTION public.get_level_events(p_secret text, p_direction text, p_limit int DEFAULT 20)
RETURNS SETOF public.character_level_events
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  IF p_direction = 'up' THEN
    RETURN QUERY
      SELECT * FROM public.character_level_events
      WHERE level_diff > 0
      ORDER BY observed_at DESC
      LIMIT p_limit;
  ELSIF p_direction = 'down' THEN
    RETURN QUERY
      SELECT * FROM public.character_level_events
      WHERE level_diff < 0
      ORDER BY observed_at DESC
      LIMIT p_limit;
  END IF;
END;
$$;

-- Function: returns level events for a character
CREATE OR REPLACE FUNCTION public.get_level_events_for_char(p_secret text, p_name text, p_limit int DEFAULT 50)
RETURNS SETOF public.character_level_events
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.character_level_events
    WHERE lower(character_name) = lower(p_name)
    ORDER BY observed_at DESC
    LIMIT p_limit;
END;
$$;

-- Function: returns deaths for a character by name
CREATE OR REPLACE FUNCTION public.get_deaths_for_char(p_secret text, p_name text, p_limit int DEFAULT 50)
RETURNS SETOF public.canonical_death_events
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT * FROM public.canonical_death_events
    WHERE lower(character_name) = lower(p_name)
    ORDER BY death_time DESC
    LIMIT p_limit;
END;
$$;

-- Function: level guild leaderboard
CREATE OR REPLACE FUNCTION public.get_level_leaderboard(p_secret text, p_days int DEFAULT 7)
RETURNS TABLE(character_name text, level_diff int, char_name text, char_side text)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
    SELECT e.character_name::text, e.level_diff::int, c.name::text, c.side::text
    FROM public.character_level_events e
    LEFT JOIN public.characters c ON lower(c.name) = lower(e.character_name)
    WHERE e.world = 'Sinistra'
      AND e.level_diff > 0
      AND e.observed_at >= now() - (p_days || ' days')::interval;
END;
$$;

-- Grant EXECUTE to anon and authenticated so the browser (via anon key) can call these.
-- The secret token check inside each function is the real gatekeeper.
GRANT EXECUTE ON FUNCTION public.verify_candy_secret(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_war_events(text, int) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_death_events(text, int) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_characters_by_side(text, text[]) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_character_by_name(text, text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.search_characters(text, text, int) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_guilds(text) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_activity_snapshots(text, int) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_sync_logs(text, int) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_level_events(text, text, int) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_level_events_for_char(text, text, int) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_deaths_for_char(text, text, int) TO anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_level_leaderboard(text, int) TO anon, authenticated;
