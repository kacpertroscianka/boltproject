/*
# Create canonical_death_events table

## Purpose
Creates a deduplicated, canonical death event table that stores every unique
character death exactly once. Uniqueness is based on (character_name, death_time)
— NOT on the cause/reason text, which varied between sync runs and caused
duplicate rows in the original death_events table.

## New Table: canonical_death_events
- `id` (uuid PK)
- `character_id` (uuid, nullable — links to characters table)
- `character_name` (text, not null)
- `character_level` (integer, not null)
- `character_vocation` (text, nullable)
- `character_side` (war_side enum, not null, default 'neutral')
- `killer_name` (text, nullable)
- `killer_vocation` (text, nullable)
- `killer_level` (integer, nullable)
- `killer_guild_name` (text, nullable)
- `killer_side` (war_side, nullable)
- `reason` (text, not null — the original TibiaData reason field)
- `is_pvp` (boolean, default false)
- `is_player_kill` (boolean, default false)
- `death_time` (timestamptz, not null)
- `killers` (jsonb — full killers array from API: [{name, player, summon, traded}])
- `assists` (jsonb — full assists array from API: [{name, player, summon, traded}])
- `participated_players` (jsonb — player killers only, for backward compat)
- `assisted_players` (jsonb — player assistants only)
- `source` (text, default 'tibiadata')
- `world` (text, nullable)
- `created_at` (timestamptz, default now())
- `updated_at` (timestamptz, default now())

## Unique Constraint
- `canonical_death_events_character_name_death_time_key` on (character_name, death_time)
  This ensures idempotent inserts — re-syncing the same character will NOT create
  duplicates because the same death timestamp for the same character is rejected.

## Indexes
- `idx_canonical_deaths_time` on (death_time DESC) — for time-range queries
- `idx_canonical_deaths_side` on (character_side, killer_side) — for war score queries
- `idx_canonical_deaths_pvp` on (is_player_kill) WHERE is_player_kill = true — partial index for PvP

## Security
- RLS enabled
- CRUD granted to anon, authenticated (single-tenant public app)
- service_role granted for edge function access
*/
CREATE TABLE IF NOT EXISTS canonical_death_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  character_id uuid,
  character_name text NOT NULL,
  character_level integer NOT NULL,
  character_vocation text,
  character_side war_side NOT NULL DEFAULT 'neutral',
  killer_name text,
  killer_vocation text,
  killer_level integer,
  killer_guild_name text,
  killer_side war_side,
  reason text NOT NULL,
  is_pvp boolean DEFAULT false,
  is_player_kill boolean DEFAULT false,
  death_time timestamptz NOT NULL,
  killers jsonb DEFAULT '[]'::jsonb,
  assists jsonb DEFAULT '[]'::jsonb,
  participated_players jsonb DEFAULT '[]'::jsonb,
  assisted_players jsonb DEFAULT '[]'::jsonb,
  source text DEFAULT 'tibiadata',
  world text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE canonical_death_events ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON canonical_death_events TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON canonical_death_events TO service_role;

DROP POLICY IF EXISTS "anon_select_canonical_deaths" ON canonical_death_events;
CREATE POLICY "anon_select_canonical_deaths" ON canonical_death_events FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_canonical_deaths" ON canonical_death_events;
CREATE POLICY "anon_insert_canonical_deaths" ON canonical_death_events FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_canonical_deaths" ON canonical_death_events;
CREATE POLICY "anon_update_canonical_deaths" ON canonical_death_events FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_canonical_deaths" ON canonical_death_events;
CREATE POLICY "anon_delete_canonical_deaths" ON canonical_death_events FOR DELETE
  TO anon, authenticated USING (true);

CREATE UNIQUE INDEX IF NOT EXISTS canonical_death_events_character_name_death_time_key
  ON canonical_death_events (character_name, death_time);

CREATE INDEX IF NOT EXISTS idx_canonical_deaths_time ON canonical_death_events (death_time DESC);
CREATE INDEX IF NOT EXISTS idx_canonical_deaths_side ON canonical_death_events (character_side, killer_side);
CREATE INDEX IF NOT EXISTS idx_canonical_deaths_pvp ON canonical_death_events (is_player_kill) WHERE is_player_kill = true;
