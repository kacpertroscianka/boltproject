/*
# Enable Supabase Realtime on intelligence tables

1. Changes
- Adds `death_events`, `character_level_events`, and `characters` to the
  `supabase_realtime` publication so the dashboard can subscribe to
  INSERT/UPDATE events and auto-refresh without polling.
2. Security
- No RLS changes. Realtime respects existing RLS policies — clients only
  receive rows they are allowed to see.
3. Notes
- Only public intelligence tables are added; user-specific tables
  (watchlists, discord_webhooks) are intentionally excluded.
*/

ALTER PUBLICATION supabase_realtime ADD TABLE public.death_events;
ALTER PUBLICATION supabase_realtime ADD TABLE public.character_level_events;
ALTER PUBLICATION supabase_realtime ADD TABLE public.characters;
