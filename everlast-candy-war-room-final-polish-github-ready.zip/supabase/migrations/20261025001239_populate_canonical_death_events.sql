/*
# Populate canonical_death_events from death_events (deduplication migration)

## What this does
For each unique (character_name, death_time) group in death_events, selects the
"best" row — the one with the most complete data — and inserts it into
canonical_death_events. The selection criteria:
1. Prefer rows whose cause field looks like an API reason (contains "at Level" or "by" with a period)
2. Among ties, prefer the earliest created_at (first observation)
3. Coalesce killer info from all duplicate rows when the best row has nulls

## Duplicate handling
- 92 PvP duplicate groups and 519 total duplicate rows are collapsed
- The original death_events table is NOT modified — it remains as historical backup
- The canonical_death_events table has a unique constraint on (character_name, death_time)
  that prevents future duplicates

## Notes
- killers and assists arrays are reconstructed from participated_players since
  the original sync did not store them. Future syncs will store the full API arrays.
- assisted_players is set to '[]' for existing data since assists were never recorded.
  Future syncs will populate this from the API.
*/
INSERT INTO canonical_death_events (
  character_id, character_name, character_level, character_vocation, character_side,
  killer_name, killer_vocation, killer_level, killer_guild_name, killer_side,
  reason, is_pvp, is_player_kill, death_time,
  killers, assists, participated_players, assisted_players,
  source, world, created_at, updated_at
)
SELECT
  best.character_id,
  best.character_name,
  best.character_level,
  best.character_vocation,
  best.character_side,
  best.killer_name,
  best.killer_vocation,
  best.killer_level,
  best.killer_guild_name,
  best.killer_side,
  best.cause AS reason,
  COALESCE(best.is_pvp, false),
  COALESCE(best.is_player_kill, false),
  best.death_time,
  -- Reconstruct killers array from participated_players (backward compat)
  COALESCE(
    (SELECT jsonb_agg(jsonb_build_object('name', p, 'player', true)) FROM jsonb_array_elements_text(best.participated_players) AS p),
    CASE WHEN best.killer_name IS NOT NULL AND best.killer_name != best.character_name
      THEN jsonb_build_array(jsonb_build_object('name', best.killer_name, 'player', true))
      ELSE '[]'::jsonb
    END
  ),
  '[]'::jsonb, -- assists not available in historical data
  best.participated_players,
  '[]'::jsonb, -- assisted_players not available in historical data
  COALESCE(best.source, 'tibiadata'),
  'Sinistra',
  best.created_at,
  now()
FROM (
  SELECT DISTINCT ON (d.character_name, d.death_time)
    d.*
  FROM death_events d
  ORDER BY
    d.character_name,
    d.death_time,
    -- Prefer API reason text (has "at Level" or ends with period) over reconstructed
    CASE
      WHEN d.cause LIKE '%at Level%' THEN 0
      WHEN d.cause LIKE '%.%' AND d.cause NOT LIKE 'Died at level%' AND d.cause NOT LIKE 'Died to%' THEN 1
      WHEN d.cause LIKE 'Killed by%' AND d.cause NOT LIKE '%.%' THEN 2
      WHEN d.cause LIKE 'Died at level%' THEN 3
      WHEN d.cause LIKE 'Died to%' THEN 4
      ELSE 5
    END,
    -- Among same quality, prefer the one with more participants
    COALESCE(jsonb_array_length(
      CASE WHEN jsonb_typeof(d.participated_players) = 'array'
           THEN d.participated_players ELSE '[]'::jsonb END
    ), 0) DESC,
    -- Among ties, prefer earliest created_at (first observation is most reliable)
    d.created_at ASC
) best
ON CONFLICT (character_name, death_time) DO NOTHING;
