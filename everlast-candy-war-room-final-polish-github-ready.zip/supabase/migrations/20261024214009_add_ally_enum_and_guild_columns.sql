/*
# Add 'ally' value to war_side enum

1. Schema Changes
- Adds `ally` value to the `war_side` enum type. This represents
  members of Terror Squad (allied friendly guild).
- Adds `alliance` column to `guilds` table.
- Adds `display_label` column to `guilds` table.
- Updates existing guild records with alliance and display_label values.
2. Security
- No RLS changes. New columns inherit existing table-level grants.
3. Notes
- The INSERT for the Terror Squad guild record is in a separate
  migration because Postgres requires new enum values to be
  committed before they can be used in INSERT/UPDATE statements.
*/

-- Add 'ally' to war_side enum
ALTER TYPE war_side ADD VALUE IF NOT EXISTS 'ally';

-- Add alliance and display_label columns to guilds
ALTER TABLE guilds ADD COLUMN IF NOT EXISTS alliance text;
ALTER TABLE guilds ADD COLUMN IF NOT EXISTS display_label text;

-- Update existing guild records
UPDATE guilds SET alliance = 'Everlast Alliance', display_label = 'Everlast' WHERE name = 'Everlast';
UPDATE guilds SET alliance = NULL, display_label = 'Mandatory Again' WHERE name = 'Mandatory Again';
