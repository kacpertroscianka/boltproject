/*
# Add unique constraint on sync_queue.character_id

1. Changes
- Adds a UNIQUE constraint on `sync_queue.character_id` so the upsert
  in the sync-guild edge function can use `onConflict: "character_id"`.
  Without this, the upsert silently fails because Postgres cannot
  resolve the conflict target.
2. Security
- No RLS or privilege changes.
*/

CREATE UNIQUE INDEX IF NOT EXISTS sync_queue_character_id_unique
ON public.sync_queue (character_id)
WHERE character_id IS NOT NULL;
