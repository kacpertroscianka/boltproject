-- Phase 11: efficient 30-day last-hit aggregation and server validation of self-reported war-call check-ins.
-- Apply AFTER 20261026170000_battle_command_and_frag_guard.sql.
-- Does not modify canonical war data or existing submitted statuses.

CREATE INDEX IF NOT EXISTS idx_canonical_death_events_death_time
  ON public.canonical_death_events (death_time DESC);

CREATE OR REPLACE FUNCTION public.get_retro_observed_last_hits(p_secret text)
RETURNS TABLE(character_name text, last_hits_24h bigint, last_hits_7d bigint, last_hits_30d bigint)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;
  RETURN QUERY
  SELECT lower(btrim(e.killer_name))::text AS character_name,
     count(*) FILTER (WHERE e.death_time >= now() - interval '24 hours') AS last_hits_24h,
     count(*) FILTER (WHERE e.death_time >= now() - interval '7 days') AS last_hits_7d,
     count(*) AS last_hits_30d
  FROM public.canonical_war_events e
  WHERE e.war_category = 'friendly_kills_enemy'
    AND e.death_time >= now() - interval '30 days'
    AND e.killer_name IS NOT NULL AND btrim(e.killer_name) <> ''
  GROUP BY lower(btrim(e.killer_name));
END;
$$;
REVOKE ALL ON FUNCTION public.get_retro_observed_last_hits(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_retro_observed_last_hits(text) TO anon, authenticated;

-- Do not trust a browser-supplied guild or arbitrary nickname. The shared gate still cannot
-- prove the visitor owns the selected character; responses remain self-reported.
CREATE OR REPLACE FUNCTION public.upsert_team_war_call_response(
  p_secret text,
  p_war_call_id uuid,
  p_client_id text,
  p_player_name text,
  p_player_side text,
  p_readiness_status text,
  p_note text DEFAULT NULL
)
RETURNS public.team_war_call_responses
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_row public.team_war_call_responses;
  v_side text;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.team_war_calls WHERE id = p_war_call_id AND status = 'active')
    THEN RAISE EXCEPTION 'No active War Call'; END IF;
  IF p_readiness_status NOT IN ('ready', 'omw', 'afk')
    THEN RAISE EXCEPTION 'Invalid readiness status'; END IF;
  IF length(p_client_id) < 8 OR length(p_client_id) > 100 OR length(coalesce(p_note,'')) > 250
    THEN RAISE EXCEPTION 'Invalid response fields'; END IF;
  SELECT c.side::text INTO v_side FROM public.characters c
    WHERE lower(c.name) = lower(btrim(p_player_name)) AND c.side::text IN ('everlast','ally') LIMIT 1;
  IF v_side IS NULL OR v_side <> p_player_side THEN RAISE EXCEPTION 'Character must be from the alliance'; END IF;
  IF EXISTS (
    SELECT 1 FROM public.team_war_call_responses r
    WHERE r.war_call_id = p_war_call_id AND lower(r.player_name) = lower(btrim(p_player_name))
      AND r.client_id <> p_client_id
  ) THEN RAISE EXCEPTION 'This character already checked in from another session'; END IF;

  INSERT INTO public.team_war_call_responses (war_call_id, client_id, player_name, player_side, readiness_status, note, updated_at)
  VALUES (p_war_call_id, p_client_id, btrim(p_player_name), v_side, p_readiness_status, p_note, now())
  ON CONFLICT (war_call_id, client_id) DO UPDATE
    SET player_name=excluded.player_name, player_side=excluded.player_side,
        readiness_status=excluded.readiness_status, note=excluded.note, updated_at=now()
  RETURNING * INTO v_row;
  RETURN v_row;
END;
$$;
REVOKE ALL ON FUNCTION public.upsert_team_war_call_response(text, uuid, text, text, text, text, text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.upsert_team_war_call_response(text, uuid, text, text, text, text, text) TO anon, authenticated;

-- Only one active War Call: lightweight RPC for frequent polling.
CREATE OR REPLACE FUNCTION public.get_active_team_war_call(p_secret text)
RETURNS public.team_war_calls
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE v_row public.team_war_calls;
BEGIN
  IF NOT public.verify_candy_secret(p_secret) THEN RAISE EXCEPTION 'Unauthorized'; END IF;
  SELECT * INTO v_row FROM public.team_war_calls
    WHERE status = 'active' ORDER BY created_at DESC LIMIT 1;
  RETURN v_row;
END;
$$;
REVOKE ALL ON FUNCTION public.get_active_team_war_call(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_active_team_war_call(text) TO anon, authenticated;
