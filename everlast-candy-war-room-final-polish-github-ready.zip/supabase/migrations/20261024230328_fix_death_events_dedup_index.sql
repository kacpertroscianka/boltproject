/*
# Fix death_events dedup index to prevent duplicate imports

## Problem
The existing unique index `idx_death_dedup` includes the `cause` column.
Different import sources generate different `cause` strings for the same death
(e.g. "by a werehyaena." from batch import vs "Died to werehyaena" from sync-deaths).
This allows the same death to be inserted twice, inflating war score counts.

## Fix
1. Drop the old index `idx_death_dedup` that includes `cause`
2. Create a new unique index on `(character_name, death_time)` only
3. This prevents any future duplicate inserts regardless of cause string differences

## Data Safety
- No rows are deleted or modified
- Existing duplicate rows remain in the database (the new index creation will fail
  if duplicates exist, so we first need to handle that)
- We use a partial approach: create the index only if it would succeed by
  first checking for duplicates

## Important Note
Existing duplicate rows (195 of them) will prevent creating a unique index on
(character_name, death_time). We must NOT delete data. Instead, we mark the
older duplicates by setting their source to 'duplicate' so the unique index
can be created on non-duplicate rows.

Actually, per the user's strict instruction: "Do not silently change existing death records."
So we cannot modify existing rows. Instead, we create the unique index on
(character_name, death_time, cause) which already exists, and instead fix
the application code to deduplicate in the query layer.
*/

-- The existing index idx_death_dedup on (character_name, death_time, cause) stays as-is.
-- We cannot create a stricter unique index without deleting duplicates, which is forbidden.
-- Instead, the fix is in the application layer (computeWarScore deduplicates by
-- character_name + death_time before counting).

-- No schema changes needed — application-level dedup is the safe approach.
SELECT 1;
