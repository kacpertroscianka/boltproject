/*
# Fix sync_queue unique constraint for upsert support

1. Changes
- Drops the partial unique index `sync_queue_character_id_unique` that
  cannot be used with ON CONFLICT.
- Creates a regular UNIQUE constraint on `character_id` that works with
  the Supabase client's `onConflict: "character_id"` upsert pattern.
- Since `character_id` is nullable and Postgres treats multiple NULLs
  as distinct, this won't conflict with rows that have NULL character_id.
2. Security
- No changes.
*/

DROP INDEX IF EXISTS sync_queue_character_id_unique;
ALTER TABLE public.sync_queue ADD CONSTRAINT sync_queue_character_id_unique UNIQUE (character_id);
