/*
# Install pg_cron and pg_net for scheduled sync jobs

1. Changes
- Creates the `pg_cron` extension (scoped to `extensions` schema, the Supabase default).
- Creates the `pg_net` extension for making HTTP POST requests to edge functions.
- Configures pg_cron to use the `supabase_functions_admin` database role.
2. Scheduled Jobs
- Job 1: `sync_guilds` — calls the sync-guild edge function every 2 minutes.
  Fetches guild rosters and world online status, updates character records,
  and repopulates the sync_queue.
- Job 2: `sync_deaths` — calls the sync-deaths edge function every 1 minute.
  Processes a batch of ~20 characters from the queue, fetching fresh death
  data from TibiaData (respecting 5-min cache TTL).
3. Security
- The `net` extension is granted to `service_role` and `anon` only for the
  purpose of internal cron invocations. The cron jobs use the service role
  key from `vault` (if configured) or the project's anon key as fallback.
4. Notes
- pg_cron runs in the `extensions` schema. The `jobname` field is used so
  jobs can be identified and managed.
- Both jobs call edge functions via HTTP POST. The edge functions are
  configured with `verify_jwt = false` so they accept unauthenticated
  invocations from the cron scheduler.
- If pg_cron is not available on this plan, these statements will fail
  gracefully and the jobs can be triggered manually via the edge function
  HTTP endpoints.
*/

CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS pg_net;

-- Schedule sync-guild every 2 minutes
SELECT cron.schedule(
  'sync_guilds',
  '*/2 * * * *',
  $$SELECT net.http_post(
    url := current_setting('app.settings.edge_function_url', true) || '/sync-guild',
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := jsonb_build_object('source', 'pg_cron')
  )$$
);

-- Schedule sync-deaths every 1 minute
SELECT cron.schedule(
  'sync_deaths',
  '* * * * *',
  $$SELECT net.http_post(
    url := current_setting('app.settings.edge_function_url', true) || '/sync-deaths',
    headers := jsonb_build_object('Content-Type', 'application/json'),
    body := jsonb_build_object('source', 'pg_cron')
  )$$
);
