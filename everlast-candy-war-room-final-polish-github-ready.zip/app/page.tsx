'use client';

import { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import Link from 'next/link';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import {
  Skull,
  Target,
  TrendingUp,
  TrendingDown,
  Users,
  ChevronRight,
  Zap,
  Clock,
  Swords,
  Heart,
  Sparkles,
  Star,
  ArrowUpCircle,
  ArrowDownCircle,
  RefreshCw,
  GitCompare,
  AlertCircle,
} from 'lucide-react';
import {
  getRecentDeaths,
  getOnlineSummary,
  getRecentActivity,
  getRecentSyncLogs,
  getRecentLevelUps,
  getRecentLevelDowns,
  getCanonicalWarEvents,
  buildDailySeries,
  computeTopKillers,
  buildCanonicalDailySeries,
  type OnlineSummary,
  type DailyDeathPoint,
} from '@/lib/queries';
import type { DeathEvent, ActivitySnapshot, SyncLogEntry, LevelEvent, WarSide, CanonicalWarEvent } from '@/lib/types';
import { StatCard, LoadingState, MockDataBadge } from '@/components/stat-card';
import { CharacterTag, OnlineIndicator, SideBadge } from '@/components/character-tag';
import { ScoringSwitcher } from '@/components/scoring-switcher';
import { DailyWarRecap } from '@/components/daily-recap';
import { TrackingHealth } from '@/components/tracking-health';
import { TeamRallyMini } from '@/components/team-rally-mini';
import { timeAgo } from '@/lib/format';
import { GUILD_EVERLAST, GUILD_ALLY, GUILD_ENEMY } from '@/lib/tibia';
import {
  getStoredScoringMode,
  storeScoringMode,
  computeLastHitScore,
  computeParticipationScore,
  computeCompareScore,
  computeGuildBreakdown,
  buildSideLookup,
  type ScoringMode,
} from '@/lib/scoring';

const CANDY_TOOLTIP = {
  backgroundColor: 'hsl(324 100% 98%)',
  border: '2px solid hsl(324 100% 85%)',
  borderRadius: '12px',
  fontSize: '12px',
  color: 'hsl(276 19% 35%)',
};

const POLL_INTERVAL = 30000; // 30 seconds

export default function DashboardPage() {
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [deaths, setDeaths] = useState<DeathEvent[]>([]);
  const [online, setOnline] = useState<OnlineSummary | null>(null);
  const [activity, setActivity] = useState<ActivitySnapshot[]>([]);
  const [syncLogs, setSyncLogs] = useState<SyncLogEntry[]>([]);
  const [levelUps, setLevelUps] = useState<LevelEvent[]>([]);
  const [levelDowns, setLevelDowns] = useState<LevelEvent[]>([]);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);
  const [canonicalEvents, setCanonicalEvents] = useState<CanonicalWarEvent[]>([]);
  const [scoringMode, setScoringMode] = useState<ScoringMode>('last-hit');
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Load scoring mode from localStorage on mount
  useEffect(() => {
    setScoringMode(getStoredScoringMode());
  }, []);

  const handleModeChange = useCallback((mode: ScoringMode) => {
    setScoringMode(mode);
    storeScoringMode(mode);
  }, []);

  const load = useCallback(async () => {
    const results = await Promise.allSettled([
      getRecentDeaths(200),
      getOnlineSummary(),
      getRecentActivity(20),
      getRecentSyncLogs(5),
      getRecentLevelUps(10),
      getRecentLevelDowns(10),
      getCanonicalWarEvents(2000),
    ]);

    const [dR, oR, aR, sR, luR, ldR, ceR] = results;
    let hadError = false;
    let errorMsg: string | null = null;

    if (dR.status === 'fulfilled') setDeaths(dR.value); else { hadError = true; errorMsg = dR.reason?.message ?? 'Deaths fetch failed'; }
    if (oR.status === 'fulfilled') setOnline(oR.value); else { hadError = true; errorMsg = oR.reason?.message ?? 'Online fetch failed'; }
    if (aR.status === 'fulfilled') setActivity(aR.value); else { hadError = true; }
    if (sR.status === 'fulfilled') setSyncLogs(sR.value); else { hadError = true; }
    if (luR.status === 'fulfilled') setLevelUps(luR.value); else { hadError = true; }
    if (ldR.status === 'fulfilled') setLevelDowns(ldR.value); else { hadError = true; }
    if (ceR.status === 'fulfilled') setCanonicalEvents(ceR.value); else { hadError = true; errorMsg = ceR.reason?.message ?? 'War events fetch failed'; }

    // Detect auth errors specifically
    const allReasons = results.filter((r) => r.status === 'rejected').map((r) => (r as PromiseRejectedResult).reason);
    const isAuthError = allReasons.some((r) => r?.name === 'AuthError');

    if (isAuthError) {
      window.location.href = '/unlock?redirect=/';
      return;
    }

    if (hadError) {
      setLoadError(errorMsg ?? 'Some data failed to load');
      console.error('Dashboard partial load error:', allReasons);
    } else {
      setLoadError(null);
    }

    // Only update lastRefresh if at least the critical war events loaded
    if (ceR.status === 'fulfilled') {
      setLastRefresh(new Date());
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();

    // Authenticated polling replaces Realtime subscriptions
    pollRef.current = setInterval(load, POLL_INTERVAL);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [load]);

  // Build side lookup for participation scoring
  const sideLookup = useMemo(() => buildSideLookup(canonicalEvents), [canonicalEvents]);

  // Compute scores based on selected mode
  const lastHitScore = useMemo(() => computeLastHitScore(canonicalEvents), [canonicalEvents]);
  const participationScore = useMemo(
    () => computeParticipationScore(canonicalEvents, sideLookup),
    [canonicalEvents, sideLookup],
  );
  const compareScore = useMemo(
    () => computeCompareScore(canonicalEvents, sideLookup),
    [canonicalEvents, sideLookup],
  );

  // Guild breakdown for stat cards — same data source + scoring mode as the scoreboard
  const guildBreakdown = useMemo(
    () => computeGuildBreakdown(canonicalEvents, scoringMode, sideLookup),
    [canonicalEvents, scoringMode, sideLookup],
  );
  const daily = useMemo(
    () => buildCanonicalDailySeries(canonicalEvents, 7),
    [canonicalEvents],
  );
  const topKillers = useMemo(() => computeTopKillers(deaths, 5), [deaths]);
  const recentDeaths = deaths.slice(0, 12);
  const hasMockData = deaths.some((d) => d.source === 'mock-dev');
  const lastSync = syncLogs[0];
  const activityData = useMemo(() => buildActivityChart(activity), [activity]);

  if (loading) return <LoadingState label="Loading candy war room..." />;

  return (
    <div className="space-y-6 animate-float-up">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <Sparkles className="size-6 text-pink-400 animate-sparkle" />
            Candy War Dashboard
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5 font-semibold">
            Everlast Alliance vs Mandatory Again · Server Sinistra
          </p>
        </div>
        <div className="flex items-center gap-2">
          <MockDataBadge show={hasMockData} />
          {lastRefresh ? (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-semibold">
              <RefreshCw className="size-3 text-emerald-400 animate-spin-slow" />
              Updated {timeAgo(lastRefresh)}
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-semibold">
              <RefreshCw className="size-3 text-amber-400" />
              No data yet
            </div>
          )}
          {lastSync && (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-semibold">
              <Clock className="size-3" />
              Synced {timeAgo(lastSync.finished_at ?? lastSync.started_at)}
            </div>
          )}
        </div>
      </div>

      {/* Error banner */}
      {loadError && (
        <div className="flex items-center gap-3 rounded-2xl border-2 border-amber-200 bg-amber-50 p-4">
          <AlertCircle className="size-5 text-amber-500 shrink-0" />
          <div className="flex-1">
            <div className="text-sm font-bold text-amber-700">Data loading issue</div>
            <div className="text-xs text-amber-600 font-semibold">{loadError}. Some statistics may be incomplete. Retrying automatically.</div>
          </div>
          <button
            onClick={() => load()}
            className="flex items-center gap-1.5 rounded-xl border-2 border-amber-300 bg-white px-3 py-1.5 text-xs font-bold text-amber-600 hover:bg-amber-100 transition-colors"
          >
            <RefreshCw className="size-3.5" />
            Retry
          </button>
        </div>
      )}

      {/* One lightweight team-command widget using the dashboard's already-loaded online roster */}
      <TeamRallyMini online={online} />

      {/* HERO SCOREBOARD with scoring switcher */}
      <ScoreboardHero
        mode={scoringMode}
        onModeChange={handleModeChange}
        lastHit={lastHitScore}
        participation={participationScore}
        compare={compareScore}
        online={online}
      />

      {/* Stat cards — alliance breakdown (same source + scoring mode as scoreboard) */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Everlast Kills" value={guildBreakdown.everlastKills} sublabel={scoringMode === 'participation' ? 'Participation kills' : 'Enemy members eliminated'} icon={Target} side="everlast" />
        <StatCard label="Terrory Kills" value={guildBreakdown.allyKills} sublabel={scoringMode === 'participation' ? 'Participation kills' : 'Enemy members eliminated'} icon={Target} side="ally" />
        <StatCard label="Alliance Kills" value={guildBreakdown.friendlyKills} sublabel="Combined friendly kills" icon={Swords} side="everlast" />
        <StatCard label="Enemy Kills" value={guildBreakdown.enemyKills} sublabel="Friendly members eliminated" icon={Skull} side="enemy" />
      </div>

      {/* Daily recap + Tracking health */}
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <DailyWarRecap />
        </div>
        <TrackingHealth />
      </div>

      {/* Charts row */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-foreground flex items-center gap-1.5">
                <TrendingUp className="size-4 text-purple-400" /> Alliance vs Enemy Kills
              </h2>
              <p className="text-xs text-muted-foreground font-semibold">Last 7 days</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={daily} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="friendlyKills" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(155 57% 57%)" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="hsl(155 57% 57%)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="enemyKillsGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(340 100% 68%)" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="hsl(340 100% 68%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(324 50% 90%)" />
              <XAxis dataKey="label" stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip contentStyle={CANDY_TOOLTIP} />
              <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 600 }} />
              <Area type="monotone" dataKey="friendlyKills" name="Alliance Kills" stroke="hsl(155 57% 57%)" strokeWidth={2} fill="url(#friendlyKills)" />
              <Area type="monotone" dataKey="enemyKills" name="Enemy Kills" stroke="hsl(340 100% 68%)" strokeWidth={2} fill="url(#enemyKillsGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl border-2 border-purple-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-foreground flex items-center gap-1.5">
                <Users className="size-4 text-blue-400" /> Guild Online Activity
              </h2>
              <p className="text-xs text-muted-foreground font-semibold">Members online over time</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={activityData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(324 50% 90%)" />
              <XAxis dataKey="label" stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip contentStyle={CANDY_TOOLTIP} />
              <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 600 }} />
              <Bar dataKey="everlast" name="Everlast" fill="hsl(155 57% 57%)" radius={[6, 6, 0, 0]} />
              <Bar dataKey="ally" name="Terrory" fill="hsl(270 60% 65%)" radius={[6, 6, 0, 0]} />
              <Bar dataKey="enemy" name="Mandatory Again" fill="hsl(340 100% 68%)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Level changes row */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border-2 border-emerald-200 bg-gradient-to-br from-emerald-50/50 to-white p-5 shadow-bubbly">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-foreground flex items-center gap-1.5">
              <ArrowUpCircle className="size-4 text-emerald-500" /> Recent Level Ups
            </h2>
            <span className="text-xs text-muted-foreground font-semibold">{levelUps.length} events</span>
          </div>
          <div className="space-y-2 max-h-[240px] overflow-y-auto pr-1">
            {levelUps.length === 0 && (
              <div className="text-sm text-muted-foreground py-4 text-center font-semibold">No level ups detected yet.</div>
            )}
            {levelUps.map((ev) => (
              <Link
                key={ev.id}
                href={`/character/${encodeURIComponent(ev.character_name)}`}
                className="flex items-center gap-3 rounded-xl border-2 border-emerald-100 bg-emerald-50/50 p-2.5 hover:bg-emerald-50 transition-colors"
              >
                <ArrowUpCircle className="size-4 text-emerald-500 shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-bold text-foreground truncate">{ev.character_name}</span>
                    {ev.character_side && <SideBadge side={ev.character_side} />}
                  </div>
                  <div className="text-xs text-muted-foreground font-semibold">
                    {ev.character_vocation ?? 'Unknown vocation'} · {ev.previous_level ?? '?'} → {ev.new_level ?? '?'}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-sm font-bold text-emerald-500">+{ev.level_diff}</span>
                  <div className="text-[10px] text-muted-foreground font-semibold">{timeAgo(ev.observed_at)}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border-2 border-pink-200 bg-gradient-to-br from-pink-50/50 to-white p-5 shadow-bubbly">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-foreground flex items-center gap-1.5">
              <ArrowDownCircle className="size-4 text-pink-400" /> Recent Level Downs
            </h2>
            <span className="text-xs text-muted-foreground font-semibold">{levelDowns.length} events</span>
          </div>
          <div className="space-y-2 max-h-[240px] overflow-y-auto pr-1">
            {levelDowns.length === 0 && (
              <div className="text-sm text-muted-foreground py-4 text-center font-semibold">No level downs detected yet.</div>
            )}
            {levelDowns.map((ev) => (
              <Link
                key={ev.id}
                href={`/character/${encodeURIComponent(ev.character_name)}`}
                className="flex items-center gap-3 rounded-xl border-2 border-pink-100 bg-pink-50/50 p-2.5 hover:bg-pink-50 transition-colors"
              >
                <ArrowDownCircle className="size-4 text-pink-400 shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-bold text-foreground truncate">{ev.character_name}</span>
                    {ev.character_side && <SideBadge side={ev.character_side} />}
                  </div>
                  <div className="text-xs text-muted-foreground font-semibold">
                    {ev.character_vocation ?? 'Unknown vocation'} · {ev.previous_level ?? '?'} → {ev.new_level ?? '?'}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-sm font-bold text-pink-500">{ev.level_diff}</span>
                  <div className="text-[10px] text-muted-foreground font-semibold">{timeAgo(ev.observed_at)}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row: Top killers + Recent deaths */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-foreground flex items-center gap-1.5">
              <Star className="size-4 text-amber-400" fill="currentColor" /> Top Killers
            </h2>
            <Link href="/analytics" className="flex items-center gap-1 text-xs text-pink-400 hover:underline font-bold">
              View all <ChevronRight className="size-3" />
            </Link>
          </div>
          <div className="space-y-3">
            {topKillers.length === 0 && (
              <div className="text-sm text-muted-foreground py-4 text-center font-semibold">No kills recorded yet.</div>
            )}
            {topKillers.map((killer, i) => (
              <div key={killer.name} className="flex items-center gap-3">
                <div className={`flex size-7 items-center justify-center rounded-xl text-xs font-bold ${i === 0 ? 'bg-amber-100 text-amber-500' : 'bg-purple-100 text-purple-400'}`}>
                  {i + 1}
                </div>
                <CharacterTag name={killer.name} vocation={killer.vocation} level={killer.level} side={killer.side ?? undefined} />
                <div className="ml-auto flex items-center gap-1.5">
                  <Zap className="size-3.5 text-emerald-500" />
                  <span className="text-sm font-bold tabular-nums text-emerald-500">{killer.kills}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border-2 border-purple-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-foreground flex items-center gap-1.5">
              <Heart className="size-4 text-pink-400" fill="currentColor" /> Recent Deaths Feed
            </h2>
            <Link href="/death-radar" className="flex items-center gap-1 text-xs text-pink-400 hover:underline font-bold">
              Death Radar <ChevronRight className="size-3" />
            </Link>
          </div>
          <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
            {recentDeaths.length === 0 && (
              <div className="text-sm text-muted-foreground py-4 text-center font-semibold">No deaths recorded.</div>
            )}
            {recentDeaths.map((death) => (
              <Link
                key={death.id}
                href={`/character/${encodeURIComponent(death.character_name)}`}
                className="block rounded-xl border-2 border-pink-100 bg-pink-50/50 p-3 hover:bg-pink-50 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <CharacterTag name={death.character_name} vocation={death.character_vocation} level={death.character_level} side={death.character_side} />
                      <SideBadge side={death.character_side} />
                    </div>
                    <div className="text-xs text-muted-foreground mt-1.5 font-semibold">
                      {death.is_pvp && death.killer_name ? (
                        <>Killed by <span className="font-bold text-foreground">{death.killer_name}</span></>
                      ) : (
                        death.reason
                      )}
                    </div>
                  </div>
                  <div className="shrink-0 text-right">
                    <div className="text-[11px] text-muted-foreground font-semibold">{timeAgo(death.death_time)}</div>
                    {death.is_pvp ? (
                      <span className="inline-flex items-center gap-1 mt-1 text-[10px] font-bold text-pink-500">
                        <Swords className="size-3" /> PvP
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 mt-1 text-[10px] font-bold text-muted-foreground">
                        <Skull className="size-3" /> PvE
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Online members */}
      {online && (
        <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Sparkles className="size-4 text-purple-400 animate-sparkle" />
              <h2 className="text-sm font-bold text-foreground">Guild Online Activity</h2>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-3">
            <OnlineList title="Everlast Online" side="everlast" online={online.everlastOnline} total={online.everlastTotal} members={online.everlastMembers.filter((m) => m.online)} />
            <OnlineList title="Terrory Online" side="ally" online={online.allyOnline} total={online.allyTotal} members={online.allyMembers.filter((m) => m.online)} />
            <OnlineList title="Mandatory Again Online" side="enemy" online={online.enemyOnline} total={online.enemyTotal} members={online.enemyMembers.filter((m) => m.online)} />
          </div>
        </div>
      )}
    </div>
  );
}

// ===== HERO SCOREBOARD =====

function ScoreboardHero({
  mode,
  onModeChange,
  lastHit,
  participation,
  compare,
  online,
}: {
  mode: ScoringMode;
  onModeChange: (m: ScoringMode) => void;
  lastHit: ReturnType<typeof computeLastHitScore>;
  participation: ReturnType<typeof computeParticipationScore>;
  compare: ReturnType<typeof computeCompareScore>;
  online: OnlineSummary | null;
}) {
  return (
    <div
      className="relative overflow-hidden rounded-[2rem] border-2 border-pink-200 bg-gradient-to-br from-pink-50/80 via-purple-50/40 to-blue-50/60 p-6 shadow-bubbly"
      style={{ fontFamily: 'inherit' }}
    >
      <div className="absolute inset-x-0 top-0 h-2 rounded-t-[2rem] bg-gradient-to-r from-emerald-300 via-purple-300 to-pink-300" />

      {/* Scoring mode switcher */}
      <div className="flex justify-center mb-6">
        <ScoringSwitcher mode={mode} onChange={onModeChange} />
      </div>

      {mode === 'last-hit' && (
        <LastHitDisplay score={lastHit} online={online} />
      )}
      {mode === 'participation' && (
        <ParticipationDisplay score={participation} online={online} />
      )}
      {mode === 'compare' && (
        <CompareDisplay score={compare} online={online} />
      )}
    </div>
  );
}

function ScorePair({
  friendly,
  enemy,
  label,
}: {
  friendly: number;
  enemy: number;
  label: string;
}) {
  return (
    <Link href="/war-verification" className="block group">
      <div className="text-[11px] uppercase tracking-widest text-muted-foreground font-bold mb-2 text-center">
        {label}
      </div>
      <div className="flex items-center justify-center gap-4 sm:gap-6">
        <div className="text-center group-hover:scale-105 transition-transform">
          <div className="text-5xl sm:text-6xl font-bold tabular-nums text-emerald-500 drop-shadow-sm">
            {friendly}
          </div>
          <div className="text-xs font-bold text-emerald-600 mt-1">Everlast + Terrory</div>
        </div>
        <div className="text-3xl text-muted-300 font-light">:</div>
        <div className="text-center group-hover:scale-105 transition-transform">
          <div className="text-5xl sm:text-6xl font-bold tabular-nums text-pink-500 drop-shadow-sm">
            {enemy}
          </div>
          <div className="text-xs font-bold text-pink-600 mt-1">Mandatory Again</div>
        </div>
      </div>
    </Link>
  );
}

function LastHitDisplay({ score, online }: { score: ReturnType<typeof computeLastHitScore>; online: OnlineSummary | null }) {
  return (
    <div className="space-y-4">
      <ScorePair friendly={score.friendlyKills} enemy={score.enemyKills} label="⚔️ Last Hit Score" />
      <div className="flex flex-wrap justify-center gap-2 text-[10px] font-bold">
        {score.inferredFriendly > 0 && (
          <span className="rounded-lg border-2 border-amber-200 bg-amber-50 px-2.5 py-1 text-amber-600">
            +{score.inferredFriendly} inferred friendly
          </span>
        )}
        {score.inferredEnemy > 0 && (
          <span className="rounded-lg border-2 border-amber-200 bg-amber-50 px-2.5 py-1 text-amber-600">
            +{score.inferredEnemy} inferred enemy
          </span>
        )}
        <span className="rounded-lg border-2 border-blue-200 bg-blue-50 px-2.5 py-1 text-blue-600">
          Friendly fire: {score.sameAlliance}
        </span>
        <span className="rounded-lg border-2 border-gray-200 bg-gray-50 px-2.5 py-1 text-gray-500">
          Unknown: {score.unknown}
        </span>
        <span className="rounded-lg border-2 border-purple-200 bg-purple-50 px-2.5 py-1 text-purple-500">
          PvE: {score.pve}
        </span>
        {online && (
          <span className="rounded-lg border-2 border-emerald-200 bg-emerald-50 px-2.5 py-1 text-emerald-600">
            {online.friendlyOnline} friendly online · {online.enemyOnline} enemy online
          </span>
        )}
      </div>
      <p className="text-center text-[10px] text-muted-foreground font-semibold">
        Credited killer (last hit) determines attribution. Uses stored guild membership at sync time.
      </p>
    </div>
  );
}

function ParticipationDisplay({ score, online }: { score: ReturnType<typeof computeParticipationScore>; online: OnlineSummary | null }) {
  return (
    <div className="space-y-4">
      <ScorePair friendly={score.friendlyKills} enemy={score.enemyKills} label="🤝 Participation Score" />
      <div className="flex flex-wrap justify-center gap-2 text-[10px] font-bold">
        <span className="rounded-lg border-2 border-amber-200 bg-amber-50 px-2.5 py-1 text-amber-600">
          ⚠️ Mixed involvement: {score.mixedInvolvement}
        </span>
        <span className="rounded-lg border-2 border-blue-200 bg-blue-50 px-2.5 py-1 text-blue-600">
          Friendly fire: {score.sameAlliance}
        </span>
        <span className="rounded-lg border-2 border-gray-200 bg-gray-50 px-2.5 py-1 text-gray-500">
          Unknown: {score.unknownParticipation}
        </span>
        <span className="rounded-lg border-2 border-purple-200 bg-purple-50 px-2.5 py-1 text-purple-500">
          PvE: {score.pve}
        </span>
        {score.incompleteAssistData > 0 && (
          <span className="rounded-lg border-2 border-orange-200 bg-orange-50 px-2.5 py-1 text-orange-600">
            Incomplete assist data: {score.incompleteAssistData}
          </span>
        )}
        {online && (
          <span className="rounded-lg border-2 border-emerald-200 bg-emerald-50 px-2.5 py-1 text-emerald-600">
            {online.friendlyOnline} friendly online · {online.enemyOnline} enemy online
          </span>
        )}
      </div>
      <p className="text-center text-[10px] text-muted-foreground font-semibold">
        Counts a unique death when any verified alliance member participated as killer or assistant. One death = max one point.
      </p>
    </div>
  );
}

function CompareDisplay({ score, online }: { score: ReturnType<typeof computeCompareScore>; online: OnlineSummary | null }) {
  return (
    <div className="space-y-5">
      <div className="grid gap-4 sm:grid-cols-2">
        {/* Last Hit */}
        <div className="rounded-2xl border-2 border-emerald-200 bg-white/60 p-4">
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold mb-2 text-center">
            ⚔️ Last Hit Score
          </div>
          <div className="flex items-center justify-center gap-3">
            <div className="text-center">
              <div className="text-3xl font-bold tabular-nums text-emerald-500">{score.lastHit.friendlyKills}</div>
              <div className="text-[9px] font-bold text-emerald-600">Everlast + Terrory</div>
            </div>
            <span className="text-xl text-muted-300">:</span>
            <div className="text-center">
              <div className="text-3xl font-bold tabular-nums text-pink-500">{score.lastHit.enemyKills}</div>
              <div className="text-[9px] font-bold text-pink-600">Mandatory Again</div>
            </div>
          </div>
        </div>

        {/* Participation */}
        <div className="rounded-2xl border-2 border-purple-200 bg-white/60 p-4">
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-bold mb-2 text-center">
            🤝 Participation Score
          </div>
          <div className="flex items-center justify-center gap-3">
            <div className="text-center">
              <div className="text-3xl font-bold tabular-nums text-emerald-500">{score.participation.friendlyKills}</div>
              <div className="text-[9px] font-bold text-emerald-600">Everlast + Terrory</div>
            </div>
            <span className="text-xl text-muted-300">:</span>
            <div className="text-center">
              <div className="text-3xl font-bold tabular-nums text-pink-500">{score.participation.enemyKills}</div>
              <div className="text-[9px] font-bold text-pink-600">Mandatory Again</div>
            </div>
          </div>
        </div>
      </div>

      {/* Comparison stats */}
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4 text-[10px] font-bold">
        <div className="rounded-xl border-2 border-emerald-200 bg-emerald-50/60 p-2.5 text-center">
          <GitCompare className="size-3 mx-auto text-emerald-500 mb-1" />
          <div className="text-emerald-600">Friendly diff: {score.friendlyDiff >= 0 ? '+' : ''}{score.friendlyDiff}</div>
        </div>
        <div className="rounded-xl border-2 border-pink-200 bg-pink-50/60 p-2.5 text-center">
          <GitCompare className="size-3 mx-auto text-pink-500 mb-1" />
          <div className="text-pink-600">Enemy diff: {score.enemyDiff >= 0 ? '+' : ''}{score.enemyDiff}</div>
        </div>
        <div className="rounded-xl border-2 border-blue-200 bg-blue-50/60 p-2.5 text-center">
          <Heart className="size-3 mx-auto text-blue-500 mb-1" />
          <div className="text-blue-600">Friendly assist kills: {score.deathsWithFriendlyAssists}</div>
        </div>
        <div className="rounded-xl border-2 border-purple-200 bg-purple-50/60 p-2.5 text-center">
          <Swords className="size-3 mx-auto text-purple-500 mb-1" />
          <div className="text-purple-600">Enemy assist kills: {score.deathsWithEnemyAssists}</div>
        </div>
      </div>
      <div className="flex flex-wrap justify-center gap-2 text-[10px] font-bold">
        <span className="rounded-lg border-2 border-orange-200 bg-orange-50 px-2.5 py-1 text-orange-600">
          <AlertCircle className="inline size-3 mr-0.5" />
          Incomplete data: {score.incompleteData}
        </span>
        <span className="rounded-lg border-2 border-amber-200 bg-amber-50 px-2.5 py-1 text-amber-600">
          ⚠️ Ambiguous: {score.ambiguous}
        </span>
        {online && (
          <span className="rounded-lg border-2 border-emerald-200 bg-emerald-50 px-2.5 py-1 text-emerald-600">
            {online.friendlyOnline} friendly · {online.enemyOnline} enemy online
          </span>
        )}
      </div>
    </div>
  );
}

function OnlineList({ title, side, online, total, members }: { title: string; side: WarSide; online: number; total: number; members: { name: string; vocation: string | null; level: number | null; rank: string | null }[] }) {
  const borderClass = side === 'everlast' ? 'border-emerald-100 bg-emerald-50/50' : side === 'ally' ? 'border-purple-100 bg-purple-50/50' : 'border-pink-100 bg-pink-50/50';
  const titleClass = side === 'everlast' ? 'text-emerald-600' : side === 'ally' ? 'text-purple-500' : 'text-pink-500';
  return (
    <div className={`rounded-xl border-2 p-4 ${borderClass}`}>
      <div className="flex items-center justify-between mb-3">
        <span className={`text-xs font-bold ${titleClass}`}>{title}</span>
        <span className="text-xs text-muted-foreground font-bold tabular-nums">{online}/{total}</span>
      </div>
      <div className="space-y-2 max-h-[200px] overflow-y-auto">
        {members.length === 0 ? (
          <div className="text-xs text-muted-foreground py-2 font-semibold">No members online</div>
        ) : (
          members.map((m) => (
            <Link key={m.name} href={`/character/${encodeURIComponent(m.name)}`} className="flex items-center gap-2 rounded-xl p-1.5 hover:bg-white/60 transition-colors">
              <CharacterTag name={m.name} vocation={m.vocation} level={m.level} side={side} rank={m.rank} />
              <OnlineIndicator online={true} className="ml-auto" />
            </Link>
          ))
        )}
      </div>
    </div>
  );
}

function buildActivityChart(activity: ActivitySnapshot[]) {
  const grouped = new Map<string, { label: string; everlast: number; ally: number; enemy: number; ts: number }>();
  const sorted = [...activity].sort((a, b) => new Date(a.snapshot_at).getTime() - new Date(b.snapshot_at).getTime());
  for (const snap of sorted) {
    const key = snap.snapshot_at.slice(0, 13);
    const existing = grouped.get(key);
    const label = new Date(snap.snapshot_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    if (existing) {
      if (snap.side === 'everlast') existing.everlast = snap.online_count;
      if (snap.side === 'ally') existing.ally = snap.online_count;
      if (snap.side === 'enemy') existing.enemy = snap.online_count;
    } else {
      grouped.set(key, {
        label,
        everlast: snap.side === 'everlast' ? snap.online_count : 0,
        ally: snap.side === 'ally' ? snap.online_count : 0,
        enemy: snap.side === 'enemy' ? snap.online_count : 0,
        ts: new Date(snap.snapshot_at).getTime(),
      });
    }
  }
  return Array.from(grouped.values()).sort((a, b) => a.ts - b.ts);
}
