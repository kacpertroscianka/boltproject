'use client';

import { useEffect, useState, useMemo, useRef, useCallback } from 'react';
import Link from 'next/link';
import {
  Tv, Maximize, Minimize, X, Swords, Skull, Heart, Sparkles,
  TrendingUp, TrendingDown, ArrowUpCircle, ArrowDownCircle,
  Clock, Users, RefreshCw, Star, Zap,
} from 'lucide-react';
import {
  getRecentDeaths, getOnlineSummary, getRecentSyncLogs,
  getRecentLevelUps, getRecentLevelDowns, getCanonicalWarEvents,
  type OnlineSummary,
} from '@/lib/queries';
import type { DeathEvent, LevelEvent, SyncLogEntry, CanonicalWarEvent } from '@/lib/types';
import { CharacterTag, SideBadge } from '@/components/character-tag';
import { ScoringSwitcher } from '@/components/scoring-switcher';
import { timeAgo } from '@/lib/format';
import { isFriendlySide, isEnemySide, GUILD_ENEMY } from '@/lib/tibia';
import {
  getStoredScoringMode, storeScoringMode,
  computeLastHitScore, computeParticipationScore, buildSideLookup,
  type ScoringMode,
} from '@/lib/scoring';
import { cn } from '@/lib/utils';

const POLL_INTERVAL = 15000;

export default function WarTvPage() {
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [deaths, setDeaths] = useState<DeathEvent[]>([]);
  const [online, setOnline] = useState<OnlineSummary | null>(null);
  const [syncLogs, setSyncLogs] = useState<SyncLogEntry[]>([]);
  const [levelUps, setLevelUps] = useState<LevelEvent[]>([]);
  const [levelDowns, setLevelDowns] = useState<LevelEvent[]>([]);
  const [canonicalEvents, setCanonicalEvents] = useState<CanonicalWarEvent[]>([]);
  const [scoringMode, setScoringMode] = useState<ScoringMode>('last-hit');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const [banner, setBanner] = useState<{ title: string; message: string; color: string } | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => { setScoringMode(getStoredScoringMode()); }, []);

  const handleModeChange = useCallback((mode: ScoringMode) => {
    setScoringMode(mode);
    storeScoringMode(mode);
  }, []);

  const load = useCallback(async () => {
    const [d, o, s, lu, ld, ce] = await Promise.allSettled([
      getRecentDeaths(200),
      getOnlineSummary(),
      getRecentSyncLogs(3),
      getRecentLevelUps(8),
      getRecentLevelDowns(8),
      getCanonicalWarEvents(2000),
    ]);
    // A single failed query must not erase other live feeds (e.g. level-ups).
    if (d.status === 'fulfilled') setDeaths(d.value);
    if (o.status === 'fulfilled') setOnline(o.value);
    if (s.status === 'fulfilled') setSyncLogs(s.value);
    if (lu.status === 'fulfilled') setLevelUps(lu.value);
    if (ld.status === 'fulfilled') setLevelDowns(ld.value);
    if (ce.status === 'fulfilled') setCanonicalEvents(ce.value);
    const failed = [d, o, s, lu, ld, ce].filter((result) => result.status === 'rejected');
    setLoadError(failed.length ? `${failed.length} źródeł danych jest chwilowo niedostępnych. Pozostałe sekcje nadal działają; starsze wyniki mogą być nieaktualne.` : null);
    if (failed.length === 0) setLastRefresh(new Date());
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
    pollRef.current = setInterval(load, POLL_INTERVAL);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [load]);

  // Listen for alert events to show banner
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as { title: string; message: string; type: string };
      const colorMap: Record<string, string> = {
        enemy_death_pvp: 'from-pink-500 to-rose-500',
        enemy_death_pve: 'from-pink-400 to-rose-400',
        friendly_kills_enemy: 'from-emerald-500 to-teal-500',
        friendly_kills_enemy_participation: 'from-purple-500 to-violet-500',
        enemy_kills_friendly: 'from-red-500 to-pink-500',
        friendly_death: 'from-blue-500 to-cyan-500',
        enemy_level_up: 'from-amber-500 to-orange-500',
        friendly_level_up: 'from-emerald-400 to-green-400',
        enemy_level_down: 'from-gray-500 to-slate-500',
        friendly_level_down: 'from-gray-400 to-slate-400',
      };
      const color = colorMap[detail.type] || 'from-pink-400 to-purple-400';
      setBanner({ title: detail.title, message: detail.message, color });
      setTimeout(() => setBanner(null), 6000);
    };
    window.addEventListener('candy-alert', handler);
    return () => window.removeEventListener('candy-alert', handler);
  }, []);

  const sideLookup = useMemo(() => buildSideLookup(canonicalEvents), [canonicalEvents]);
  const lastHitScore = useMemo(() => computeLastHitScore(canonicalEvents), [canonicalEvents]);
  const participationScore = useMemo(
    () => computeParticipationScore(canonicalEvents, sideLookup),
    [canonicalEvents, sideLookup],
  );

  const friendlyKills = scoringMode === 'participation' ? participationScore.friendlyKills : lastHitScore.friendlyKills;
  const enemyKills = scoringMode === 'participation' ? participationScore.enemyKills : lastHitScore.enemyKills;

  const enemyDeaths = useMemo(
    () => deaths.filter((d) => isEnemySide(d.character_side)).slice(0, 8),
    [deaths],
  );
  const friendlyDeaths = useMemo(
    () => deaths.filter((d) => isFriendlySide(d.character_side)).slice(0, 8),
    [deaths],
  );
  const pvpKills = useMemo(
    () => deaths.filter((d) => d.is_pvp && d.killer_name && d.killer_name !== d.character_name).slice(0, 8),
    [deaths],
  );

  const lastSync = syncLogs[0];

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  }, []);

  useEffect(() => {
    const onFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <RefreshCw className="size-8 text-pink-400 animate-spin" />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[70] bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50 overflow-y-auto">
      {/* Top control bar */}
      <div className="sticky top-0 z-[71] flex items-center justify-between px-4 py-3 bg-white/80 backdrop-blur-xl border-b-2 border-pink-200">
        <div className="flex items-center gap-2">
          <Tv className="size-5 text-pink-400" />
          <span className="text-sm font-bold text-foreground">📺 Everlast War TV</span>
          <span className="hidden sm:flex items-center gap-1 ml-2 text-xs text-muted-foreground font-semibold">
            <RefreshCw className="size-3 text-emerald-400 animate-spin-slow" />
            {timeAgo(lastRefresh)}
          </span>
          {lastSync && (
            <span className="hidden md:flex items-center gap-1 text-xs text-muted-foreground font-semibold">
              <Clock className="size-3" />
              Sync {timeAgo(lastSync.finished_at ?? lastSync.started_at)}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden sm:block">
            <ScoringSwitcher mode={scoringMode} onChange={handleModeChange} />
          </div>
          <button
            onClick={toggleFullscreen}
            className="flex items-center gap-1.5 rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-1.5 text-xs font-bold text-pink-400 hover:bg-pink-50 transition-colors"
          >
            {isFullscreen ? <Minimize className="size-3.5" /> : <Maximize className="size-3.5" />}
            <span className="hidden sm:inline">{isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}</span>
          </button>
          <Link
            href="/"
            className="flex items-center gap-1.5 rounded-xl border-2 border-pink-300 bg-gradient-to-r from-pink-100 to-purple-100 px-3 py-1.5 text-xs font-bold text-pink-500 hover:scale-105 transition-transform"
          >
            <X className="size-3.5" />
            <span className="hidden sm:inline">Exit TV</span>
          </Link>
        </div>
      </div>

      {loadError && <div role="alert" className="mx-4 mt-3 rounded-xl border-2 border-amber-200 bg-amber-50 px-4 py-2 text-xs font-bold text-amber-800">⚠️ {loadError}</div>}
      {/* Event banner */}
      {banner && (
        <div className="px-4 pt-4 animate-float-up">
          <div className={cn('rounded-2xl bg-gradient-to-r p-4 shadow-lg', banner.color)}>
            <div className="text-lg font-bold text-white">{banner.title}</div>
            <div className="text-sm text-white/90">{banner.message}</div>
          </div>
        </div>
      )}

      <div className="p-4 lg:p-6 space-y-6">
        {/* GIANT SCOREBOARD */}
        <div className="rounded-[2rem] border-2 border-pink-200 bg-white/80 backdrop-blur-xl p-6 lg:p-10 shadow-bubbly">
          <div className="absolute inset-x-0 top-0 h-2 rounded-t-[2rem] bg-gradient-to-r from-emerald-300 via-purple-300 to-pink-300" />
          <div className="text-center mb-4">
            <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">
              {scoringMode === 'participation' ? '🤝 Participation Score' : '⚔️ Last Hit Score'}
            </span>
          </div>
          <div className="flex items-center justify-center gap-6 lg:gap-12">
            <div className="text-center">
              <div className="text-6xl lg:text-8xl font-extrabold tabular-nums text-emerald-500 drop-shadow-sm">
                {friendlyKills}
              </div>
              <div className="text-sm lg:text-base font-bold text-emerald-600 mt-2">
                Everlast + Terrory
              </div>
              {online && (
                <div className="text-xs text-emerald-500 font-semibold mt-1">
                  {online.friendlyOnline} online
                </div>
              )}
            </div>
            <div className="text-4xl lg:text-6xl font-light text-muted-300">:</div>
            <div className="text-center">
              <div className="text-6xl lg:text-8xl font-extrabold tabular-nums text-pink-500 drop-shadow-sm">
                {enemyKills}
              </div>
              <div className="text-sm lg:text-base font-bold text-pink-600 mt-2">
                Mandatory Again
              </div>
              {online && (
                <div className="text-xs text-pink-500 font-semibold mt-1">
                  {online.enemyOnline} online
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Online counts */}
        {online && (
          <div className="grid grid-cols-3 gap-3">
            <OnlineCard label="Everlast" count={online.everlastOnline} total={online.everlastTotal} side="everlast" />
            <OnlineCard label="Terrory" count={online.allyOnline} total={online.allyTotal} side="ally" />
            <OnlineCard label="Mandatory Again" count={online.enemyOnline} total={online.enemyTotal} side="enemy" />
          </div>
        )}

        {/* Feed columns */}
        <div className="grid gap-4 lg:grid-cols-3">
          <TvFeed
            title="Enemy Deaths"
            icon={Skull}
            color="pink"
            events={enemyDeaths.map((d) => ({
              id: d.id,
              name: d.character_name,
              level: d.character_level,
              side: d.character_side,
              time: d.death_time,
              isPvp: d.is_pvp,
              detail: d.killer_name || d.reason,
            }))}
          />
          <TvFeed
            title="Friendly Deaths"
            icon={Heart}
            color="blue"
            events={friendlyDeaths.map((d) => ({
              id: d.id,
              name: d.character_name,
              level: d.character_level,
              side: d.character_side,
              time: d.death_time,
              isPvp: d.is_pvp,
              detail: d.killer_name || d.reason,
            }))}
          />
          <TvFeed
            title="PvP Kills"
            icon={Swords}
            color="emerald"
            events={pvpKills.map((d) => ({
              id: d.id,
              name: d.character_name,
              level: d.character_level,
              side: d.character_side,
              time: d.death_time,
              isPvp: true,
              detail: `by ${d.killer_name}`,
            }))}
          />
        </div>

        {/* Level changes */}
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="rounded-2xl border-2 border-emerald-200 bg-white/70 p-4">
            <div className="flex items-center gap-2 mb-3">
              <ArrowUpCircle className="size-5 text-emerald-500" />
              <h3 className="text-sm font-bold text-foreground">Level Ups</h3>
            </div>
            <div className="space-y-2">
              {levelUps.length === 0 && <div className="text-xs text-muted-foreground py-2">No level ups.</div>}
              {levelUps.slice(0, 6).map((ev) => (
                <div key={ev.id} className="flex items-center gap-2 text-sm">
                  <span className="font-bold text-foreground truncate">{ev.character_name}</span>
                  <span className="text-xs text-emerald-500 font-bold tabular-nums">
                    {ev.previous_level} → {ev.new_level} (+{ev.level_diff})
                  </span>
                  <span className="ml-auto text-[10px] text-muted-foreground">{timeAgo(ev.observed_at)}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-4">
            <div className="flex items-center gap-2 mb-3">
              <ArrowDownCircle className="size-5 text-pink-400" />
              <h3 className="text-sm font-bold text-foreground">Level Downs</h3>
            </div>
            <div className="space-y-2">
              {levelDowns.length === 0 && <div className="text-xs text-muted-foreground py-2">No level downs.</div>}
              {levelDowns.slice(0, 6).map((ev) => (
                <div key={ev.id} className="flex items-center gap-2 text-sm">
                  <span className="font-bold text-foreground truncate">{ev.character_name}</span>
                  <span className="text-xs text-pink-500 font-bold tabular-nums">
                    {ev.previous_level} → {ev.new_level} ({ev.level_diff})
                  </span>
                  <span className="ml-auto text-[10px] text-muted-foreground">{timeAgo(ev.observed_at)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function OnlineCard({ label, count, total, side }: { label: string; count: number; total: number; side: 'everlast' | 'ally' | 'enemy' }) {
  const colorClass = side === 'everlast' ? 'border-emerald-200 bg-emerald-50/60 text-emerald-600'
    : side === 'ally' ? 'border-purple-200 bg-purple-50/60 text-purple-600'
    : 'border-pink-200 bg-pink-50/60 text-pink-600';
  return (
    <div className={cn('rounded-2xl border-2 p-3 text-center', colorClass)}>
      <div className="text-xs font-bold uppercase tracking-wider opacity-70">{label}</div>
      <div className="text-2xl lg:text-3xl font-extrabold tabular-nums mt-1">
        {count}<span className="text-sm font-normal text-muted-foreground">/{total}</span>
      </div>
    </div>
  );
}

interface TvFeedEvent {
  id: string;
  name: string;
  level: number;
  side: 'everlast' | 'ally' | 'enemy' | 'neutral';
  time: string;
  isPvp: boolean;
  detail: string;
}

function TvFeed({ title, icon: Icon, color, events }: { title: string; icon: typeof Skull; color: string; events: TvFeedEvent[] }) {
  const colorMap: Record<string, string> = {
    pink: 'border-pink-200 bg-pink-50/40 text-pink-500',
    blue: 'border-blue-200 bg-blue-50/40 text-blue-500',
    emerald: 'border-emerald-200 bg-emerald-50/40 text-emerald-500',
  };
  return (
    <div className={cn('rounded-2xl border-2 p-4', colorMap[color])}>
      <div className="flex items-center gap-2 mb-3">
        <Icon className="size-4" />
        <h3 className="text-sm font-bold">{title}</h3>
        <span className="ml-auto text-xs font-bold tabular-nums opacity-60">{events.length}</span>
      </div>
      <div className="space-y-2 max-h-[300px] overflow-y-auto">
        {events.length === 0 && <div className="text-xs text-muted-foreground py-2">No events.</div>}
        {events.map((ev) => (
          <Link
            key={ev.id}
            href={`/character/${encodeURIComponent(ev.name)}`}
            className="block rounded-xl border border-current border-opacity-20 bg-white/60 p-2 hover:bg-white/90 transition-colors"
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-sm font-bold text-foreground truncate">{ev.name}</span>
              <span className="text-xs font-bold tabular-nums text-muted-foreground">Lv {ev.level}</span>
            </div>
            <div className="flex items-center justify-between gap-2 mt-1">
              <span className="text-xs text-muted-foreground truncate">{ev.detail}</span>
              <span className="text-[10px] text-muted-foreground font-semibold">{timeAgo(ev.time)}</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
