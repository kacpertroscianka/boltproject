'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import {
  Trophy, Crown, Skull, Star, Swords, Target, Heart, Sparkles,
  TrendingUp, AlertCircle, Calendar, Shield, Medal, ChevronRight,
} from 'lucide-react';
import { fetchData } from '@/lib/api-client';
import type { WarSide } from '@/lib/types';
import { isFriendlySide, isEnemySide } from '@/lib/tibia';
import { cn } from '@/lib/utils';
import { timeAgo } from '@/lib/format';
import { LoadingState } from '@/components/stat-card';
import { SideBadge } from '@/components/character-tag';

type Period = 'today' | '24h' | '7d' | '30d';

const PERIOD_LABELS: Record<Period, string> = {
  today: 'Today (server save)',
  '24h': 'Last 24 hours',
  '7d': 'Last 7 days',
  '30d': 'Last 30 days',
};

type GuildFilter = 'all' | 'everlast' | 'ally' | 'enemy';

const GUILD_FILTER_LABELS: Record<GuildFilter, string> = {
  all: 'All Guilds',
  everlast: 'Everlast',
  ally: 'Terrory',
  enemy: 'Mandatory Again',
};

type ScoringMethod = 'last-hit' | 'participation';

const SCORING_LABELS: Record<ScoringMethod, string> = {
  'last-hit': 'Last Hit',
  participation: 'Participation',
};

const SERVER_SAVE_HOUR_UTC = 9;

function periodStart(period: Period): string {
  const now = new Date();
  if (period === 'today') {
    const start = new Date(now);
    start.setUTCHours(SERVER_SAVE_HOUR_UTC, 0, 0, 0);
    if (start.getTime() > now.getTime()) {
      start.setUTCDate(start.getUTCDate() - 1);
    }
    return start.toISOString();
  }
  if (period === '24h') return new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();
  if (period === '7d') return new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
  return new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();
}

interface AwardKiller {
  name: string;
  side: string | null;
  guild: string | null;
  vocation: string | null;
  level: number | null;
  kills: number;
  event_ids: string[];
}

interface AwardOopsie {
  name: string;
  side: string;
  vocation: string | null;
  level: number;
  total_deaths: number;
  pvp_deaths: number;
  pve_deaths: number;
  last_death_time: string;
}

interface AwardLevelHero {
  name: string;
  side: string;
  guild: string | null;
  vocation: string | null;
  start_level: number;
  end_level: number;
  total_diff: number;
  event_count: number;
  first_observed: string;
  last_observed: string;
}

interface AwardBiggestTrophy {
  victim: string;
  victim_side: string;
  victim_guild: string | null;
  victim_level: number;
  killer: string | null;
  killer_side: string | null;
  killer_guild: string | null;
  death_time: string;
  event_id: string;
}

interface AwardSummary {
  total_events: number;
  pvp_events: number;
  friendly_kills: number;
  enemy_kills: number;
  level_events: number;
}

interface CandyAwardsData {
  killer_rankings: AwardKiller[];
  participation_rankings: AwardKiller[];
  oopsie_rankings: AwardOopsie[];
  level_hero_entries: AwardLevelHero[];
  biggest_trophy: AwardBiggestTrophy | null;
  summary: AwardSummary;
}

function toWarSide(s: string | null | undefined): WarSide | null {
  if (s === 'everlast' || s === 'ally' || s === 'enemy' || s === 'neutral') return s;
  return null;
}

export default function CandyAwardsPage() {
  const [period, setPeriod] = useState<Period>('today');
  const [guildFilter, setGuildFilter] = useState<GuildFilter>('all');
  const [scoring, setScoring] = useState<ScoringMethod>('last-hit');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [data, setData] = useState<CandyAwardsData | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(false);
    setData(null);
    fetchData<CandyAwardsData>('candy-awards', {
      since: periodStart(period),
      guildFilter,
    })
      .then((d) => { if (active) setData(d); })
      .catch(() => { if (active) setError(true); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [period, guildFilter]);

  const killerRankings = useMemo(() => {
    if (!data) return [];
    return scoring === 'last-hit' ? data.killer_rankings : data.participation_rankings;
  }, [data, scoring]);

  const killerOfDay = killerRankings[0] ?? null;
  const friendlyRankings = killerRankings.filter((k) => isFriendlySide(toWarSide(k.side)));
  const enemyRankings = killerRankings.filter((k) => isEnemySide(toWarSide(k.side)));
  const mvpAlliance = friendlyRankings[0] ?? null;
  const mostWantedEnemy = enemyRankings[0] ?? null;

  const oopsieOfDay = data?.oopsie_rankings[0] ?? null;
  const levelHero = data?.level_hero_entries[0] ?? null;
  const biggestTrophy = data?.biggest_trophy ?? null;
  const summary = data?.summary;

  if (loading) return <LoadingState label="Calculating candy awards..." />;

  return (
    <div className="space-y-6 animate-float-up">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <Trophy className="size-6 text-amber-400" fill="currentColor" />
            🍬 Candy Awards
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5 font-semibold">
            The sweetest legends of Sinistra!
          </p>
        </div>
        <div className="flex items-center gap-1.5 rounded-full border-2 border-amber-200 bg-amber-50 px-3 py-1.5 shadow-bubbly">
          <Sparkles className="size-3.5 text-amber-400" />
          <span className="text-xs font-bold text-amber-600">Awards Ceremony</span>
        </div>
      </div>

      {error && (
        <div className="rounded-2xl border-2 border-amber-200 bg-amber-50/60 p-4 text-sm font-semibold text-amber-600 flex items-center gap-2">
          <AlertCircle className="size-4 shrink-0" />
          Failed to load awards data. Please try again.
        </div>
      )}

      {/* Filters */}
      <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-4 shadow-bubbly space-y-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs font-bold text-muted-foreground">
            <Calendar className="size-3.5" /> Period:
          </div>
          <div className="flex gap-1">
            {(Object.keys(PERIOD_LABELS) as Period[]).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={cn(
                  'rounded-lg border-2 px-2.5 py-1 text-[11px] font-bold transition-colors',
                  period === p
                    ? 'border-pink-300 bg-pink-50 text-pink-500'
                    : 'border-pink-100 bg-white/40 text-muted-foreground hover:bg-pink-50',
                )}
              >
                {PERIOD_LABELS[p]}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs font-bold text-muted-foreground">
            <Shield className="size-3.5" /> Guild:
          </div>
          <div className="flex gap-1">
            {(Object.keys(GUILD_FILTER_LABELS) as GuildFilter[]).map((g) => (
              <button
                key={g}
                onClick={() => setGuildFilter(g)}
                className={cn(
                  'rounded-lg border-2 px-2.5 py-1 text-[11px] font-bold transition-colors',
                  guildFilter === g
                    ? g === 'everlast'
                      ? 'border-emerald-300 bg-emerald-50 text-emerald-600'
                      : g === 'ally'
                        ? 'border-purple-300 bg-purple-50 text-purple-600'
                        : g === 'enemy'
                          ? 'border-pink-300 bg-pink-50 text-pink-500'
                          : 'border-pink-300 bg-pink-50 text-pink-500'
                    : 'border-pink-100 bg-white/40 text-muted-foreground hover:bg-pink-50',
                )}
              >
                {GUILD_FILTER_LABELS[g]}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs font-bold text-muted-foreground">
            <Swords className="size-3.5" /> Kill scoring:
          </div>
          <div className="flex gap-1">
            {(Object.keys(SCORING_LABELS) as ScoringMethod[]).map((s) => (
              <button
                key={s}
                onClick={() => setScoring(s)}
                className={cn(
                  'rounded-lg border-2 px-2.5 py-1 text-[11px] font-bold transition-colors',
                  scoring === s
                    ? 'border-amber-300 bg-amber-50 text-amber-600'
                    : 'border-pink-100 bg-white/40 text-muted-foreground hover:bg-pink-50',
                )}
              >
                {SCORING_LABELS[s]}
              </button>
            ))}
          </div>
        </div>

        {summary && (
          <div className="flex flex-wrap gap-3 border-t border-pink-100 pt-2">
            <span className="text-[10px] font-bold text-muted-foreground">
              {summary.total_events} total events · {summary.pvp_events} PvP · {summary.friendly_kills} friendly kills · {summary.enemy_kills} enemy kills · {summary.level_events} level events
            </span>
          </div>
        )}

        <div className="text-[10px] text-muted-foreground font-semibold leading-relaxed border-t border-pink-100 pt-2">
          Awards are computed from real canonical death events and level events in the selected period.
          {scoring === 'last-hit'
            ? ' Last Hit credits the killing blow. Participation counts distinct opposing deaths where the player participated as killer or assistant.'
            : ' Participation counts distinct opposing deaths where the player participated as killer or assistant.'}
          {' '}Level Hero uses observed snapshots, not exact in-game level-up times.
        </div>
      </div>

      {/* Award cards */}
      <div className="grid gap-4 md:grid-cols-2">
        <AwardCard
          icon={Crown}
          emoji="👑"
          title="Killer of the Day"
          accent="gold"
          winner={killerOfDay}
          emptyText="No PvP kills recorded in this period."
        >
          {killerOfDay && (
            <KillerWinnerDetail stat={killerOfDay} scoring={scoring} />
          )}
        </AwardCard>

        <AwardCard
          icon={Skull}
          emoji="💀"
          title="Oopsie of the Day"
          accent="silver"
          winner={oopsieOfDay}
          emptyText="No deaths recorded in this period."
        >
          {oopsieOfDay && (
            <OopsieWinnerDetail stat={oopsieOfDay} />
          )}
        </AwardCard>

        <AwardCard
          icon={Star}
          emoji="⭐"
          title="Level Hero"
          accent="bronze"
          winner={levelHero}
          emptyText="No level gains recorded in this period."
        >
          {levelHero && (
            <LevelHeroDetail entry={levelHero} />
          )}
        </AwardCard>

        <AwardCard
          icon={Swords}
          emoji="⚔️"
          title="Biggest Trophy"
          accent="gold"
          winner={biggestTrophy}
          emptyText="No enemy PvP kills recorded in this period."
        >
          {biggestTrophy && (
            <BiggestTrophyDetail entry={biggestTrophy} />
          )}
        </AwardCard>

        <AwardCard
          icon={Heart}
          emoji="💚"
          title="Most Valuable Alliance Player"
          accent="gold"
          winner={mvpAlliance}
          emptyText="No friendly PvP kills recorded in this period."
        >
          {mvpAlliance && (
            <KillerWinnerDetail stat={mvpAlliance} scoring={scoring} />
          )}
          {friendlyRankings.length > 1 && (
            <RankingList rankings={friendlyRankings.slice(0, 5)} scoring={scoring} />
          )}
        </AwardCard>

        <AwardCard
          icon={Target}
          emoji="🎯"
          title="Most Wanted Enemy"
          accent="gold"
          winner={mostWantedEnemy}
          emptyText="No enemy PvP kills recorded in this period."
        >
          {mostWantedEnemy && (
            <KillerWinnerDetail stat={mostWantedEnemy} scoring={scoring} />
          )}
          {enemyRankings.length > 1 && (
            <RankingList rankings={enemyRankings.slice(0, 5)} scoring={scoring} />
          )}
        </AwardCard>
      </div>

      {/* Hall of Fame — rankings summary */}
      <div className="rounded-3xl border-2 border-amber-200 bg-gradient-to-br from-amber-50/70 via-pink-50/40 to-purple-50/30 p-5 shadow-bubbly">
        <div className="flex items-center gap-2 mb-4">
          <Trophy className="size-5 text-amber-400" />
          <h2 className="text-sm font-bold text-foreground">🏆 Candy Hall of Fame</h2>
          <span className="ml-auto text-xs text-muted-foreground font-semibold">
            {PERIOD_LABELS[period]} · {GUILD_FILTER_LABELS[guildFilter]}
          </span>
        </div>

        {killerRankings.length === 0 && (!data || data.oopsie_rankings.length === 0) && (!data || data.level_hero_entries.length === 0) ? (
          <div className="text-center py-6 text-sm text-muted-foreground font-semibold">
            <Trophy className="size-8 mx-auto mb-2 opacity-30" />
            No awards available for this period and guild filter.
          </div>
        ) : (
          <div className="space-y-3">
            {killerRankings.length > 0 && (
              <HallSection title="👑 Top Killers" entries={killerRankings.slice(0, 3).map((k) => ({
                name: k.name, side: toWarSide(k.side), guild: k.guild, value: k.kills, label: 'kills',
              }))} />
            )}
            {data && data.oopsie_rankings.length > 0 && (
              <HallSection title="💀 Most Deaths" entries={data.oopsie_rankings.slice(0, 3).map((v) => ({
                name: v.name, side: toWarSide(v.side), guild: null, value: v.total_deaths, label: 'deaths',
              }))} />
            )}
            {data && data.level_hero_entries.length > 0 && (
              <HallSection title="⭐ Level Heroes" entries={data.level_hero_entries.slice(0, 3).map((h) => ({
                name: h.name, side: toWarSide(h.side), guild: h.guild, value: h.total_diff, label: 'levels gained',
              }))} />
            )}
          </div>
        )}

        <div className="mt-4 text-[10px] text-muted-foreground font-semibold leading-relaxed border-t border-amber-100 pt-3">
          Coverage note: Awards reflect only events stored in the database. Periods before sync started may have incomplete data.
          Level gains are observed between sync snapshots, not exact in-game level-up times.
        </div>
      </div>
    </div>
  );
}

// ===== Award Card =====

const ACCENT_STYLES: Record<string, { border: string; bg: string; iconBg: string; iconColor: string; badge: string }> = {
  gold: {
    border: 'border-amber-300',
    bg: 'bg-gradient-to-br from-amber-50/70 to-white',
    iconBg: 'bg-gradient-to-br from-amber-300 to-yellow-400',
    iconColor: 'text-white',
    badge: 'bg-amber-100 text-amber-600 border-amber-300',
  },
  silver: {
    border: 'border-slate-300',
    bg: 'bg-gradient-to-br from-slate-50/70 to-white',
    iconBg: 'bg-gradient-to-br from-slate-300 to-slate-400',
    iconColor: 'text-white',
    badge: 'bg-slate-100 text-slate-600 border-slate-300',
  },
  bronze: {
    border: 'border-orange-300',
    bg: 'bg-gradient-to-br from-orange-50/70 to-white',
    iconBg: 'bg-gradient-to-br from-orange-300 to-amber-600',
    iconColor: 'text-white',
    badge: 'bg-orange-100 text-orange-600 border-orange-300',
  },
};

function AwardCard({
  icon: Icon,
  emoji,
  title,
  accent,
  winner,
  emptyText,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  emoji: string;
  title: string;
  accent: 'gold' | 'silver' | 'bronze';
  winner: object | null;
  emptyText: string;
  children?: React.ReactNode;
}) {
  const style = ACCENT_STYLES[accent];
  return (
    <div className={cn('rounded-3xl border-2 p-5 shadow-bubbly transition-all', style.border, style.bg)}>
      <div className="flex items-center gap-2 mb-4">
        <div className={cn('flex size-10 items-center justify-center rounded-2xl shadow-bubbly', style.iconBg)}>
          <Icon className={cn('size-5', style.iconColor)} />
        </div>
        <div>
          <h2 className="text-sm font-bold text-foreground flex items-center gap-1.5">
            {emoji} {title}
          </h2>
        </div>
        {winner && (
          <span className={cn('ml-auto rounded-full border-2 px-2 py-0.5 text-[10px] font-bold', style.badge)}>
            Winner
          </span>
        )}
      </div>
      {!winner ? (
        <div className="text-center py-6 text-sm text-muted-foreground font-semibold">
          {emptyText}
        </div>
      ) : (
        children
      )}
    </div>
  );
}

// ===== Winner details =====

function KillerWinnerDetail({ stat, scoring }: { stat: AwardKiller; scoring: ScoringMethod }) {
  const side = toWarSide(stat.side);
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <div className="flex size-10 items-center justify-center rounded-xl bg-amber-100 text-amber-500 text-sm font-bold border-2 border-amber-300">
          <Medal className="size-5" fill="currentColor" />
        </div>
        <div className="min-w-0 flex-1">
          <Link
            href={`/character/${encodeURIComponent(stat.name)}`}
            className="text-sm font-bold text-foreground hover:underline truncate block"
          >
            {stat.name}
          </Link>
          <div className="flex items-center gap-2 flex-wrap mt-0.5">
            {side && <SideBadge side={side} />}
            {stat.vocation && <span className="text-[11px] text-muted-foreground font-semibold">{stat.vocation}</span>}
            {stat.level != null && <span className="text-[11px] text-muted-foreground font-semibold">Lv {stat.level}</span>}
          </div>
        </div>
        <div className="text-right shrink-0">
          <div className="text-2xl font-extrabold tabular-nums text-emerald-500">{stat.kills}</div>
          <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">
            {scoring === 'last-hit' ? 'credited kills' : 'participated kills'}
          </div>
        </div>
      </div>
      {stat.event_ids && stat.event_ids.length > 0 && (
        <Link
          href={`/death-radar`}
          className="flex items-center gap-1 text-[11px] font-bold text-pink-400 hover:underline"
        >
          View {stat.event_ids.length} event{stat.event_ids.length !== 1 ? 's' : ''} in Death Radar
          <ChevronRight className="size-3" />
        </Link>
      )}
    </div>
  );
}

function OopsieWinnerDetail({ stat }: { stat: AwardOopsie }) {
  const side = toWarSide(stat.side);
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <div className="flex size-10 items-center justify-center rounded-xl bg-slate-100 text-slate-500 text-sm font-bold border-2 border-slate-300">
          <Skull className="size-5" />
        </div>
        <div className="min-w-0 flex-1">
          <Link
            href={`/character/${encodeURIComponent(stat.name)}`}
            className="text-sm font-bold text-foreground hover:underline truncate block"
          >
            {stat.name}
          </Link>
          <div className="flex items-center gap-2 flex-wrap mt-0.5">
            {side && <SideBadge side={side} />}
            {stat.vocation && <span className="text-[11px] text-muted-foreground font-semibold">{stat.vocation}</span>}
            <span className="text-[11px] text-muted-foreground font-semibold">Lv {stat.level}</span>
          </div>
        </div>
        <div className="text-right shrink-0">
          <div className="text-2xl font-extrabold tabular-nums text-pink-500">{stat.total_deaths}</div>
          <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">total deaths</div>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-xl border-2 border-pink-100 bg-pink-50/50 p-2 text-center">
          <div className="text-sm font-extrabold tabular-nums text-pink-500">{stat.pvp_deaths}</div>
          <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">PvP</div>
        </div>
        <div className="rounded-xl border-2 border-slate-100 bg-slate-50/50 p-2 text-center">
          <div className="text-sm font-extrabold tabular-nums text-slate-500">{stat.pve_deaths}</div>
          <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">PvE</div>
        </div>
      </div>
      {stat.last_death_time && (
        <div className="text-[11px] text-muted-foreground font-semibold">
          Most recent: {timeAgo(stat.last_death_time)}
        </div>
      )}
    </div>
  );
}

function LevelHeroDetail({ entry }: { entry: AwardLevelHero }) {
  const side = toWarSide(entry.side);
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <div className="flex size-10 items-center justify-center rounded-xl bg-orange-100 text-orange-500 text-sm font-bold border-2 border-orange-300">
          <Star className="size-5" fill="currentColor" />
        </div>
        <div className="min-w-0 flex-1">
          <Link
            href={`/character/${encodeURIComponent(entry.name)}`}
            className="text-sm font-bold text-foreground hover:underline truncate block"
          >
            {entry.name}
          </Link>
          <div className="flex items-center gap-2 flex-wrap mt-0.5">
            {side && <SideBadge side={side} />}
            {entry.vocation && <span className="text-[11px] text-muted-foreground font-semibold">{entry.vocation}</span>}
          </div>
        </div>
        <div className="text-right shrink-0">
          <div className="text-2xl font-extrabold tabular-nums text-emerald-500">+{entry.total_diff}</div>
          <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">levels gained</div>
        </div>
      </div>
      <div className="flex items-center justify-center gap-2 text-sm font-bold">
        <span className="tabular-nums text-muted-foreground">{entry.start_level}</span>
        <TrendingUp className="size-4 text-emerald-500" />
        <span className="tabular-nums text-emerald-500">{entry.end_level}</span>
      </div>
      <div className="text-[11px] text-muted-foreground font-semibold text-center">
        Observed: {timeAgo(entry.first_observed)} → {timeAgo(entry.last_observed)}
      </div>
      <div className="text-[10px] text-muted-foreground font-semibold leading-relaxed bg-orange-50/50 rounded-lg p-2 border border-orange-100">
        Level changes are recorded between sync snapshots, not exact in-game level-up times.
        Based on {entry.event_count} observed event{entry.event_count !== 1 ? 's' : ''}.
      </div>
    </div>
  );
}

function BiggestTrophyDetail({ entry }: { entry: AwardBiggestTrophy }) {
  const victimSide = toWarSide(entry.victim_side);
  const killerSide = toWarSide(entry.killer_side);
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <div className="flex size-10 items-center justify-center rounded-xl bg-amber-100 text-amber-500 text-sm font-bold border-2 border-amber-300">
          <Trophy className="size-5" fill="currentColor" />
        </div>
        <div className="min-w-0 flex-1">
          <Link
            href={`/character/${encodeURIComponent(entry.victim)}`}
            className="text-sm font-bold text-foreground hover:underline truncate block"
          >
            {entry.victim}
          </Link>
          <div className="flex items-center gap-2 flex-wrap mt-0.5">
            {victimSide && <SideBadge side={victimSide} />}
            <span className="text-[11px] text-muted-foreground font-semibold">Lv {entry.victim_level} at death</span>
          </div>
        </div>
      </div>
      <div className="text-center py-2">
        <div className="text-3xl font-extrabold tabular-nums text-amber-500">{entry.victim_level}</div>
        <div className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">victim level at death</div>
      </div>
      <div className="rounded-xl border-2 border-pink-100 bg-pink-50/50 p-3 text-xs">
        <div className="font-semibold text-muted-foreground mb-1">Killed by</div>
        <div className="flex items-center gap-2 flex-wrap">
          {entry.killer ? (
            <Link
              href={`/character/${encodeURIComponent(entry.killer)}`}
              className="font-bold text-foreground hover:underline"
            >
              {entry.killer}
            </Link>
          ) : (
            <span className="font-bold text-muted-foreground">Unknown</span>
          )}
          {killerSide && <SideBadge side={killerSide} />}
        </div>
        <div className="text-[11px] text-muted-foreground mt-1.5">
          {timeAgo(entry.death_time)}
        </div>
      </div>
    </div>
  );
}

function RankingList({ rankings, scoring }: { rankings: AwardKiller[]; scoring: ScoringMethod }) {
  return (
    <div className="mt-3 border-t border-pink-100 pt-3">
      <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-2">
        Top 5 — {SCORING_LABELS[scoring]}
      </div>
      <div className="space-y-1.5">
        {rankings.map((r, i) => {
          const side = toWarSide(r.side);
          return (
            <div key={r.name} className="flex items-center gap-2 text-xs">
              <span className={cn(
                'flex size-5 items-center justify-center rounded-lg text-[10px] font-bold shrink-0',
                i === 0 ? 'bg-amber-100 text-amber-500' : i === 1 ? 'bg-slate-100 text-slate-500' : 'bg-orange-100 text-orange-500',
              )}>
                {i + 1}
              </span>
              <Link
                href={`/character/${encodeURIComponent(r.name)}`}
                className="font-bold text-foreground hover:underline truncate"
              >
                {r.name}
              </Link>
              {side && <SideBadge side={side} />}
              <span className="ml-auto font-bold tabular-nums text-emerald-500">{r.kills}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function HallSection({ title, entries }: {
  title: string;
  entries: { name: string; side: WarSide | null; guild: string | null; value: number; label: string }[];
}) {
  return (
    <div>
      <div className="text-xs font-bold text-foreground mb-2">{title}</div>
      <div className="grid gap-2 sm:grid-cols-3">
        {entries.map((e, i) => (
          <div
            key={e.name}
            className={cn(
              'rounded-xl border-2 p-3',
              i === 0 ? 'border-amber-300 bg-amber-50/60' : i === 1 ? 'border-slate-300 bg-slate-50/60' : 'border-orange-200 bg-orange-50/60',
            )}
          >
            <div className="flex items-center gap-1.5 mb-1">
              <span className={cn(
                'flex size-5 items-center justify-center rounded-lg text-[10px] font-bold',
                i === 0 ? 'bg-amber-200 text-amber-600' : i === 1 ? 'bg-slate-200 text-slate-600' : 'bg-orange-200 text-orange-600',
              )}>
                {i + 1}
              </span>
              {e.side && <SideBadge side={e.side} />}
            </div>
            <Link
              href={`/character/${encodeURIComponent(e.name)}`}
              className="text-sm font-bold text-foreground hover:underline block truncate"
            >
              {e.name}
            </Link>
            <div className="text-[11px] text-muted-foreground font-semibold mt-0.5">
              {e.value} {e.label}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
