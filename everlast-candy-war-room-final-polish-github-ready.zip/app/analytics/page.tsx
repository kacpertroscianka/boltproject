'use client';

import { useEffect, useState } from 'react';
import {
  BarChart3,
  Swords,
  Trophy,
  Skull,
  TrendingUp,
  Users,
  Crown,
  Star,
  Heart,
  ArrowUpCircle,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  getRecentDeaths,
  getGuilds,
  computeWarScore,
  buildDailySeries,
  computeTopKillers,
  computeMostKilled,
  getLevelGuildLeaderboard,
  type LevelLeaderboardEntry,
} from '@/lib/queries';
import type { DeathEvent, Guild } from '@/lib/types';
import { LoadingState, MockDataBadge, StatCard } from '@/components/stat-card';
import { CharacterTag } from '@/components/character-tag';
import { GUILD_EVERLAST, GUILD_ALLY, GUILD_ENEMY } from '@/lib/tibia';

const CANDY_TOOLTIP = {
  backgroundColor: 'hsl(324 100% 98%)',
  border: '2px solid hsl(324 100% 85%)',
  borderRadius: '12px',
  fontSize: '12px',
  color: 'hsl(276 19% 35%)',
};

export default function AnalyticsPage() {
  const [loading, setLoading] = useState(true);
  const [loadWarning, setLoadWarning] = useState<string | null>(null);
  const [deaths, setDeaths] = useState<DeathEvent[]>([]);
  const [guilds, setGuilds] = useState<Guild[]>([]);
  const [elLevelBoard, setElLevelBoard] = useState<LevelLeaderboardEntry[]>([]);
  const [allyLevelBoard, setAllyLevelBoard] = useState<LevelLeaderboardEntry[]>([]);
  const [enemyLevelBoard, setEnemyLevelBoard] = useState<LevelLeaderboardEntry[]>([]);

  useEffect(() => {
    Promise.allSettled([
      getRecentDeaths(2000),
      getGuilds(),
      getLevelGuildLeaderboard('everlast', 7, 10),
      getLevelGuildLeaderboard('ally', 7, 10),
      getLevelGuildLeaderboard('enemy', 7, 10),
    ])
      .then(([d, g, elb, alb, enb]) => {
        const failed = [d, g, elb, alb, enb].filter(item => item.status === 'rejected').length;
        setLoadWarning(failed ? `${failed} źródeł analitycznych jest niedostępnych. Nie interpretuj brakujących danych jako zera.` : null);
        if (d.status === 'fulfilled') setDeaths(d.value); else console.error(d.reason);
        if (g.status === 'fulfilled') setGuilds(g.value); else console.error(g.reason);
        if (elb.status === 'fulfilled') setElLevelBoard(elb.value);
        if (alb.status === 'fulfilled') setAllyLevelBoard(alb.value);
        if (enb.status === 'fulfilled') setEnemyLevelBoard(enb.value);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <LoadingState label="Analyzing candy war data..." />;

  const score = computeWarScore(deaths);
  const daily = buildDailySeries(deaths, 14);
  const topKillers = computeTopKillers(deaths, 10);
  const mostKilled = computeMostKilled(deaths, 10);
  const hasMockData = deaths.some((d) => d.source === 'mock-dev');
  const isHistoryCapped = deaths.length >= 2000;

  const everlastGuild = guilds.find((g) => g.name === GUILD_EVERLAST);
  const allyGuild = guilds.find((g) => g.name === GUILD_ALLY);
  const enemyGuild = guilds.find((g) => g.name === GUILD_ENEMY);

  const pvpCount = deaths.filter((d) => d.is_pvp).length;
  const pveCount = deaths.filter((d) => !d.is_pvp).length;
  const pieData = [
    { name: 'PvP Deaths', value: pvpCount, color: 'hsl(340 100% 68%)' },
    { name: 'PvE Deaths', value: pveCount, color: 'hsl(52 100% 70%)' },
  ];

  const comparisonData = [
    { metric: 'Kills', Everlast: score.everlastKills, Terrory: score.allyKills, Enemy: score.enemyKills },
    { metric: 'Deaths', Everlast: score.everlastDeaths, Terrory: score.allyDeaths, Enemy: score.enemyDeaths },
    { metric: 'Members', Everlast: everlastGuild?.member_count ?? 0, Terrory: allyGuild?.member_count ?? 0, Enemy: enemyGuild?.member_count ?? 0 },
  ];

  return (
    <div className="space-y-6 animate-float-up">
      {loadWarning && <div role="alert" className="rounded-2xl border-2 border-amber-200 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-800">⚠️ {loadWarning}</div>}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <BarChart3 className="size-6 text-purple-400" />
            Guild War Analytics
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5 font-semibold">
            Everlast Alliance vs Mandatory Again — deep dive comparison
          </p>
        </div>
        <MockDataBadge show={hasMockData} />
      </div>

      <div role="note" className="rounded-xl border border-purple-200 bg-purple-50/70 px-4 py-2 text-xs font-semibold text-purple-600">
        This page summarizes the most recent recorded deaths (up to 2,000), with legacy killer-side attribution.
        For the authoritative alliance war score, use the main dashboard's canonical Last Hit / Participation scoreboard.
        {isHistoryCapped && ' The 2,000-event limit was reached, so these analytics may be incomplete.'}
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Everlast K/D" value={score.everlastDeaths > 0 ? (score.everlastKills / score.everlastDeaths).toFixed(2) : '—'} sublabel="Kill-to-death ratio" icon={Trophy} side="everlast" />
        <StatCard label="Terrory K/D" value={score.allyDeaths > 0 ? (score.allyKills / score.allyDeaths).toFixed(2) : '—'} sublabel="Ally kill-to-death ratio" icon={Trophy} side="ally" />
        <StatCard label="Alliance K/D" value={score.friendlyDeaths > 0 ? (score.friendlyKills / score.friendlyDeaths).toFixed(2) : '—'} sublabel="Combined ratio" icon={Swords} side="everlast" />
        <StatCard label="Enemy K/D" value={score.enemyDeaths > 0 ? (score.enemyKills / score.enemyDeaths).toFixed(2) : '—'} sublabel="Kill-to-death ratio" icon={Trophy} side="enemy" />
      </div>

      <div className="rounded-2xl border-2 border-purple-200 bg-white/70 p-5 shadow-bubbly">
        <h2 className="text-sm font-bold text-foreground mb-4 flex items-center gap-1.5">
          <BarChart3 className="size-4 text-purple-400" /> Guild Comparison
        </h2>
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={comparisonData} margin={{ top: 5, right: 20, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(324 50% 90%)" />
            <XAxis dataKey="metric" stroke="hsl(276 12% 50%)" fontSize={12} tickLine={false} axisLine={false} />
            <YAxis stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
            <Tooltip contentStyle={CANDY_TOOLTIP} />
            <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 600 }} />
            <Bar dataKey="Everlast" fill="hsl(155 57% 57%)" radius={[6, 6, 0, 0]} />
            <Bar dataKey="Terrory" fill="hsl(270 60% 65%)" radius={[6, 6, 0, 0]} />
            <Bar dataKey="Enemy" fill="hsl(340 100% 68%)" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-foreground flex items-center gap-1.5">
              <TrendingUp className="size-4 text-emerald-500" /> 14-Day Kill Trends
            </h2>
            <p className="text-xs text-muted-foreground font-semibold">Daily PvP kills by guild</p>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={280}>
          <LineChart data={daily} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(324 50% 90%)" />
            <XAxis dataKey="label" stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} />
            <YAxis stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
            <Tooltip contentStyle={CANDY_TOOLTIP} />
            <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 600 }} />
            <Line type="monotone" dataKey="friendlyKills" name="Alliance Kills" stroke="hsl(155 57% 57%)" strokeWidth={2.5} dot={{ fill: 'hsl(155 57% 57%)', r: 3 }} />
            <Line type="monotone" dataKey="enemyKills" name="Enemy Kills" stroke="hsl(340 100% 68%)" strokeWidth={2.5} dot={{ fill: 'hsl(340 100% 68%)', r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center gap-2 mb-4">
            <Crown className="size-4 text-amber-400" fill="currentColor" />
            <h2 className="text-sm font-bold text-foreground">Top Killers</h2>
          </div>
          <div className="space-y-3">
            {topKillers.length === 0 && <div className="text-sm text-muted-foreground py-4 text-center font-semibold">No kills recorded.</div>}
            {topKillers.map((killer, i) => (
              <div key={killer.name} className="flex items-center gap-3">
                <div className={`flex size-7 items-center justify-center rounded-xl text-xs font-bold ${i === 0 ? 'bg-amber-100 text-amber-500' : 'bg-purple-100 text-purple-400'}`}>
                  {i + 1}
                </div>
                <CharacterTag name={killer.name} vocation={killer.vocation} level={killer.level} side={killer.side ?? undefined} />
                <div className="ml-auto flex items-center gap-1.5">
                  <Swords className="size-3.5 text-emerald-500" />
                  <span className="text-sm font-bold tabular-nums text-emerald-500">{killer.kills}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center gap-2 mb-4">
            <Heart className="size-4 text-pink-400" fill="currentColor" />
            <h2 className="text-sm font-bold text-foreground">Most Frequently Killed</h2>
          </div>
          <div className="space-y-3">
            {mostKilled.length === 0 && <div className="text-sm text-muted-foreground py-4 text-center font-semibold">No PvP deaths recorded.</div>}
            {mostKilled.map((victim, i) => (
              <div key={victim.name} className="flex items-center gap-3">
                <div className="flex size-7 items-center justify-center rounded-xl bg-purple-100 text-xs font-bold text-purple-400">
                  {i + 1}
                </div>
                <CharacterTag name={victim.name} vocation={victim.vocation} level={victim.level} side={victim.side} />
                <div className="ml-auto flex items-center gap-1.5">
                  <Skull className="size-3.5 text-pink-400" />
                  <span className="text-sm font-bold tabular-nums text-pink-500">{victim.deaths}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Level gain leaderboards */}
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border-2 border-emerald-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center gap-2 mb-4">
            <ArrowUpCircle className="size-4 text-emerald-500" />
            <h2 className="text-sm font-bold text-foreground">Everlast Level Gains</h2>
          </div>
          <div className="space-y-3">
            {elLevelBoard.length === 0 && <div className="text-sm text-muted-foreground py-4 text-center font-semibold">No level gains recorded.</div>}
            {elLevelBoard.map((entry, i) => (
              <div key={entry.name} className="flex items-center gap-3">
                <div className={`flex size-7 items-center justify-center rounded-xl text-xs font-bold ${i === 0 ? 'bg-amber-100 text-amber-500' : 'bg-emerald-100 text-emerald-500'}`}>
                  {i + 1}
                </div>
                <CharacterTag name={entry.name} side="everlast" />
                <div className="ml-auto flex items-center gap-3">
                  <span className="text-xs text-muted-foreground font-semibold">{entry.events} jumps</span>
                  <span className="text-sm font-bold tabular-nums text-emerald-500">+{entry.totalGain}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border-2 border-purple-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center gap-2 mb-4">
            <ArrowUpCircle className="size-4 text-purple-500" />
            <h2 className="text-sm font-bold text-foreground">Terrory Level Gains</h2>
          </div>
          <div className="space-y-3">
            {allyLevelBoard.length === 0 && <div className="text-sm text-muted-foreground py-4 text-center font-semibold">No level gains recorded.</div>}
            {allyLevelBoard.map((entry, i) => (
              <div key={entry.name} className="flex items-center gap-3">
                <div className={`flex size-7 items-center justify-center rounded-xl text-xs font-bold ${i === 0 ? 'bg-amber-100 text-amber-500' : 'bg-purple-100 text-purple-500'}`}>
                  {i + 1}
                </div>
                <CharacterTag name={entry.name} side="ally" />
                <div className="ml-auto flex items-center gap-3">
                  <span className="text-xs text-muted-foreground font-semibold">{entry.events} jumps</span>
                  <span className="text-sm font-bold tabular-nums text-purple-500">+{entry.totalGain}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center gap-2 mb-4">
            <ArrowUpCircle className="size-4 text-pink-400" />
            <h2 className="text-sm font-bold text-foreground">Mandatory Again Level Gains</h2>
          </div>
          <div className="space-y-3">
            {enemyLevelBoard.length === 0 && <div className="text-sm text-muted-foreground py-4 text-center font-semibold">No level gains recorded.</div>}
            {enemyLevelBoard.map((entry, i) => (
              <div key={entry.name} className="flex items-center gap-3">
                <div className={`flex size-7 items-center justify-center rounded-xl text-xs font-bold ${i === 0 ? 'bg-amber-100 text-amber-500' : 'bg-pink-100 text-pink-500'}`}>
                  {i + 1}
                </div>
                <CharacterTag name={entry.name} side="enemy" />
                <div className="ml-auto flex items-center gap-3">
                  <span className="text-xs text-muted-foreground font-semibold">{entry.events} jumps</span>
                  <span className="text-sm font-bold tabular-nums text-pink-500">+{entry.totalGain}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border-2 border-purple-200 bg-white/70 p-5 shadow-bubbly">
          <h2 className="text-sm font-bold text-foreground mb-4">Death Classification</h2>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={4} dataKey="value">
                {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip contentStyle={CANDY_TOOLTIP} />
              <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 600 }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
          <div className="flex items-center gap-2 mb-4">
            <Users className="size-4 text-emerald-500" />
            <h2 className="text-sm font-bold text-foreground">Guild Rosters</h2>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="rounded-xl border-2 border-emerald-200 bg-emerald-50 p-4">
              <div className="text-xs font-bold text-emerald-600 mb-2">Everlast</div>
              <div className="text-2xl font-bold text-foreground tabular-nums">{everlastGuild?.member_count ?? 0}</div>
              <div className="text-xs text-muted-foreground mt-1 font-semibold">Members tracked</div>
            </div>
            <div className="rounded-xl border-2 border-purple-200 bg-purple-50 p-4">
              <div className="text-xs font-bold text-purple-500 mb-2">Terrory</div>
              <div className="text-2xl font-bold text-foreground tabular-nums">{allyGuild?.member_count ?? 0}</div>
              <div className="text-xs text-muted-foreground mt-1 font-semibold">Allied members</div>
            </div>
            <div className="rounded-xl border-2 border-pink-200 bg-pink-50 p-4">
              <div className="text-xs font-bold text-pink-500 mb-2">Mandatory Again</div>
              <div className="text-2xl font-bold text-foreground tabular-nums">{enemyGuild?.member_count ?? 0}</div>
              <div className="text-xs text-muted-foreground mt-1 font-semibold">Members tracked</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
