'use client';

import { useState, useRef, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { Eye, EyeOff, Lock, Sparkles, Heart, Star, Candy, Mail } from 'lucide-react';

export default function UnlockPage() {
  const searchParams = useSearchParams();
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ password }),
      });
      if (res.ok) {
        const redirect = searchParams.get('redirect') || '/';
        window.location.href = redirect;
      } else {
        const data = await res.json();
        setError(data.error === 'Incorrect password' ? 'Upsik! Złe hasło 🍭 Spróbuj ponownie!' : data.error || 'Error');
      }
    } catch {
      setError('Connection error. Try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-pink-100 via-purple-50 to-blue-100"
      style={{ fontFamily: 'inherit' }}
    >
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <Star className="absolute top-[12%] left-[10%] size-8 text-yellow-300/50 animate-sparkle" fill="currentColor" />
        <Heart className="absolute top-[22%] right-[12%] size-7 text-pink-300/50 animate-bounce-soft" fill="currentColor" />
        <Sparkles className="absolute top-[60%] left-[6%] size-9 text-purple-300/40 animate-sparkle" style={{ animationDelay: '0.5s' }} />
        <Star className="absolute top-[75%] right-[8%] size-6 text-blue-300/50 animate-sparkle" fill="currentColor" style={{ animationDelay: '1s' }} />
        <Heart className="absolute top-[85%] left-[15%] size-5 text-pink-300/40 animate-bounce-soft" fill="currentColor" style={{ animationDelay: '0.3s' }} />
        <Candy className="absolute top-[45%] right-[18%] size-8 text-purple-200/40 animate-wiggle" />
      </div>

      <div className="relative z-10 w-full max-w-md">
        <div className="rounded-[2rem] border-4 border-pink-200 bg-white/80 backdrop-blur-xl p-8 shadow-[0_20px_60px_-15px_rgba(236,72,153,0.3)]">
          <div className="flex justify-center mb-6">
            <div className="relative">
              <div className="flex size-16 items-center justify-center rounded-3xl bg-gradient-to-br from-pink-300 via-purple-300 to-blue-300 shadow-bubbly">
                <Candy className="size-8 text-white" />
              </div>
              <Sparkles className="absolute -top-2 -right-2 size-5 text-yellow-300 animate-sparkle" />
              <Heart className="absolute -bottom-1 -left-2 size-4 text-pink-400 animate-heartbeat" fill="currentColor" />
            </div>
          </div>

          <h1 className="text-center text-2xl font-bold tracking-tight text-foreground mb-1">
            🍬 Everlast Secret Candy Club 🔐
          </h1>
          <p className="text-center text-sm text-muted-foreground font-semibold mb-6">
            Tylko dla wtajemniczonych! 💖
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 size-5 text-purple-400" />
              <input
                ref={inputRef}
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Wpisz tajne hasło..."
                autoComplete="current-password"
                disabled={loading}
                className="w-full rounded-2xl border-2 border-pink-200 bg-white/70 py-3.5 pl-12 pr-12 text-sm font-semibold text-foreground placeholder:text-muted-foreground/60 focus:border-pink-400 focus:outline-none focus:ring-4 focus:ring-pink-100 transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg p-1.5 hover:bg-pink-100 transition-colors"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff className="size-4 text-purple-400" /> : <Eye className="size-4 text-purple-400" />}
              </button>
            </div>

            {error && (
              <div className="rounded-xl border-2 border-pink-200 bg-pink-50 px-4 py-3 text-center text-sm font-bold text-pink-600 animate-float-up">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading || !password}
              className="w-full rounded-2xl border-2 border-pink-300 bg-gradient-to-r from-pink-200 via-purple-200 to-blue-200 py-3.5 text-sm font-bold text-foreground shadow-bubbly transition-all hover:scale-[1.02] active:scale-[0.98] disabled:opacity-50 disabled:hover:scale-100"
            >
              {loading ? '⏳ Otwieram...' : '🔓 Otwórz Candy War Room'}
            </button>
          </form>
        </div>

        <div className="mt-6 text-center">
          <span
            className="text-xs font-semibold tracking-wide text-muted-foreground"
            style={{ fontFamily: 'inherit' }}
          >
            <Mail className="inline-block size-3 mr-1 -translate-y-px" />
            powered by Courier
          </span>
        </div>
      </div>
    </div>
  );
}
