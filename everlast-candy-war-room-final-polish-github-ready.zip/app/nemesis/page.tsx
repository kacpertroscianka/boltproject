'use client';

import { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import {
  Skull, Swords, Search, Heart, Sparkles, Star, X,
  TrendingUp, AlertCircle,
} from 'lucide-react';
import { getCanonicalWarEvents } from '@/lib/queries';
import type { CanonicalWarEvent, WarSide } from '@/lib/types';
import { isFriendlySide, isEnemySide, SIDE_LABELS } from '@/lib/tibia';
import { cn } from '@/lib/utils';

interface Rivalry {
  pairId: string;
  killer: string;
  killerSide: WarSide | null;
  victim: string;
  victimSide: WarSide | null;
  killCount: number;
  events: { eventId: string; time: string; level: number }[];
  revengeCount: number;
  revengeEvents: { eventId: string; time: string; level: number }[];
}

export default function NemesisPage() {
  const [events, setEvents] = useState<CanonicalWarEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'friendly' | 'enemy'>('all');

  useEffect(() => {
    getCanonicalWarEvents(2000).then((data) => {
      setEvents(data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const rivalries = useMemo(() => {
    const killMap = new Map<string, { killer: string; killerSide: WarSide | null; victim: string; victimSide: WarSide | null; events: { eventId: string; time: string; level: number }[] }>();

    for (const e of events) {
      if (!e.is_pvp || !e.is_player_kill) continue;
      if (!e.killer_name || e.killer_name === e.character_name) continue;

      const killerFriendly = isFriendlySide(e.killer_current_side ?? e.stored_killer_side);
      const killerEnemy = isEnemySide(e.killer_current_side ?? e.stored_killer_side);
      const victimFriendly = isFriendlySide(e.character_side);
      const victimEnemy = isEnemySide(e.character_side);

      if (!killerFriendly && !killerEnemy) continue;
      if (!victimFriendly && !victimEnemy) continue;
      if (killerFriendly && victimFriendly) continue;
      if (killerEnemy && victimEnemy) continue;

      const pairId = `${e.killer_name}→${e.character_name}`;
      const existing = killMap.get(pairId);
      if (existing) {
        existing.events.push({ eventId: e.event_id, time: e.death_time, level: e.character_level });
      } else {
        killMap.set(pairId, {
          killer: e.killer_name,
          killerSide: e.killer_current_side ?? e.stored_killer_side,
          victim: e.character_name,
          victimSide: e.character_side,
          events: [{ eventId: e.event_id, time: e.death_time, level: e.character_level }],
        });
      }
    }

    const result: Rivalry[] = [];
    const allValues = Array.from(killMap.values());
    for (const data of allValues) {
      if (data.events.length < 2) continue;

      const reversePairId = `${data.victim}→${data.killer}`;
      const reverse = killMap.get(reversePairId);
      const revengeEvents = reverse ? reverse.events : [];

      result.push({
        pairId: `${data.killer}→${data.victim}`,
        killer: data.killer,
        killerSide: data.killerSide,
        victim: data.victim,
        victimSide: data.victimSide,
        killCount: data.events.length,
        events: data.events,
        revengeCount: revengeEvents.length,
        revengeEvents,
      });
    }

    result.sort((a, b) => b.killCount - a.killCount);
    return result;
  }, [events]);

  const filteredRivalries = useMemo(() => {
    return rivalries.filter((r) => {
      if (search) {
        const q = search.toLowerCase();
        if (!r.killer.toLowerCase().includes(q) && !r.victim.toLowerCase().includes(q)) return false;
      }
      if (filter === 'friendly' && !isFriendlySide(r.killerSide)) return false;
      if (filter === 'enemy' && !isEnemySide(r.killerSide)) return false;
      return true;
    });
  }, [rivalries, search, filter]);

  if (loading) {
    return <div className="flex items-center justify-center min-h-[40vh]"><Skull className="size-8 text-pink-400 animate-spin" /></div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <Skull className="size-6 text-pink-400" />
          Nemesis Board
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          Killer-victim rivalries from real canonical PvP records
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-pink-400" />
          <input
            type="text"
            placeholder="Search killer or victim..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border-2 border-pink-200 bg-white/60 py-2 pl-10 pr-4 text-sm font-semibold text-foreground focus:border-pink-400 focus:outline-none"
          />
        </div>
        <div className="flex gap-1">
          {(['all', 'friendly', 'enemy'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn('rounded-xl border-2 px-3 py-2 text-xs font-bold transition-colors', filter === f ? 'border-pink-300 bg-pink-50 text-pink-500' : 'border-pink-100 bg-white/40 text-muted-foreground')}
            >
              {f === 'all' ? 'All' : f === 'friendly' ? '💚 Friendly' : '🩸 Enemy'}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl border-2 border-pink-200 bg-white/60 p-3 text-center">
          <div className="text-2xl font-extrabold tabular-nums text-foreground">{rivalries.length}</div>
          <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Rivalries</div>
        </div>
        <div className="rounded-2xl border-2 border-emerald-200 bg-emerald-50/40 p-3 text-center">
          <div className="text-2xl font-extrabold tabular-nums text-emerald-600">{rivalries.filter((r) => isFriendlySide(r.killerSide)).length}</div>
          <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">Friendly Nemesis</div>
        </div>
        <div className="rounded-2xl border-2 border-purple-200 bg-purple-50/40 p-3 text-center">
          <div className="text-2xl font-extrabold tabular-nums text-purple-600">{rivalries.filter((r) => r.revengeCount > 0).length}</div>
          <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">With Revenge</div>
        </div>
      </div>

      {filteredRivalries.length === 0 ? (
        <div className="text-center py-16">
          <Skull className="size-12 mx-auto text-pink-200 mb-3" />
          <div className="text-sm font-bold text-muted-foreground">
            {rivalries.length === 0 ? 'No rivalries found yet.' : 'No rivalries match your filters.'}
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            Rivalries require 2+ recorded PvP kills between the same killer and victim.
          </div>
        </div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {filteredRivalries.slice(0, 40).map((r) => (
            <RivalryCard key={r.pairId} rivalry={r} />
          ))}
        </div>
      )}
    </div>
  );
}

function RivalryCard({ rivalry }: { rivalry: Rivalry }) {
  const killerColor = rivalry.killerSide === 'everlast' ? 'text-emerald-600' : rivalry.killerSide === 'ally' ? 'text-purple-600' : rivalry.killerSide === 'enemy' ? 'text-pink-600' : 'text-muted-foreground';
  const victimColor = rivalry.victimSide === 'everlast' ? 'text-emerald-600' : rivalry.victimSide === 'ally' ? 'text-purple-600' : rivalry.victimSide === 'enemy' ? 'text-pink-600' : 'text-muted-foreground';

  return (
    <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-4 shadow-bubbly">
      <div className="flex items-center gap-3 mb-3">
        <Skull className="size-5 text-pink-400 shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 text-sm">
            <Link href={`/character/${encodeURIComponent(rivalry.killer)}`} className={cn('font-bold truncate hover:underline', killerColor)}>
              {rivalry.killer}
            </Link>
            <Swords className="size-3 text-pink-400" />
            <Link href={`/character/${encodeURIComponent(rivalry.victim)}`} className={cn('font-bold truncate hover:underline', victimColor)}>
              {rivalry.victim}
            </Link>
          </div>
          {rivalry.killerSide && rivalry.victimSide && (
            <div className="text-[10px] text-muted-foreground font-semibold mt-0.5">
              {SIDE_LABELS[rivalry.killerSide]} → {SIDE_LABELS[rivalry.victimSide]}
            </div>
          )}
        </div>
        <div className="shrink-0 text-right">
          <div className="text-2xl font-extrabold tabular-nums text-pink-500">{rivalry.killCount}</div>
          <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">kills</div>
        </div>
      </div>

      <div className="space-y-1 mb-2">
        {rivalry.events.slice(0, 5).map((ev, i) => (
          <Link
            key={`${ev.eventId}-${i}`}
            href={`/character/${encodeURIComponent(rivalry.victim)}`}
            className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            <span className="size-1.5 rounded-full bg-pink-400" />
            <span className="font-semibold">{new Date(ev.time).toLocaleDateString()}</span>
            <span>Lv {ev.level}</span>
          </Link>
        ))}
        {rivalry.events.length > 5 && (
          <div className="text-[10px] text-muted-foreground font-semibold">+{rivalry.events.length - 5} more</div>
        )}
      </div>

      {rivalry.revengeCount > 0 && (
        <div className="mt-3 rounded-xl border-2 border-emerald-200 bg-emerald-50/50 p-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-600 mb-1">
            <Heart className="size-3" fill="currentColor" />
            REVENGE: {rivalry.victim} killed {rivalry.killer} {rivalry.revengeCount}x
          </div>
          <div className="space-y-0.5">
            {rivalry.revengeEvents.slice(0, 3).map((ev, i) => (
              <div key={`rev-${ev.eventId}-${i}`} className="flex items-center gap-2 text-[10px] text-muted-foreground">
                <span className="size-1 rounded-full bg-emerald-400" />
                <span className="font-semibold">{new Date(ev.time).toLocaleDateString()}</span>
                <span>Lv {ev.level}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
