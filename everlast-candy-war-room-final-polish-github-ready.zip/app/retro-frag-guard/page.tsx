'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { CaptainPanel } from '@/components/captain-panel';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { getRetroObservedLastHits, getCharactersBySides, getRetroFragGuardEntries } from '@/lib/queries';
import { Character, RetroFragGuardEntry, RetroObservedLastHits } from '@/lib/types';
import { evaluateFragRisk, FRAG_RISK_CLASSES } from '@/lib/retro-frag-risk';
import { SIDE_LABELS, vocationAbbr } from '@/lib/tibia';
import { AlertTriangle, Loader2, ShieldAlert, Trash2 } from 'lucide-react';

export default function RetroFragGuardPage() {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [entries, setEntries] = useState<RetroFragGuardEntry[]>([]);
  const [observedEvents, setObservedEvents] = useState<RetroObservedLastHits[]>([]);
  const [observedLoaded, setObservedLoaded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [captain, setCaptain] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [selectedName, setSelectedName] = useState('');
  const [manual24h, setManual24h] = useState(0);
  const [manual7d, setManual7d] = useState(0);
  const [manual30d, setManual30d] = useState(0);
  const [notes, setNotes] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const [charsRes, entriesRes, eventsRes] = await Promise.allSettled([
      getCharactersBySides(['everlast', 'ally']),
      getRetroFragGuardEntries(),
      getRetroObservedLastHits(),
    ]);
    if (charsRes.status === 'fulfilled') setCharacters(charsRes.value);
    if (entriesRes.status === 'fulfilled') setEntries(entriesRes.value);
    if (eventsRes.status === 'fulfilled') { setObservedEvents(eventsRes.value); setObservedLoaded(true); }
    else setObservedLoaded(false);
    if ([charsRes, entriesRes, eventsRes].some((r) => r.status === 'rejected')) {
      setError('Część danych Frag Guard nie załadowała się. Wyniki nie są kompletne — sprawdź migrację Supabase i RPC.');
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const observedLastHits = useMemo(() => new Map(observedEvents.map(row => [row.character_name.toLowerCase(), {
    d1: row.last_hits_24h,
    d7: row.last_hits_7d,
    d30: row.last_hits_30d,
  }])), [observedEvents]);

  const allianceChars = useMemo(() => [...characters].sort((a,b)=> (b.level ?? 0) - (a.level ?? 0)), [characters]);
  const entryRows = useMemo(() => [...entries].sort((a,b) => evaluateFragRisk(b).priority - evaluateFragRisk(a).priority).map((entry) => ({
    entry,
    observed: observedLastHits.get(entry.character_name.toLowerCase()) ?? { d1: 0, d7: 0, d30: 0 },
    character: allianceChars.find((char) => char.name.toLowerCase() === entry.character_name.toLowerCase()) ?? null,
  })), [entries, observedLastHits, allianceChars]);

  const topObserved = useMemo(() => allianceChars.map((char) => ({
    character: char,
    observed: observedLastHits.get(char.name.toLowerCase()) ?? { d1: 0, d7: 0, d30: 0 },
  })).filter((row) => row.observed.d30 > 0).sort((a,b) => b.observed.d30 - a.observed.d30).slice(0, 15), [allianceChars, observedLastHits]);

  const urgent = useMemo(() => entryRows.filter(({entry}) => evaluateFragRisk(entry).priority >= 2), [entryRows]);

  const handlePrefill = (name: string) => {
    setSelectedName(name);
    const existing = entries.find((entry) => entry.character_name === name);
    setManual24h(existing?.unjust_24h ?? 0);
    setManual7d(existing?.unjust_7d ?? 0);
    setManual30d(existing?.unjust_30d ?? 0);
    setNotes(existing?.notes ?? '');
  };

  const handleSave = async () => {
    const char = allianceChars.find((entry) => entry.name === selectedName);
    if (!char) {
      setError('Wybierz postać z Everlast/Terrory.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const response = await fetch('/api/frag-guard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          action: 'upsert',
          characterName: char.name,
          side: char.side,
          unjust24h: manual24h,
          unjust7d: manual7d,
          unjust30d: manual30d,
          notes,
          updatedBy: 'Candy War Room',
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || 'Nie udało się zapisać wpisu Frag Guard');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Nie udało się zapisać wpisu Frag Guard');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    setSaving(true);
    try {
      const response = await fetch('/api/frag-guard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ action: 'delete', id }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || 'Nie udało się usunąć wpisu');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Nie udało się usunąć wpisu');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-black tracking-tight text-foreground flex items-center gap-2"><ShieldAlert className="size-8 text-rose-500" /> Retro Frag Guard</h1>
        <p className="text-sm text-muted-foreground mt-1">Manual unjust-frag tracker for Retro Open PvP, plus observed alliance last hits from the war log.</p>
      </div>

      <Alert className="border-rose-300 bg-rose-50 text-rose-900">
        <AlertTriangle className="size-4" />
        <AlertTitle>Important limitation</AlertTitle>
        <AlertDescription>
          TibiaData does NOT tell us whether a kill was justified/unjustified. This page separates <strong>manual unjust counts</strong> from <strong>observed PvP last hits</strong>. Use it as a guard rail, not a guaranteed skull detector.
        </AlertDescription>
      </Alert>

      <CaptainPanel onChange={setCaptain} />

      {error && (
        <Alert className="border-amber-300 bg-amber-50 text-amber-900">
          <AlertTriangle className="size-4" />
          <AlertTitle>Frag Guard notice</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {urgent.length > 0 && (
        <Alert className="border-rose-300 bg-rose-50 text-rose-900">
          <ShieldAlert className="size-4" />
          <AlertTitle>⚠️ Frag risk watch — {urgent.length} manual entries to review</AlertTitle>
          <AlertDescription>
            <div className="mt-2 flex flex-wrap gap-2">
              {urgent.slice(0, 8).map(({ entry }) => {
                const risk = evaluateFragRisk(entry);
                return <span key={entry.id} className={`rounded-full border px-2 py-1 text-xs font-bold ${FRAG_RISK_CLASSES[risk.level]}`} title={risk.detail}>{entry.character_name}: {risk.label}</span>;
              })}
            </div>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="rounded-3xl border-2 border-rose-200 bg-gradient-to-br from-rose-50 to-white shadow-bubbly">
          <CardHeader className="pb-2"><CardTitle className="text-sm">Retro thresholds</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div className="flex justify-between"><span>24h</span><span className="font-bold">Red 3 / Black 6</span></div>
            <div className="flex justify-between"><span>7 days</span><span className="font-bold">Red 5 / Black 10</span></div>
            <div className="flex justify-between"><span>30 days</span><span className="font-bold">Red 10 / Black 20</span></div>
          </CardContent>
        </Card>
        <Card className="rounded-3xl border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white shadow-bubbly">
          <CardHeader className="pb-2"><CardTitle className="text-sm">Tracked entries</CardTitle></CardHeader>
          <CardContent><div className="text-4xl font-black text-purple-600">{loading ? '—' : entries.length}</div><p className="text-xs text-muted-foreground mt-1">Manual frag guard rows for alliance players.</p></CardContent>
        </Card>
        <Card className="rounded-3xl border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-white shadow-bubbly-everlast">
          <CardHeader className="pb-2"><CardTitle className="text-sm">Observed alliance last hits</CardTitle></CardHeader>
          <CardContent><div className="text-4xl font-black text-emerald-600">{observedLoaded ? observedEvents.reduce((sum,row)=> sum + row.last_hits_24h, 0) : '—'}</div><p className="text-xs text-muted-foreground mt-1">Alliance war last hits in the last 24h (from all recorded canonical war events).</p></CardContent>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <div className="space-y-6">
          <Card className="rounded-3xl border-2 border-pink-200 bg-white/90 shadow-bubbly">
            <CardHeader>
              <CardTitle className="text-lg">Manual tracker</CardTitle>
              <CardDescription>Store the unjust-frag situation for a specific alliance character.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-xs font-bold text-muted-foreground">Character</label>
                <select value={selectedName} onChange={(e)=>handlePrefill(e.target.value)} className="mt-1 w-full rounded-2xl border-2 border-pink-200 bg-white px-3 py-2 text-sm">
                  <option value="">Select alliance character...</option>
                  {allianceChars.map((char) => (
                    <option key={char.id} value={char.name}>{char.name} • {SIDE_LABELS[char.side]} • lvl {char.level ?? '?'} {vocationAbbr(char.vocation)}</option>
                  ))}
                </select>
              </div>
              <div className="grid gap-3 md:grid-cols-3">
                <div>
                  <label className="text-xs font-bold text-muted-foreground">Unjust 24h</label>
                  <Input type="number" min={0} value={manual24h} onChange={(e)=>setManual24h(Number(e.target.value) || 0)} className="mt-1 rounded-2xl border-2 border-pink-200" />
                </div>
                <div>
                  <label className="text-xs font-bold text-muted-foreground">Unjust 7d</label>
                  <Input type="number" min={0} value={manual7d} onChange={(e)=>setManual7d(Number(e.target.value) || 0)} className="mt-1 rounded-2xl border-2 border-pink-200" />
                </div>
                <div>
                  <label className="text-xs font-bold text-muted-foreground">Unjust 30d</label>
                  <Input type="number" min={0} value={manual30d} onChange={(e)=>setManual30d(Number(e.target.value) || 0)} className="mt-1 rounded-2xl border-2 border-pink-200" />
                </div>
              </div>
              <div>
                <label className="text-xs font-bold text-muted-foreground">Notes</label>
                <Textarea value={notes} onChange={(e)=>setNotes(e.target.value)} className="mt-1 min-h-[120px] rounded-3xl border-2 border-pink-200" placeholder="e.g. 1 frag from random, 2 from defense, watch this char today" />
              </div>
              {!captain && <p className="text-xs text-amber-700">Tylko kapitan może edytować lub usuwać ręcznie raportowane unjusty.</p>}
              <Button type="button" onClick={handleSave} disabled={saving || !selectedName || !captain} className="rounded-2xl bg-pink-500 hover:bg-pink-600">
                {saving ? <Loader2 className="mr-2 size-4 animate-spin" /> : <ShieldAlert className="mr-2 size-4" />} Save frag guard entry
              </Button>
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-2 border-purple-200 bg-white/90 shadow-bubbly">
            <CardHeader>
              <CardTitle className="text-lg">Observed last-hit pressure</CardTitle>
              <CardDescription>Alliance PvP last hits from the war log. Useful as context, but not equal to unjusts.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 max-h-[520px] overflow-y-auto">
              {!observedLoaded ? <div className="text-sm text-amber-700">Observed PvP aggregates unavailable (requires Phase 11 RPC). No figures can be trusted yet.</div> : topObserved.length === 0 ? <div className="text-sm text-muted-foreground">No recorded alliance last hits in the last 30 days.</div> : topObserved.map(({ character, observed }) => (
                <div key={character.id} className="rounded-2xl border-2 border-purple-200 bg-purple-50/50 p-3">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="font-black text-foreground">{character.name}</div>
                      <div className="text-xs text-muted-foreground">{character.guild_name || SIDE_LABELS[character.side]} • {character.vocation || 'Unknown'} • lvl {character.level ?? '?'}</div>
                    </div>
                    <Badge className="rounded-full border-purple-300 bg-white text-purple-700">24h {observed.d1} • 7d {observed.d7} • 30d {observed.d30}</Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        <Card className="rounded-3xl border-2 border-rose-200 bg-white/90 shadow-bubbly-enemy">
          <CardHeader>
            <CardTitle className="text-lg">Guarded characters</CardTitle>
            <CardDescription>Manual skull-risk table for alliance members. Keep this updated before big pushes.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {entryRows.length === 0 ? (
              <div className="text-sm text-muted-foreground">No frag guard entries yet.</div>
            ) : entryRows.map(({ entry, observed, character }) => {
              const risk = evaluateFragRisk(entry);
              return (
                <div key={entry.id} className={`rounded-3xl border-2 p-4 ${risk.priority >= 4 ? 'border-rose-400 bg-rose-100/70' : risk.priority >= 2 ? 'border-amber-300 bg-amber-50/70' : 'border-rose-200 bg-rose-50/40'}`}>
                  <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-lg font-black text-foreground">{entry.character_name}</h3>
                        <Badge className={`rounded-full border ${FRAG_RISK_CLASSES[risk.level]}`}>{risk.label}</Badge>
                        <Badge className="rounded-full border-purple-300 bg-white text-purple-700">{SIDE_LABELS[entry.side]}</Badge>
                      </div>
                      <div className="mt-1 text-xs font-bold text-rose-700">{risk.detail} · Manual update: {new Date(entry.updated_at).toLocaleString('pl-PL')}</div>
                      <div className="text-xs text-muted-foreground mt-1">{character?.vocation || 'Unknown'} • lvl {character?.level ?? '?'} • observed last hits: {observedLoaded ? `24h ${observed.d1} / 7d ${observed.d7} / 30d ${observed.d30}` : 'unavailable'}</div>
                      {entry.notes && <div className="mt-2 text-sm text-foreground/80 whitespace-pre-wrap">{entry.notes}</div>}
                    </div>
                    <Button type="button" variant="outline" className="rounded-2xl" onClick={()=>handleDelete(entry.id)} disabled={saving || !captain}><Trash2 className="mr-2 size-4" /> Remove</Button>
                  </div>
                  <div className="mt-3 grid gap-3 md:grid-cols-3">
                    <div className="rounded-2xl border border-rose-200 bg-white/70 p-3 text-center"><div className="text-xs text-muted-foreground">Manual unjust 24h</div><div className="text-2xl font-black text-rose-600">{entry.unjust_24h}</div></div>
                    <div className="rounded-2xl border border-rose-200 bg-white/70 p-3 text-center"><div className="text-xs text-muted-foreground">Manual unjust 7d</div><div className="text-2xl font-black text-rose-600">{entry.unjust_7d}</div></div>
                    <div className="rounded-2xl border border-rose-200 bg-white/70 p-3 text-center"><div className="text-xs text-muted-foreground">Manual unjust 30d</div><div className="text-2xl font-black text-rose-600">{entry.unjust_30d}</div></div>
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
