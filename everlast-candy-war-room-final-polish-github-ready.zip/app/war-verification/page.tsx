'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  ShieldQuestion,
  Search,
  Download,
  Filter,
  Swords,
  Skull,
  Users,
  ChevronLeft,
  ChevronRight,
  X,
  Heart,
  Sparkles,
} from 'lucide-react';
import {
  getCanonicalWarEvents,
  getCanonicalWarEventsFiltered,
  computeCanonicalWarScore,
  type CanonicalWarScore,
} from '@/lib/queries';
import type { CanonicalWarEvent, Attribution, WarCategory, WarSide } from '@/lib/types';
import { LoadingState, StatCard } from '@/components/stat-card';
import { CharacterTag, SideBadge } from '@/components/character-tag';
import { formatDateTime, timeAgo } from '@/lib/format';

const PAGE_SIZE = 25;

const ATTRIBUTION_LABELS: Record<Attribution, string> = {
  confirmed: 'Confirmed',
  inferred: 'Inferred',
  unknown: 'Unknown',
  same_alliance: 'Friendly Fire',
  pve: 'PvE',
};

const ATTRIBUTION_STYLES: Record<Attribution, string> = {
  confirmed: 'bg-emerald-100 text-emerald-700 border-emerald-300',
  inferred: 'bg-amber-100 text-amber-700 border-amber-300',
  unknown: 'bg-gray-100 text-gray-600 border-gray-300',
  same_alliance: 'bg-blue-100 text-blue-700 border-blue-300',
  pve: 'bg-purple-100 text-purple-600 border-purple-300',
};

const CATEGORY_LABELS: Record<WarCategory, string> = {
  friendly_kills_enemy: 'Friendly kills enemy',
  enemy_kills_friendly: 'Enemy kills friendly',
  friendly_kills_enemy_inferred: 'Friendly kills enemy (inferred)',
  enemy_kills_friendly_inferred: 'Enemy kills friendly (inferred)',
  same_alliance: 'Same alliance',
  pve: 'PvE death',
  excluded: 'Excluded',
};

const WAR_CATEGORIES: WarCategory[] = [
  'friendly_kills_enemy',
  'friendly_kills_enemy_inferred',
  'enemy_kills_friendly',
  'enemy_kills_friendly_inferred',
  'same_alliance',
  'pve',
  'excluded',
];

const SIDE_FILTERS: { value: WarSide | 'all'; label: string }[] = [
  { value: 'all', label: 'All sides' },
  { value: 'everlast', label: 'Everlast' },
  { value: 'ally', label: 'Terrory' },
  { value: 'enemy', label: 'Mandatory Again' },
];

const TIME_FILTERS: { value: string; label: string }[] = [
  { value: 'all', label: 'All time' },
  { value: '24h', label: 'Last 24h' },
  { value: '7d', label: 'Last 7d' },
  { value: '30d', label: 'Last 30d' },
];

export default function WarVerificationPage() {
  const [loading, setLoading] = useState(true);
  const [loadWarning, setLoadWarning] = useState<string | null>(null);
  const [events, setEvents] = useState<CanonicalWarEvent[]>([]);
  const [score, setScore] = useState<CanonicalWarScore | null>(null);
  const [allEvents, setAllEvents] = useState<CanonicalWarEvent[]>([]);
  const [page, setPage] = useState(0);
  const [selectedEvent, setSelectedEvent] = useState<CanonicalWarEvent | null>(null);

  // Filters
  const [search, setSearch] = useState('');
  const [attributionFilter, setAttributionFilter] = useState<Attribution | 'all'>('all');
  const [categoryFilter, setCategoryFilter] = useState<WarCategory | 'all'>('all');
  const [sideFilter, setSideFilter] = useState<WarSide | 'all'>('all');
  const [pvpFilter, setPvpFilter] = useState<'all' | 'pvp' | 'pve'>('all');
  const [timeFilter, setTimeFilter] = useState('all');

  const loadEvents = useCallback(async () => {
    setLoading(true);
    setLoadWarning(null);
    try {
      const now = new Date();
      let since: string | undefined;
      if (timeFilter === '24h') since = new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString();
      else if (timeFilter === '7d') since = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();
      else if (timeFilter === '30d') since = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();

      const [filtered, full] = await Promise.all([
        getCanonicalWarEventsFiltered(
          {
            attribution: attributionFilter !== 'all' ? attributionFilter : undefined,
            warCategory: categoryFilter !== 'all' ? categoryFilter : undefined,
            side: sideFilter !== 'all' ? sideFilter : undefined,
            isPvp: pvpFilter === 'pvp' ? true : pvpFilter === 'pve' ? false : undefined,
            since,
            search: search.trim() || undefined,
          },
          2000,
        ),
        getCanonicalWarEvents(2000),
      ]);
      setEvents(filtered);
      setAllEvents(full);
      setScore(computeCanonicalWarScore(full));
      setPage(0);
    } catch (err) {
      console.error('War verification load error:', err);
      setLoadWarning('Nie udało się pobrać weryfikacji. Widoczne wyniki mogą być nieaktualne; nie traktuj pustego widoku jako braku zabójstw.');
    } finally {
      setLoading(false);
    }
  }, [attributionFilter, categoryFilter, sideFilter, pvpFilter, timeFilter, search]);

  useEffect(() => {
    loadEvents();
  }, [loadEvents]);

  const filteredScore = useMemo(() => {
    if (timeFilter === 'all' && attributionFilter === 'all' && categoryFilter === 'all' &&
        sideFilter === 'all' && pvpFilter === 'all' && !search.trim()) {
      return score;
    }
    return computeCanonicalWarScore(events);
  }, [events, score, timeFilter, attributionFilter, categoryFilter, sideFilter, pvpFilter, search]);

  const totalPages = Math.ceil(events.length / PAGE_SIZE);
  const pageEvents = events.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  const exportCsv = () => {
    const headers = [
      'Death Time', 'Victim', 'Victim Guild', 'Victim Side',
      'Killer', 'Killer Guild (stored)', 'Killer Side (stored)', 'Killer Guild (current)',
      'Level', 'Vocation', 'PvP', 'Attribution', 'War Category', 'Participants', 'Cause', 'Source',
    ];
    const rows = events.map((e) => [
      e.death_time,
      e.character_name,
      e.victim_guild ?? '',
      e.character_side,
      e.killer_name ?? '',
      e.stored_killer_guild ?? '',
      e.stored_killer_side ?? '',
      e.killer_current_guild ?? '',
      String(e.character_level),
      e.character_vocation ?? '',
      e.is_pvp ? 'Yes' : 'No',
      e.attribution,
      e.war_category,
      e.participated_players?.join('; ') ?? '',
      e.cause,
      e.source ?? '',
    ]);
    const csv = [headers, ...rows]
      .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `war-verification-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading && events.length === 0) return <LoadingState label="Verifying war events..." />;

  return (
    <div className="space-y-6 animate-float-up">
      {loadWarning && <div role="alert" className="rounded-xl border-2 border-amber-200 bg-amber-50 p-3 text-sm font-semibold text-amber-800">⚠️ {loadWarning}</div>}
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <ShieldCheck className="size-6 text-emerald-400" />
            War Kill Verification
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5 font-semibold">
            Every canonical war event with full evidence and attribution
          </p>
        </div>
        <button
          onClick={exportCsv}
          disabled={events.length === 0}
          className="flex items-center gap-2 rounded-xl border-2 border-pink-200 bg-white/60 px-4 py-2 text-xs font-bold text-pink-500 hover:bg-pink-50 transition-colors shadow-bubbly disabled:opacity-50"
        >
          <Download className="size-4" /> Export CSV ({events.length})
        </button>
      </div>

      {/* Score breakdown */}
      {filteredScore && (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Confirmed Friendly"
              value={filteredScore.confirmedFriendly}
              sublabel="Verified kills on enemy"
              icon={Swords}
              side="everlast"
            />
            <StatCard
              label="Inferred Friendly"
              value={filteredScore.inferredFriendly}
              sublabel="Current-guild attribution"
              icon={ShieldAlert}
              side="everlast"
            />
            <StatCard
              label="Confirmed Enemy"
              value={filteredScore.confirmedEnemy}
              sublabel="Verified kills on friendly"
              icon={Skull}
              side="enemy"
            />
            <StatCard
              label="Inferred Enemy"
              value={filteredScore.inferredEnemy}
              sublabel="Current-guild attribution"
              icon={ShieldAlert}
              side="enemy"
            />
          </div>

          <div className="rounded-2xl border-2 border-pink-200 bg-gradient-to-br from-white to-pink-50 p-5 shadow-bubbly">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <Heart className="size-5 text-emerald-500" fill="currentColor" />
                <div>
                  <div className="text-xs uppercase tracking-widest text-muted-foreground font-bold">
                    Verified War Score
                  </div>
                  <div className="text-3xl font-bold tabular-nums">
                    <span className="text-emerald-500">
                      {filteredScore.confirmedFriendly}
                      {filteredScore.inferredFriendly > 0 && (
                        <span className="text-amber-500 text-lg"> +{filteredScore.inferredFriendly}?</span>
                      )}
                    </span>
                    <span className="text-muted-foreground mx-2">:</span>
                    <span className="text-pink-500">{filteredScore.confirmedEnemy}</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3 text-xs font-semibold">
                <span className="rounded-lg border-2 border-blue-200 bg-blue-50 px-2.5 py-1 text-blue-600">
                  Friendly fire: {filteredScore.sameAlliance}
                </span>
                <span className="rounded-lg border-2 border-purple-200 bg-purple-50 px-2.5 py-1 text-purple-500">
                  PvE: {filteredScore.pve}
                </span>
                <span className="rounded-lg border-2 border-gray-200 bg-gray-50 px-2.5 py-1 text-gray-500">
                  Unknown: {filteredScore.unknown}
                </span>
                <span className="text-muted-foreground">
                  Total events: {filteredScore.totalEvents}
                </span>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Filters */}
      <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-4 shadow-bubbly space-y-3">
        <div className="flex items-center gap-2 text-xs font-bold text-muted-foreground">
          <Filter className="size-3.5" /> Filters
        </div>
        <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
          <div className="relative flex-1 min-w-[180px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search victim, killer, or cause..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-xl border-2 border-pink-200 bg-white/60 py-2 pl-9 pr-3 text-sm font-semibold text-foreground placeholder:text-muted-foreground/60 focus:border-pink-400 focus:outline-none"
            />
          </div>
          <select
            value={attributionFilter}
            onChange={(e) => setAttributionFilter(e.target.value as Attribution | 'all')}
            className="rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-sm font-semibold text-foreground focus:border-pink-400 focus:outline-none"
          >
            <option value="all">All attributions</option>
            <option value="confirmed">Confirmed</option>
            <option value="inferred">Inferred</option>
            <option value="unknown">Unknown</option>
            <option value="same_alliance">Friendly fire</option>
            <option value="pve">PvE</option>
          </select>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value as WarCategory | 'all')}
            className="rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-sm font-semibold text-foreground focus:border-pink-400 focus:outline-none"
          >
            <option value="all">All categories</option>
            {WAR_CATEGORIES.map((c) => (
              <option key={c} value={c}>{CATEGORY_LABELS[c]}</option>
            ))}
          </select>
          <select
            value={sideFilter}
            onChange={(e) => setSideFilter(e.target.value as WarSide | 'all')}
            className="rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-sm font-semibold text-foreground focus:border-pink-400 focus:outline-none"
          >
            {SIDE_FILTERS.map((s) => (
              <option key={s.value} value={s.value}>{s.label}</option>
            ))}
          </select>
          <select
            value={pvpFilter}
            onChange={(e) => setPvpFilter(e.target.value as 'all' | 'pvp' | 'pve')}
            className="rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-sm font-semibold text-foreground focus:border-pink-400 focus:outline-none"
          >
            <option value="all">PvP + PvE</option>
            <option value="pvp">PvP only</option>
            <option value="pve">PvE only</option>
          </select>
          <select
            value={timeFilter}
            onChange={(e) => setTimeFilter(e.target.value)}
            className="rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-sm font-semibold text-foreground focus:border-pink-400 focus:outline-none"
          >
            {TIME_FILTERS.map((t) => (
              <option key={t.value} value={t.value}>{t.label}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Events table */}
      <div className="rounded-2xl border-2 border-pink-200 bg-white/70 shadow-bubbly overflow-hidden">
        <div className="flex items-center justify-between border-b-2 border-pink-100 px-4 py-3">
          <span className="text-sm font-bold text-foreground">
            {events.length} events
            {events.length !== allEvents.length && (
              <span className="text-muted-foreground font-semibold"> of {allEvents.length}</span>
            )}
          </span>
          {totalPages > 1 && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage(Math.max(0, page - 1))}
                disabled={page === 0}
                className="rounded-lg border-2 border-pink-200 p-1.5 hover:bg-pink-50 disabled:opacity-40 transition-colors"
              >
                <ChevronLeft className="size-4 text-pink-400" />
              </button>
              <span className="text-xs font-bold tabular-nums text-muted-foreground">
                {page + 1} / {totalPages}
              </span>
              <button
                onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
                disabled={page >= totalPages - 1}
                className="rounded-lg border-2 border-pink-200 p-1.5 hover:bg-pink-50 disabled:opacity-40 transition-colors"
              >
                <ChevronRight className="size-4 text-pink-400" />
              </button>
            </div>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b-2 border-pink-100 bg-pink-50/30 text-left text-[10px] uppercase tracking-wider text-muted-foreground font-bold">
                <th className="px-3 py-2.5">Date / Time</th>
                <th className="px-3 py-2.5">Victim</th>
                <th className="px-3 py-2.5">Killer</th>
                <th className="px-3 py-2.5 hidden md:table-cell">Lv</th>
                <th className="px-3 py-2.5 hidden sm:table-cell">Parts</th>
                <th className="px-3 py-2.5">Attribution</th>
                <th className="px-3 py-2.5 hidden lg:table-cell">Category</th>
              </tr>
            </thead>
            <tbody>
              {pageEvents.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-3 py-8 text-center text-muted-foreground font-semibold">
                    No events match the current filters.
                  </td>
                </tr>
              )}
              {pageEvents.map((e) => (
                <tr
                  key={e.event_id}
                  onClick={() => setSelectedEvent(e)}
                  className="border-b border-pink-50 cursor-pointer hover:bg-pink-50/40 transition-colors"
                >
                  <td className="px-3 py-2.5 text-xs font-semibold text-muted-foreground whitespace-nowrap">
                    {formatDateTime(e.death_time)}
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <CharacterTag
                        name={e.character_name}
                        vocation={e.character_vocation}
                        level={e.character_level}
                        side={e.character_side}
                      />
                    </div>
                  </td>
                  <td className="px-3 py-2.5">
                    {e.killer_name ? (
                      <div className="flex items-center gap-2">
                        <CharacterTag
                          name={e.killer_name}
                          vocation={e.killer_vocation}
                          level={e.killer_level}
                          side={e.stored_killer_side ?? e.killer_current_side ?? undefined}
                        />
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground italic font-semibold">—</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 hidden md:table-cell text-xs font-bold tabular-nums text-foreground">
                    {e.character_level}
                  </td>
                  <td className="px-3 py-2.5 hidden sm:table-cell">
                    {e.participant_count > 0 ? (
                      <span className="inline-flex items-center gap-1 text-xs font-bold text-purple-500">
                        <Users className="size-3" /> {e.participant_count}
                      </span>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="px-3 py-2.5">
                    <span className={`inline-flex items-center rounded-lg border-2 px-2 py-0.5 text-[10px] font-bold ${ATTRIBUTION_STYLES[e.attribution]}`}>
                      {ATTRIBUTION_LABELS[e.attribution]}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 hidden lg:table-cell text-xs font-semibold text-muted-foreground">
                    {CATEGORY_LABELS[e.war_category]}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail panel */}
      {selectedEvent && (
        <EventDetailPanel
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
        />
      )}
    </div>
  );
}

function EventDetailPanel({ event, onClose }: { event: CanonicalWarEvent; onClose: () => void }) {
  const participants = event.participated_players ?? [];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-sm p-4" onClick={onClose}>
      <div
        className="relative w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-3xl border-2 border-pink-200 bg-white p-6 shadow-bubbly"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-xl p-1.5 hover:bg-pink-50 transition-colors"
        >
          <X className="size-5 text-pink-400" />
        </button>

        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="size-5 text-purple-400" />
          <h2 className="text-lg font-bold text-foreground">Death Evidence</h2>
        </div>

        <div className="space-y-4">
          {/* Time and level */}
          <div className="flex flex-wrap gap-3 text-xs font-semibold">
            <span className="rounded-lg border-2 border-pink-100 bg-pink-50/50 px-3 py-1.5 text-foreground">
              {formatDateTime(event.death_time)}
            </span>
            <span className="rounded-lg border-2 border-purple-100 bg-purple-50/50 px-3 py-1.5 text-foreground">
              Level {event.character_level}
            </span>
            <span className="rounded-lg border-2 border-pink-100 bg-pink-50/50 px-3 py-1.5 text-muted-foreground">
              {timeAgo(event.death_time)}
            </span>
            <span className={`rounded-lg border-2 px-3 py-1.5 ${ATTRIBUTION_STYLES[event.attribution]}`}>
              {ATTRIBUTION_LABELS[event.attribution]}
            </span>
          </div>

          {/* Victim */}
          <div className="rounded-xl border-2 border-pink-100 bg-pink-50/40 p-4">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold mb-2">Victim</div>
            <div className="flex items-center gap-3">
              <CharacterTag
                name={event.character_name}
                vocation={event.character_vocation}
                level={event.character_level}
                side={event.character_side}
              />
              <SideBadge side={event.character_side} />
            </div>
            <div className="mt-2 text-xs text-muted-foreground font-semibold">
              Guild (current): {event.victim_guild ?? 'Unknown'}
            </div>
          </div>

          {/* Killer */}
          {event.killer_name && (
            <div className="rounded-xl border-2 border-emerald-100 bg-emerald-50/40 p-4">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold mb-2">
                Killer (last-hit)
              </div>
              <div className="flex items-center gap-3">
                <CharacterTag
                  name={event.killer_name}
                  vocation={event.killer_vocation}
                  level={event.killer_level}
                  side={event.stored_killer_side ?? event.killer_current_side ?? undefined}
                />
                {event.stored_killer_side && <SideBadge side={event.stored_killer_side} />}
              </div>
              <div className="mt-2 space-y-0.5 text-xs text-muted-foreground font-semibold">
                <div>Stored guild: {event.stored_killer_guild ?? 'Unknown'}</div>
                <div>Current guild: {event.killer_current_guild ?? 'Unknown'}</div>
                <div>Current side: {event.killer_current_side ?? 'Unknown'}</div>
              </div>
            </div>
          )}

          {/* Participants */}
          {participants.length > 0 && (
            <div className="rounded-xl border-2 border-purple-100 bg-purple-50/40 p-4">
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold mb-2">
                All Participants ({participants.length})
              </div>
              <div className="flex flex-wrap gap-2">
                {participants.map((p, i) => (
                  <span
                    key={i}
                    className="rounded-lg border-2 border-purple-200 bg-white/60 px-2.5 py-1 text-xs font-semibold text-foreground"
                  >
                    {p}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Original cause text */}
          <div className="rounded-xl border-2 border-pink-200 bg-white/60 p-4">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold mb-2">
              Original TibiaData Death Text
            </div>
            <p className="text-sm font-semibold text-foreground leading-relaxed">
              {event.cause}
            </p>
          </div>

          {/* Attribution reasoning */}
          <div className="rounded-xl border-2 border-amber-100 bg-amber-50/40 p-4">
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-bold mb-2">
              Attribution Reasoning
            </div>
            <p className="text-xs font-semibold text-foreground leading-relaxed">
              {getAttributionReason(event)}
            </p>
          </div>

          {/* Metadata */}
          <div className="flex flex-wrap gap-3 text-[10px] font-bold text-muted-foreground">
            <span>Source: {event.source ?? 'unknown'}</span>
            <span>·</span>
            <span>PvP: {event.is_pvp ? 'Yes' : 'No'}</span>
            <span>·</span>
            <span>Player kill: {event.is_player_kill ? 'Yes' : 'No'}</span>
            <span>·</span>
            <span>War category: {CATEGORY_LABELS[event.war_category]}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function getAttributionReason(e: CanonicalWarEvent): string {
  if (e.attribution === 'pve') {
    return 'This death was caused by monsters or environmental hazards, not a player kill. Excluded from war score.';
  }
  if (e.attribution === 'same_alliance') {
    return 'Both victim and killer belong to the friendly alliance (Everlast + Terrory). This is friendly fire and excluded from the war score.';
  }
  if (e.attribution === 'confirmed') {
    const victimSide = e.character_side;
    const killerSide = e.stored_killer_side;
    return `The killer's guild side (${killerSide}) was recorded at death time and is on the opposing side from the victim (${victimSide}). This is a confirmed war kill with high confidence.`;
  }
  if (e.attribution === 'inferred') {
    return `The killer's guild side was not stored at death time, but the killer currently belongs to a war guild (${e.killer_current_guild}, side: ${e.killer_current_side}). Attribution is based on current guild membership, not death-time membership, so it is classified as inferred rather than confirmed.`;
  }
  return 'The killer could not be attributed to any war guild, either at death time or currently. This death is excluded from the war score as unverified.';
}
