'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Mail, Lock, ArrowLeft, Loader2, Candy, Heart, Sparkles } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { cn } from '@/lib/utils';

export default function LoginPage() {
  const router = useRouter();
  const { signIn, signUp, user, loading: authLoading } = useAuth();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!authLoading && user) router.push('/watchlist');
  }, [user, authLoading, router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    const { error } = mode === 'login' ? await signIn(email, password) : await signUp(email, password);
    setSubmitting(false);
    if (error) {
      setError(error);
    } else if (mode === 'signup') {
      setError('Account created. You can now sign in.');
      setMode('login');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background bg-candy-dots p-4">
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <Sparkles className="absolute top-[15%] left-[10%] size-8 text-purple-300/30 animate-sparkle" />
        <Heart className="absolute top-[25%] right-[12%] size-6 text-pink-300/30 animate-bounce-soft" fill="currentColor" />
        <Sparkles className="absolute bottom-[20%] left-[8%] size-6 text-pink-300/30 animate-sparkle" style={{ animationDelay: '0.7s' }} />
      </div>
      <div className="relative w-full max-w-md">
        <Link href="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors font-semibold">
          <ArrowLeft className="size-4" /> Back to Dashboard
        </Link>
        <div className="rounded-3xl border-2 border-pink-200 bg-white/80 backdrop-blur-xl p-8 shadow-bubbly">
          <div className="flex flex-col items-center mb-8">
            <div className="relative mb-4">
              <div className="flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br from-pink-300 to-purple-300 shadow-bubbly">
                <Candy className="size-7 text-white" />
              </div>
              <Sparkles className="absolute -top-1 -right-1 size-4 text-amber-300 animate-sparkle" />
            </div>
            <h1 className="text-xl font-bold text-foreground">
              {mode === 'login' ? 'Sign In' : 'Create Account'}
            </h1>
            <p className="text-sm text-muted-foreground mt-1 font-semibold">
              {mode === 'login' ? 'Access your watchlist and alerts' : 'Join the Candy War Room'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Email</label>
              <div className="relative mt-1.5">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-pink-300" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border-2 border-pink-200 bg-white/70 py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-200 font-semibold"
                  placeholder="commander@everlast.com"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Password</label>
              <div className="relative mt-1.5">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-pink-300" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-xl border-2 border-pink-200 bg-white/70 py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-200 font-semibold"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {error && (
              <div className={cn('rounded-xl border-2 px-3 py-2.5 text-xs font-semibold', error.includes('created') ? 'border-emerald-200 bg-emerald-50 text-emerald-600' : 'border-pink-200 bg-pink-50 text-pink-500')}>
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-pink-400 to-purple-400 px-4 py-2.5 text-sm font-bold text-white hover:from-pink-500 hover:to-purple-500 disabled:opacity-50 transition-all shadow-bubbly"
            >
              {submitting && <Loader2 className="size-4 animate-spin" />}
              {mode === 'login' ? 'Sign In' : 'Create Account'}
            </button>
          </form>

          <div className="mt-6 text-center text-xs text-muted-foreground font-semibold">
            {mode === 'login' ? (
              <>
                No account?{' '}
                <button onClick={() => { setMode('signup'); setError(null); }} className="text-pink-400 hover:underline font-bold">Create one</button>
              </>
            ) : (
              <>
                Already have an account?{' '}
                <button onClick={() => { setMode('login'); setError(null); }} className="text-pink-400 hover:underline font-bold">Sign in</button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
