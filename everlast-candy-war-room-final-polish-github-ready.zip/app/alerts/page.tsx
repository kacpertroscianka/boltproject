'use client';

import { useState, useMemo, useEffect } from 'react';
import Link from 'next/link';
import {
  Bell, BellRing, Volume2, VolumeX, BellOff, BellRing as BellOn,
  Play, TestTube, Search, Trash2, CheckCheck, Candy,
  Heart, Sparkles, Star, ShieldCheck, Clock, ExternalLink,
  Volume1, Settings2, Filter,
} from 'lucide-react';
import { unlockAudio } from '@/lib/alert-engine';
import { useGlobalAlerts } from '@/lib/global-alerts-context';
import {
  EVENT_TYPE_LABELS,
  SOUND_TYPES,
  SOUND_LABELS,
  type AlertEventType,
  type AlertGuild,
  type SoundType,
  type AlertHistoryEntry,
} from '@/lib/alert-types';
import { isFriendlySide, isEnemySide, SIDE_LABELS } from '@/lib/tibia';
import { cn } from '@/lib/utils';

const GUILD_OPTIONS: { key: AlertGuild; label: string; emoji: string; color: string }[] = [
  { key: 'everlast', label: 'Everlast', emoji: '💚', color: 'text-emerald-600' },
  { key: 'ally', label: 'Terrory', emoji: '💜', color: 'text-purple-600' },
  { key: 'enemy', label: 'Mandatory Again', emoji: '🩸', color: 'text-pink-600' },
];

const EVENT_GROUPS: { label: string; types: AlertEventType[] }[] = [
  { label: 'PvP Deaths', types: ['enemy_death_pvp', 'friendly_death'] },
  { label: 'PvE Deaths', types: ['enemy_death_pve'] },
  { label: 'Kills', types: ['friendly_kills_enemy', 'friendly_kills_enemy_participation', 'enemy_kills_friendly'] },
  { label: 'Level Changes', types: ['enemy_level_up', 'enemy_level_down', 'friendly_level_up', 'friendly_level_down'] },
];

const SIDE_BADGE: Record<string, string> = {
  everlast: 'bg-emerald-100 text-emerald-700 border-emerald-300',
  ally: 'bg-purple-100 text-purple-700 border-purple-300',
  enemy: 'bg-pink-100 text-pink-700 border-pink-300',
  neutral: 'bg-blue-100 text-blue-700 border-blue-300',
};

export default function AlertsPage() {
  const engine = useGlobalAlerts();
  const {
    settings,
    updateSettings,
    history,
    clearHistory,
    markAllRead,
    notificationPermission,
    requestNotificationPermission,
    testNotification,
    testSound,
    audioStatus,
    isPolling,
    lastPollAt,
    unreadCount,
  } = engine;

  const [searchQuery, setSearchQuery] = useState('');
  const [filterGuild, setFilterGuild] = useState<AlertGuild | 'all'>('all');
  const [filterType, setFilterType] = useState<AlertEventType | 'all'>('all');

  const filteredHistory = useMemo(() => {
    return history.filter((h) => {
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        if (!h.characterName.toLowerCase().includes(q) && !h.title.toLowerCase().includes(q) && !h.message.toLowerCase().includes(q)) {
          return false;
        }
      }
      if (filterGuild !== 'all') {
        if (filterGuild === 'everlast' && h.side !== 'everlast') return false;
        if (filterGuild === 'ally' && h.side !== 'ally') return false;
        if (filterGuild === 'enemy' && h.side !== 'enemy') return false;
      }
      if (filterType !== 'all' && h.type !== filterType) return false;
      return true;
    });
  }, [history, searchQuery, filterGuild, filterType]);

  const handleEnableSounds = () => {
    unlockAudio();
    updateSettings({ soundsEnabled: !settings.soundsEnabled });
  };

  const handleMute = () => {
    if (settings.mutedUntil && Date.now() < settings.mutedUntil) {
      updateSettings({ mutedUntil: null });
    } else {
      updateSettings({ mutedUntil: Date.now() + 60 * 60 * 1000 }); // 1 hour
    }
  };

  const isMuted = settings.mutedUntil != null && Date.now() < settings.mutedUntil;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="relative">
          <div className="flex size-12 items-center justify-center rounded-2xl bg-gradient-to-br from-pink-300 to-purple-300 shadow-bubbly">
            <BellRing className="size-6 text-white" />
          </div>
          <Sparkles className="absolute -top-1 -right-1 size-4 text-yellow-300 animate-sparkle" />
        </div>
        <div>
          <h1 className="text-xl font-bold tracking-tight text-foreground">
            🍬 Candy Alert Center
          </h1>
          <p className="text-xs text-muted-foreground">
            Powiadomienia o zdarzeniach na Sinistra — na żywo!
          </p>
        </div>
        {unreadCount > 0 && (
          <div className="ml-auto flex items-center gap-2">
            <span className="rounded-full bg-pink-500 text-white text-xs font-bold px-2.5 py-1 animate-pulse-soft">
              {unreadCount} new
            </span>
            <button
              onClick={markAllRead}
              className="flex items-center gap-1.5 rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-1.5 text-xs font-bold text-pink-400 hover:bg-pink-50 transition-colors"
            >
              <CheckCheck className="size-3.5" />
              Mark all read
            </button>
          </div>
        )}
      </div>

      {/* Status bar */}
      <div className="flex flex-wrap items-center gap-2 rounded-2xl border-2 border-pink-200 bg-white/60 p-3 shadow-bubbly">
        <div className="flex items-center gap-1.5 rounded-full border-2 border-pink-200 bg-white/60 px-3 py-1">
          <span className={cn('size-2 rounded-full', settings.enabled ? 'bg-emerald-400 animate-pulse-soft' : 'bg-gray-300')} />
          <span className="text-xs font-bold text-foreground">
            {settings.enabled ? 'Alerts ON' : 'Alerts OFF'}
          </span>
        </div>
        {isPolling && (
          <div className="flex items-center gap-1.5 rounded-full border-2 border-blue-200 bg-blue-50 px-3 py-1">
            <Clock className="size-3 text-blue-400 animate-spin" />
            <span className="text-xs font-bold text-blue-500">Polling...</span>
          </div>
        )}
        {lastPollAt && (
          <div className="flex items-center gap-1.5 rounded-full border-2 border-purple-200 bg-purple-50 px-3 py-1">
            <Clock className="size-3 text-purple-400" />
            <span className="text-xs font-bold text-purple-500">
              Last: {new Date(lastPollAt).toLocaleTimeString()}
            </span>
          </div>
        )}
        <div className={cn(
          'flex items-center gap-1.5 rounded-full border-2 px-3 py-1',
          audioStatus === 'enabled' ? 'border-emerald-200 bg-emerald-50' : audioStatus === 'blocked' ? 'border-amber-200 bg-amber-50' : 'border-gray-200 bg-gray-50',
        )}>
          {audioStatus === 'enabled' ? <Volume2 className="size-3 text-emerald-500" /> : <VolumeX className="size-3 text-amber-500" />}
          <span className={cn('text-xs font-bold', audioStatus === 'enabled' ? 'text-emerald-600' : audioStatus === 'blocked' ? 'text-amber-600' : 'text-muted-foreground')}>
            Sound: {audioStatus === 'enabled' ? 'ready' : audioStatus === 'blocked' ? 'blocked' : 'muted'}
          </span>
        </div>
        {isMuted && (
          <div className="flex items-center gap-1.5 rounded-full border-2 border-orange-200 bg-orange-50 px-3 py-1">
            <BellOff className="size-3 text-orange-400" />
            <span className="text-xs font-bold text-orange-500">Muted</span>
          </div>
        )}
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={handleMute}
            className={cn(
              'flex items-center gap-1.5 rounded-xl border-2 px-3 py-1.5 text-xs font-bold transition-colors',
              isMuted
                ? 'border-orange-300 bg-orange-50 text-orange-500'
                : 'border-pink-200 bg-white/60 text-pink-400 hover:bg-pink-50',
            )}
          >
            {isMuted ? <BellOff className="size-3.5" /> : <Bell className="size-3.5" />}
            {isMuted ? 'Unmute' : 'Mute 1h'}
          </button>
        </div>
      </div>

      {/* General settings */}
      <SettingsCard title="General Settings" emoji="⚙️" icon={Settings2}>
        <div className="space-y-4">
          {/* Enable alerts */}
          <ToggleRow
            label="Enable Candy Alerts"
            emoji="🔔"
            description="Turn on live event polling and notifications"
            checked={settings.enabled}
            onChange={(v) => updateSettings({ enabled: v })}
          />

          {/* Enable sounds */}
          <ToggleRow
            label="Enable Sounds"
            emoji="🔊"
            description="Play sounds for new alerts (click to unlock audio)"
            checked={settings.soundsEnabled}
            onChange={handleEnableSounds}
          />

          {/* Volume slider */}
          {settings.soundsEnabled && (
            <div className="rounded-2xl border-2 border-pink-200 bg-white/60 p-4">
              <div className="flex items-center gap-3 mb-2">
                <Volume1 className="size-4 text-purple-400" />
                <span className="text-sm font-bold text-foreground">Volume</span>
                <span className="ml-auto text-xs font-bold text-muted-foreground">
                  {Math.round(settings.volume * 100)}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={settings.volume}
                onChange={(e) => updateSettings({ volume: Number(e.target.value) })}
                className="w-full accent-pink-400"
              />
            </div>
          )}

          {/* Notification toggles */}
          <ToggleRow
            label="Show in-app alerts (foreground)"
            emoji="🔔"
            description="Show toast notifications while the tab is visible"
            checked={settings.notifyInForeground}
            onChange={(v) => updateSettings({ notifyInForeground: v })}
          />
          <ToggleRow
            label="Browser notifications (background)"
            emoji="🌙"
            description="Show OS notifications when the tab is hidden"
            checked={settings.notifyInBackground}
            onChange={(v) => updateSettings({ notifyInBackground: v })}
          />

          {/* Browser notification permission */}
          <div className="rounded-2xl border-2 border-pink-200 bg-white/60 p-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex-1">
                <div className="text-sm font-bold text-foreground">
                  Browser Notifications
                </div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  Permission: {notificationPermission}
                  {notificationPermission === 'unsupported' && ' — not supported in this browser'}
                </div>
              </div>
              {notificationPermission !== 'granted' && notificationPermission !== 'unsupported' && (
                <button
                  onClick={() => requestNotificationPermission()}
                  className="flex items-center gap-1.5 rounded-xl border-2 border-pink-300 bg-gradient-to-r from-pink-100 to-purple-100 px-3 py-2 text-xs font-bold text-pink-500 hover:scale-[1.02] transition-transform"
                >
                  <Bell className="size-3.5" />
                  Enable
                </button>
              )}
              {notificationPermission === 'granted' && (
                <button
                  onClick={testNotification}
                  className="flex items-center gap-1.5 rounded-xl border-2 border-emerald-300 bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-600 hover:bg-emerald-100 transition-colors"
                >
                  <TestTube className="size-3.5" />
                  Test
                </button>
              )}
            </div>
          </div>

          {/* Test sounds */}
          {settings.soundsEnabled && (
            <div className="rounded-2xl border-2 border-pink-200 bg-white/60 p-4">
              <div className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
                <Play className="size-4 text-purple-400" />
                Test Sounds
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {SOUND_TYPES.map((type) => (
                  <button
                    key={type}
                    onClick={() => testSound(type)}
                    className="flex items-center gap-1.5 rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-xs font-bold text-pink-400 hover:bg-pink-50 transition-colors"
                  >
                    <Volume2 className="size-3.5" />
                    {SOUND_LABELS[type]}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="rounded-2xl border-2 border-blue-200 bg-blue-50/60 p-3 text-xs font-semibold leading-relaxed text-blue-700">
            Alerts are limited by TibiaData source freshness and browser notification/audio rules. The browser checks for new events every 8 seconds while this page is open.
          </div>

          {/* Cooldown */}
          <div className="rounded-2xl border-2 border-pink-200 bg-white/60 p-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex-1">
                <div className="text-sm font-bold text-foreground">Notification Cooldown</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  Minimum seconds between alerts (0 = no cooldown)
                </div>
              </div>
              <input
                type="number"
                min={0}
                max={300}
                value={Math.round(settings.cooldownMs / 1000)}
                onChange={(e) => updateSettings({ cooldownMs: Number(e.target.value) * 1000 })}
                className="w-20 rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-sm font-bold text-center text-foreground"
              />
            </div>
          </div>
        </div>
      </SettingsCard>

      {/* Guild filters */}
      <SettingsCard title="Guild Filters" emoji="🏰" icon={ShieldCheck}>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {GUILD_OPTIONS.map((opt) => (
            <button
              key={opt.key}
              onClick={() => updateSettings({
                guildFilters: { ...settings.guildFilters, [opt.key]: !settings.guildFilters[opt.key] },
              })}
              className={cn(
                'flex items-center gap-2 rounded-2xl border-2 px-4 py-3 text-sm font-bold transition-all',
                settings.guildFilters[opt.key]
                  ? 'border-pink-300 bg-gradient-to-r from-pink-50 to-purple-50 text-foreground shadow-bubbly'
                  : 'border-pink-100 bg-white/40 text-muted-foreground',
              )}
            >
              <span className="text-lg">{opt.emoji}</span>
              <span className={cn(settings.guildFilters[opt.key] && opt.color)}>
                {opt.label}
              </span>
              {settings.guildFilters[opt.key] && <CheckCheck className="size-4 text-emerald-400 ml-auto" />}
            </button>
          ))}
        </div>
      </SettingsCard>

      {/* Event filters */}
      <SettingsCard title="Event Filters" emoji="🎯" icon={Filter}>
        <div className="space-y-4">
          {EVENT_GROUPS.map((group) => (
            <div key={group.label}>
              <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">
                {group.label}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {group.types.map((type) => {
                  const meta = EVENT_TYPE_LABELS[type];
                  const enabled = settings.eventFilters[type];
                  return (
                    <button
                      key={type}
                      onClick={() => updateSettings({
                        eventFilters: { ...settings.eventFilters, [type]: !enabled },
                      })}
                      className={cn(
                        'flex items-center gap-2 rounded-xl border-2 px-3 py-2 text-xs font-bold transition-all',
                        enabled
                          ? 'border-pink-300 bg-pink-50 text-foreground'
                          : 'border-pink-100 bg-white/40 text-muted-foreground',
                      )}
                    >
                      <span className="text-base">{meta.emoji}</span>
                      <span className="flex-1 text-left">{meta.label}</span>
                      {enabled && <CheckCheck className="size-3.5 text-emerald-400" />}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </SettingsCard>

      {/* Preferences */}
      <SettingsCard title="Preferences" emoji="🍭" icon={Candy}>
        <div className="space-y-4">
          {/* Scoring mode */}
          <div className="rounded-2xl border-2 border-pink-200 bg-white/60 p-4">
            <div className="text-sm font-bold text-foreground mb-2">
              Alert Scoring Mode
            </div>
            <div className="text-xs text-muted-foreground mb-3">
              Which scoring policy to use for kill alerts
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => updateSettings({ scoringMode: 'last-hit' })}
                className={cn(
                  'flex-1 rounded-xl border-2 px-3 py-2 text-xs font-bold transition-all',
                  settings.scoringMode === 'last-hit'
                    ? 'border-pink-300 bg-pink-50 text-pink-500'
                    : 'border-pink-100 bg-white/40 text-muted-foreground',
                )}
              >
                ⚔️ Last Hit
              </button>
              <button
                onClick={() => updateSettings({ scoringMode: 'participation' })}
                className={cn(
                  'flex-1 rounded-xl border-2 px-3 py-2 text-xs font-bold transition-all',
                  settings.scoringMode === 'participation'
                    ? 'border-purple-300 bg-purple-50 text-purple-500'
                    : 'border-purple-100 bg-white/40 text-muted-foreground',
                )}
              >
                🤝 Participation
              </button>
            </div>
          </div>

          {/* Min level */}
          <div className="rounded-2xl border-2 border-pink-200 bg-white/60 p-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex-1">
                <div className="text-sm font-bold text-foreground">Minimum Character Level</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  Only alert for characters at or above this level (0 = all)
                </div>
              </div>
              <input
                type="number"
                min={0}
                max={2000}
                value={settings.minLevel}
                onChange={(e) => updateSettings({ minLevel: Number(e.target.value) })}
                className="w-20 rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-sm font-bold text-center text-foreground"
              />
            </div>
          </div>
        </div>
      </SettingsCard>

      {/* Recent Alerts History */}
      <SettingsCard title="💌 Recent Alerts" emoji="💌" icon={Bell}>
        <div className="space-y-3">
          {/* Search and filters */}
          <div className="flex flex-wrap gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-pink-400" />
              <input
                type="text"
                placeholder="Search alerts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-xl border-2 border-pink-200 bg-white/60 py-2 pl-10 pr-4 text-xs font-semibold text-foreground placeholder:text-muted-foreground/60 focus:border-pink-400 focus:outline-none"
              />
            </div>
            <select
              value={filterGuild}
              onChange={(e) => setFilterGuild(e.target.value as AlertGuild | 'all')}
              className="rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-xs font-bold text-foreground"
            >
              <option value="all">All Guilds</option>
              <option value="everlast">Everlast</option>
              <option value="ally">Terrory</option>
              <option value="enemy">Mandatory Again</option>
            </select>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as AlertEventType | 'all')}
              className="rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-xs font-bold text-foreground"
            >
              <option value="all">All Events</option>
              {Object.entries(EVENT_TYPE_LABELS).map(([key, meta]) => (
                <option key={key} value={key}>{meta.emoji} {meta.label}</option>
              ))}
            </select>
            <button
              onClick={clearHistory}
              className="flex items-center gap-1.5 rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-xs font-bold text-pink-400 hover:bg-pink-50 transition-colors"
            >
              <Trash2 className="size-3.5" />
              Clear
            </button>
          </div>

          {/* History list */}
          {filteredHistory.length === 0 ? (
            <div className="text-center py-8 text-sm text-muted-foreground">
              <Bell className="size-8 mx-auto mb-2 opacity-30" />
              No alerts yet. Enable alerts to start receiving notifications!
            </div>
          ) : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto">
              {filteredHistory.map((entry) => (
                <HistoryRow key={entry.id} entry={entry} />
              ))}
            </div>
          )}
        </div>
      </SettingsCard>
    </div>
  );
}

function HistoryRow({ entry }: { entry: AlertHistoryEntry }) {
  const meta = EVENT_TYPE_LABELS[entry.type];
  const sideBadge = SIDE_BADGE[entry.side || 'neutral'] ?? SIDE_BADGE.neutral;

  return (
    <div className={cn(
      'rounded-xl border-2 p-3 transition-all',
      entry.read ? 'border-pink-100 bg-white/40' : 'border-pink-200 bg-white/70 shadow-bubbly',
    )}>
      <div className="flex items-start gap-2">
        <span className="text-lg shrink-0">{meta.emoji}</span>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold text-foreground">{entry.title}</span>
            {entry.side && (
              <span className={cn('rounded-full border px-1.5 py-0.5 text-[10px] font-bold', sideBadge)}>
                {SIDE_LABELS[entry.side]}
              </span>
            )}
            {!entry.read && (
              <span className="size-2 rounded-full bg-pink-400 animate-pulse-soft" />
            )}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            {entry.message}
          </div>
          <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="size-2.5" />
              {new Date(entry.eventTime).toLocaleString()}
            </span>
            <span>·</span>
            <span>Detected: {new Date(entry.detectedAt).toLocaleTimeString()}</span>
            {entry.detailHref && (
              <Link
                href={entry.detailHref}
                className="ml-auto flex items-center gap-1 text-pink-400 font-bold hover:underline"
              >
                Details <ExternalLink className="size-2.5" />
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function SettingsCard({
  title,
  emoji,
  icon: Icon,
  children,
}: {
  title: string;
  emoji: string;
  icon: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-3xl border-2 border-pink-200 bg-white/70 backdrop-blur-xl p-5 shadow-bubbly">
      <div className="flex items-center gap-2 mb-4">
        <Icon className="size-5 text-pink-400" />
        <h2 className="text-sm font-bold tracking-tight text-foreground">
          {emoji} {title}
        </h2>
      </div>
      {children}
    </div>
  );
}

function ToggleRow({
  label,
  emoji,
  description,
  checked,
  onChange,
}: {
  label: string;
  emoji: string;
  description: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-2xl border-2 border-pink-200 bg-white/60 p-4">
      <div className="flex-1">
        <div className="text-sm font-bold text-foreground">
          {emoji} {label}
        </div>
        <div className="text-xs text-muted-foreground mt-0.5">
          {description}
        </div>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={cn(
          'relative w-12 h-7 rounded-full border-2 transition-all shrink-0',
          checked ? 'border-pink-400 bg-gradient-to-r from-pink-300 to-purple-300' : 'border-pink-200 bg-white/60',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 size-5 rounded-full bg-white shadow-md transition-all',
            checked ? 'left-6' : 'left-0.5',
          )}
        />
      </button>
    </div>
  );
}
