import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { AuthProvider } from '@/lib/auth-context';
import { GlobalAlertsProvider } from '@/lib/global-alerts-context';
import { AppShell } from '@/components/app-shell';
import { WelcomeToast } from '@/components/welcome-toast';
import { AlertToastContainer } from '@/components/alert-toast';

const inter = Inter({
  subsets: ['latin', 'latin-ext'],
  weight: ['400', '500', '600', '700', '800'],
  variable: '--font-inter',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Everlast Candy War Room — Sinistra Guild War Intelligence',
  description:
    'Real-time war intelligence dashboard for Everlast Alliance vs Mandatory Again on the Tibia server Sinistra.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="font-sans antialiased">
        <AuthProvider>
          <GlobalAlertsProvider>
            <AppShell>{children}</AppShell>
            <WelcomeToast />
            <AlertToastContainer />
          </GlobalAlertsProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
