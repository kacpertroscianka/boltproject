'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import Link from 'next/link';
import {
  Swords, Play, Square, Plus, Trash2, Clock, Calendar,
  Heart, Skull, TrendingUp, TrendingDown, Sparkles, X,
  Users, Zap, AlertCircle,
} from 'lucide-react';
import { fetchData } from '@/lib/api-client';
import { getCanonicalWarEvents, getRecentDeaths, getRecentLevelUps, getRecentLevelDowns } from '@/lib/queries';
import type { CanonicalWarEvent, DeathEvent, LevelEvent, WarSide } from '@/lib/types';
import { isFriendlySide, isEnemySide } from '@/lib/tibia';
import {
  computeLastHitScore, computeParticipationScore, buildSideLookup,
} from '@/lib/scoring';
import { timeAgo } from '@/lib/format';
import { cn } from '@/lib/utils';

interface WarSession {
  id: string;
  name: string;
  notes: string | null;
  scoring_mode: 'last-hit' | 'participation';
  status: 'active' | 'ended';
  started_at: string;
  ended_at: string | null;
  created_at: string;
}

interface SessionStats {
  friendlyKills: number;
  enemyKills: number;
  friendlyDeaths: number;
  enemyDeaths: number;
  pvpEvents: number;
  pveEvents: number;
  unknownEvents: number;
  levelUps: number;
  levelDowns: number;
}

export default function WarSessionsPage() {
  const [sessions, setSessions] = useState<WarSession[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadWarning, setLoadWarning] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [newScoring, setNewScoring] = useState<'last-hit' | 'participation'>('last-hit');
  const [newNotes, setNewNotes] = useState('');
  const [selectedSession, setSelectedSession] = useState<WarSession | null>(null);
  const [sessionStats, setSessionStats] = useState<SessionStats | null>(null);
  const [statsLoading, setStatsLoading] = useState(false);
  const [events, setEvents] = useState<CanonicalWarEvent[]>([]);
  const [deaths, setDeaths] = useState<DeathEvent[]>([]);
  const [levelUps, setLevelUps] = useState<LevelEvent[]>([]);
  const [levelDowns, setLevelDowns] = useState<LevelEvent[]>([]);

  const loadSessions = useCallback(async () => {
    try {
      const data = await fetchData<WarSession[]>('war-sessions', { limit: 50 });
      setSessions(data || []);
      setLoadWarning(null);
    } catch (err) {
      console.error('Failed to load sessions:', err);
      setLoadWarning('Nie udało się załadować War Sessions. Lista może być nieaktualna.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadSessions(); }, [loadSessions]);

  // Load canonical events for session stats computation
  useEffect(() => {
    Promise.allSettled([
      getCanonicalWarEvents(2000),
      getRecentDeaths(2000),
      getRecentLevelUps(500),
      getRecentLevelDowns(500),
    ]).then(([ce, d, lu, ld]) => {
      if (ce.status === 'fulfilled') setEvents(ce.value);
      if (d.status === 'fulfilled') setDeaths(d.value);
      if (lu.status === 'fulfilled') setLevelUps(lu.value);
      if (ld.status === 'fulfilled') setLevelDowns(ld.value);
      if ([ce, d, lu, ld].some(r => r.status === 'rejected')) {
        setLoadWarning('Historia War Sessions jest niekompletna — część źródeł zgonów lub leveli nie odpowiada.');
        console.warn('War Sessions: part of the historical feed is unavailable; existing data is preserved.');
      }
    });
  }, []);

  const handleCreate = async () => {
    if (!newName.trim()) return;
    try {
      const res = await fetch('/api/war-sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ action: 'create', name: newName, scoringMode: newScoring, notes: newNotes }),
      });
      if (res.ok) {
        setShowCreate(false);
        setNewName('');
        setNewNotes('');
        loadSessions();
      }
    } catch (err) {
      console.error('Create failed:', err);
    }
  };

  const handleEnd = async (id: string) => {
    try {
      await fetch('/api/war-sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ action: 'end', id }),
      });
      loadSessions();
      if (selectedSession?.id === id) setSelectedSession(null);
    } catch (err) {
      console.error('End failed:', err);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this war session? This does NOT delete any canonical events.')) return;
    try {
      await fetch('/api/war-sessions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ action: 'delete', id }),
      });
      loadSessions();
      if (selectedSession?.id === id) setSelectedSession(null);
    } catch (err) {
      console.error('Delete failed:', err);
    }
  };

  // Compute session stats when selected
  useEffect(() => {
    if (!selectedSession) { setSessionStats(null); return; }
    setStatsLoading(true);
    const start = new Date(selectedSession.started_at).getTime();
    const end = selectedSession.ended_at ? new Date(selectedSession.ended_at).getTime() : Date.now();

    // Filter canonical war events by death_time within session window
    const sessionWarEvents = events.filter((e) => {
      const t = new Date(e.death_time).getTime();
      return t >= start && t <= end;
    });

    // Filter deaths by death_time
    const sessionDeaths = deaths.filter((d) => {
      const t = new Date(d.death_time).getTime();
      return t >= start && t <= end;
    });

    // Filter level events by observed_at
    const sessionLevelUps = levelUps.filter((ev) => {
      const t = new Date(ev.observed_at).getTime();
      return t >= start && t <= end;
    });
    const sessionLevelDowns = levelDowns.filter((ev) => {
      const t = new Date(ev.observed_at).getTime();
      return t >= start && t <= end;
    });

    const sideLookup = buildSideLookup(sessionWarEvents);
    const lastHit = computeLastHitScore(sessionWarEvents);
    const participation = computeParticipationScore(sessionWarEvents, sideLookup);
    const useParticipation = selectedSession.scoring_mode === 'participation';

    const stats: SessionStats = {
      friendlyKills: useParticipation ? participation.friendlyKills : lastHit.friendlyKills,
      enemyKills: useParticipation ? participation.enemyKills : lastHit.enemyKills,
      friendlyDeaths: sessionDeaths.filter((d) => isFriendlySide(d.character_side)).length,
      enemyDeaths: sessionDeaths.filter((d) => isEnemySide(d.character_side)).length,
      pvpEvents: sessionDeaths.filter((d) => d.is_pvp).length,
      pveEvents: sessionDeaths.filter((d) => !d.is_pvp).length,
      unknownEvents: useParticipation ? participation.unknownParticipation : lastHit.unknown,
      levelUps: sessionLevelUps.length,
      levelDowns: sessionLevelDowns.length,
    };
    setSessionStats(stats);
    setStatsLoading(false);
  }, [selectedSession, events, deaths, levelUps, levelDowns]);

  const activeSessions = sessions.filter((s) => s.status === 'active');
  const endedSessions = sessions.filter((s) => s.status === 'ended');

  return (
    <div className="space-y-6">
      {loadWarning && <div role="alert" className="rounded-xl border-2 border-amber-200 bg-amber-50 p-3 text-sm font-semibold text-amber-800">⚠️ {loadWarning}</div>}
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <Swords className="size-6 text-pink-400" />
            War Sessions
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Record individual war sessions and see scores within each time window
          </p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="flex items-center gap-1.5 rounded-xl border-2 border-pink-300 bg-gradient-to-r from-pink-100 to-purple-100 px-4 py-2 text-sm font-bold text-pink-500 hover:scale-105 transition-transform shadow-bubbly"
        >
          <Plus className="size-4" />
          New Session
        </button>
      </div>

      {/* Create modal */}
      {showCreate && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center bg-black/30 backdrop-blur-sm p-4" onClick={() => setShowCreate(false)}>
          <div className="w-full max-w-md rounded-3xl border-2 border-pink-200 bg-white p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-foreground">New War Session</h2>
              <button onClick={() => setShowCreate(false)} className="rounded-lg p-1 hover:bg-pink-100">
                <X className="size-4 text-pink-400" />
              </button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Session Name</label>
                <input
                  type="text"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Everlast Evening War"
                  className="mt-1 w-full rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-sm font-semibold text-foreground focus:border-pink-400 focus:outline-none"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Scoring Mode</label>
                <div className="mt-1 flex gap-2">
                  <button
                    onClick={() => setNewScoring('last-hit')}
                    className={cn('flex-1 rounded-xl border-2 px-3 py-2 text-sm font-bold', newScoring === 'last-hit' ? 'border-pink-300 bg-pink-50 text-pink-500' : 'border-pink-100 bg-white/40 text-muted-foreground')}
                  >⚔️ Last Hit</button>
                  <button
                    onClick={() => setNewScoring('participation')}
                    className={cn('flex-1 rounded-xl border-2 px-3 py-2 text-sm font-bold', newScoring === 'participation' ? 'border-purple-300 bg-purple-50 text-purple-500' : 'border-purple-100 bg-white/40 text-muted-foreground')}
                  >🤝 Participation</button>
                </div>
              </div>
              <div>
                <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Notes (optional)</label>
                <textarea
                  value={newNotes}
                  onChange={(e) => setNewNotes(e.target.value)}
                  placeholder="Session notes..."
                  rows={3}
                  className="mt-1 w-full rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-sm font-semibold text-foreground focus:border-pink-400 focus:outline-none"
                />
              </div>
              <button
                onClick={handleCreate}
                disabled={!newName.trim()}
                className="w-full rounded-xl border-2 border-pink-300 bg-gradient-to-r from-pink-200 to-purple-200 py-2.5 text-sm font-bold text-foreground hover:scale-[1.02] transition-transform disabled:opacity-50"
              >
                Start Session
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Active sessions */}
      {activeSessions.length > 0 && (
        <div>
          <h2 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-3">Active Sessions</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {activeSessions.map((s) => (
              <SessionCard
                key={s.id}
                session={s}
                onSelect={() => setSelectedSession(s)}
                onEnd={() => handleEnd(s.id)}
                onDelete={() => handleDelete(s.id)}
                selected={selectedSession?.id === s.id}
              />
            ))}
          </div>
        </div>
      )}

      {/* Session stats */}
      {selectedSession && sessionStats && (
        <div className="rounded-3xl border-2 border-pink-200 bg-white/70 p-6 shadow-bubbly">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-foreground">{selectedSession.name}</h2>
            <Link href={`/war-replay?id=${selectedSession.id}`} className="flex items-center gap-1.5 rounded-xl border-2 border-pink-300 bg-pink-50 px-3 py-1.5 text-xs font-bold text-pink-500 hover:bg-pink-100 transition-colors">
              <Play className="size-3.5" /> Replay
            </Link>
          </div>
          {statsLoading ? (
            <div className="text-sm text-muted-foreground">Calculating...</div>
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
                <StatBox label="Friendly Kills" value={sessionStats.friendlyKills} icon={Swords} color="emerald" />
                <StatBox label="Enemy Kills" value={sessionStats.enemyKills} icon={Skull} color="pink" />
                <StatBox label="Friendly Deaths" value={sessionStats.friendlyDeaths} icon={Heart} color="blue" />
                <StatBox label="Enemy Deaths" value={sessionStats.enemyDeaths} icon={Skull} color="purple" />
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                <MiniStat label="PvP" value={sessionStats.pvpEvents} />
                <MiniStat label="PvE" value={sessionStats.pveEvents} />
                <MiniStat label="Unknown" value={sessionStats.unknownEvents} />
                <MiniStat label="Level Ups" value={sessionStats.levelUps} />
                <MiniStat label="Level Downs" value={sessionStats.levelDowns} />
              </div>
              <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground font-semibold">
                <Clock className="size-3" />
                {new Date(selectedSession.started_at).toLocaleString()} — {selectedSession.ended_at ? new Date(selectedSession.ended_at).toLocaleString() : 'ongoing'}
              </div>
              <div className="mt-2 text-[10px] text-muted-foreground">
                Scores computed from canonical events with death_time within the session window. Event time ≠ detection time.
              </div>
            </>
          )}
        </div>
      )}

      {/* Ended sessions */}
      {endedSessions.length > 0 && (
        <div>
          <h2 className="text-sm font-bold text-muted-foreground uppercase tracking-wider mb-3">Ended Sessions</h2>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {endedSessions.map((s) => (
              <SessionCard
                key={s.id}
                session={s}
                onSelect={() => setSelectedSession(s)}
                onEnd={() => {}}
                onDelete={() => handleDelete(s.id)}
                selected={selectedSession?.id === s.id}
              />
            ))}
          </div>
        </div>
      )}

      {!loading && sessions.length === 0 && (
        <div className="text-center py-16">
          <Swords className="size-12 mx-auto text-pink-200 mb-3" />
          <div className="text-sm font-bold text-muted-foreground">No war sessions yet.</div>
          <div className="text-xs text-muted-foreground mt-1">Click &quot;New Session&quot; to record your first war.</div>
        </div>
      )}
    </div>
  );
}

function SessionCard({ session, onSelect, onEnd, onDelete, selected }: {
  session: WarSession;
  onSelect: () => void;
  onEnd: () => void;
  onDelete: () => void;
  selected: boolean;
}) {
  const isActive = session.status === 'active';
  return (
    <div
      onClick={onSelect}
      className={cn(
        'cursor-pointer rounded-2xl border-2 p-4 transition-all',
        selected ? 'border-pink-400 bg-pink-50 shadow-bubbly scale-[1.02]' : isActive ? 'border-emerald-200 bg-emerald-50/40 hover:bg-emerald-50' : 'border-pink-100 bg-white/60 hover:bg-white/90',
      )}
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-bold text-foreground truncate">{session.name}</span>
        {isActive && <span className="size-2 rounded-full bg-emerald-400 animate-pulse-soft shrink-0" />}
      </div>
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-semibold mb-2">
        <Calendar className="size-3" />
        {new Date(session.started_at).toLocaleDateString()}
      </div>
      {session.notes && <div className="text-xs text-muted-foreground truncate mb-2">{session.notes}</div>}
      <div className="flex items-center gap-2">
        <span className={cn('rounded-full border px-2 py-0.5 text-[10px] font-bold', isActive ? 'border-emerald-300 bg-emerald-100 text-emerald-600' : 'border-gray-200 bg-gray-50 text-gray-500')}>
          {isActive ? 'Active' : 'Ended'}
        </span>
        <span className="rounded-full border border-pink-200 bg-pink-50 px-2 py-0.5 text-[10px] font-bold text-pink-500">
          {session.scoring_mode === 'participation' ? '🤝 Participation' : '⚔️ Last Hit'}
        </span>
      </div>
      <div className="mt-3 flex gap-1.5" onClick={(e) => e.stopPropagation()}>
        {isActive && (
          <button onClick={onEnd} className="flex items-center gap-1 rounded-lg border border-emerald-200 bg-emerald-50 px-2 py-1 text-[10px] font-bold text-emerald-600 hover:bg-emerald-100 transition-colors">
            <Square className="size-2.5" /> End
          </button>
        )}
        <button onClick={onDelete} className="flex items-center gap-1 rounded-lg border border-pink-200 bg-pink-50 px-2 py-1 text-[10px] font-bold text-pink-400 hover:bg-pink-100 transition-colors">
          <Trash2 className="size-2.5" /> Delete
        </button>
      </div>
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color }: { label: string; value: number; icon: typeof Swords; color: string }) {
  const colorMap: Record<string, string> = {
    emerald: 'border-emerald-200 bg-emerald-50/60 text-emerald-600',
    pink: 'border-pink-200 bg-pink-50/60 text-pink-600',
    blue: 'border-blue-200 bg-blue-50/60 text-blue-600',
    purple: 'border-purple-200 bg-purple-50/60 text-purple-600',
  };
  return (
    <div className={cn('rounded-2xl border-2 p-3', colorMap[color])}>
      <Icon className="size-4 mb-1" />
      <div className="text-2xl font-extrabold tabular-nums">{value}</div>
      <div className="text-[10px] font-bold uppercase tracking-wider opacity-70">{label}</div>
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl border border-pink-100 bg-white/60 p-2 text-center">
      <div className="text-sm font-extrabold tabular-nums text-foreground">{value}</div>
      <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}
