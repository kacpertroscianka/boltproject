'use client';

import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import Link from 'next/link';
import {
  Play, Pause, SkipForward, Clock, Swords, Skull, Heart,
  TrendingUp, TrendingDown, Sparkles, ChevronRight, X,
  Volume2, Flag,
} from 'lucide-react';
import { fetchData } from '@/lib/api-client';
import { getCanonicalWarEvents, getRecentLevelUps, getRecentLevelDowns } from '@/lib/queries';
import type { CanonicalWarEvent, LevelEvent, WarSide } from '@/lib/types';
import { isFriendlySide, isEnemySide, SIDE_LABELS } from '@/lib/tibia';
import { computeLastHitScore, computeParticipationScore, buildSideLookup } from '@/lib/scoring';
import { cn } from '@/lib/utils';
import { useSearchParams } from 'next/navigation';

interface WarSession {
  id: string;
  name: string;
  notes: string | null;
  scoring_mode: 'last-hit' | 'participation';
  status: 'active' | 'ended';
  started_at: string;
  ended_at: string | null;
}

interface TimelineEvent {
  id: string;
  type: 'death' | 'level-up' | 'level-down';
  timestamp: number;
  characterName: string;
  side: WarSide | null;
  level: number;
  killerName: string | null;
  isPvp: boolean;
  warCategory: string | null;
  attribution: string | null;
  detailHref: string;
}

interface ReplayState {
  playing: boolean;
  currentIndex: number;
  speed: number;
}

export default function WarReplayPage() {
  const searchParams = useSearchParams();
  const sessionId = searchParams.get('id');
  const [sessions, setSessions] = useState<WarSession[]>([]);
  const [selectedSession, setSelectedSession] = useState<WarSession | null>(null);
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [replay, setReplay] = useState<ReplayState>({ playing: false, currentIndex: 0, speed: 1 });
  const [loading, setLoading] = useState(true);
  const [loadWarning, setLoadWarning] = useState<string | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    fetchData<WarSession[]>('war-sessions', { limit: 50 }).then((data) => {
      setSessions(data || []);
      if (sessionId) {
        const found = (data || []).find((s) => s.id === sessionId);
        if (found) setSelectedSession(found);
      }
      setLoading(false);
    }).catch(() => { setLoadWarning('Nie udało się pobrać War Sessions. Sprawdź logowanie i połączenie Supabase.'); setLoading(false); });
  }, [sessionId]);

  // Build timeline when session selected
  useEffect(() => {
    if (!selectedSession) { setTimeline([]); return; }
    const start = new Date(selectedSession.started_at).getTime();
    const end = selectedSession.ended_at ? new Date(selectedSession.ended_at).getTime() : Date.now();

    Promise.allSettled([
      getCanonicalWarEvents(2000),
      getRecentLevelUps(500),
      getRecentLevelDowns(500),
    ]).then(([war, up, down]) => {
      const failed = [war, up, down].filter(r => r.status === 'rejected').length;
      setLoadWarning(failed ? `${failed} źródeł replay jest niedostępnych. Oś czasu może być niekompletna.` : null);
      const warEvents = war.status === 'fulfilled' ? war.value : [];
      const ups = up.status === 'fulfilled' ? up.value : [];
      const downs = down.status === 'fulfilled' ? down.value : [];
      const events: TimelineEvent[] = [];

      for (const e of warEvents) {
        const t = new Date(e.death_time).getTime();
        if (t < start || t > end) continue;
        events.push({
          id: e.event_id,
          type: 'death',
          timestamp: t,
          characterName: e.character_name,
          side: e.character_side,
          level: e.character_level,
          killerName: e.killer_name,
          isPvp: e.is_pvp,
          warCategory: e.war_category,
          attribution: e.attribution,
          detailHref: `/character/${encodeURIComponent(e.character_name)}`,
        });
      }

      for (const ev of ups) {
        const t = new Date(ev.observed_at).getTime();
        if (t < start || t > end) continue;
        const side = (ev as unknown as { character_side?: WarSide }).character_side ?? null;
        events.push({
          id: ev.id,
          type: 'level-up',
          timestamp: t,
          characterName: ev.character_name,
          side,
          level: ev.new_level ?? 0,
          killerName: null,
          isPvp: false,
          warCategory: null,
          attribution: null,
          detailHref: `/character/${encodeURIComponent(ev.character_name)}`,
        });
      }

      for (const ev of downs) {
        const t = new Date(ev.observed_at).getTime();
        if (t < start || t > end) continue;
        const side = (ev as unknown as { character_side?: WarSide }).character_side ?? null;
        events.push({
          id: ev.id,
          type: 'level-down',
          timestamp: t,
          characterName: ev.character_name,
          side,
          level: ev.new_level ?? 0,
          killerName: null,
          isPvp: false,
          warCategory: null,
          attribution: null,
          detailHref: `/character/${encodeURIComponent(ev.character_name)}`,
        });
      }

      events.sort((a, b) => a.timestamp - b.timestamp);
      setTimeline(events);
      setReplay({ playing: false, currentIndex: 0, speed: 1 });
    }).catch(() => {});
  }, [selectedSession]);

  // Replay playback
  useEffect(() => {
    if (!replay.playing) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      return;
    }
    if (replay.currentIndex >= timeline.length) {
      setReplay((r) => ({ ...r, playing: false }));
      return;
    }
    const stepMs = 2000 / replay.speed;
    intervalRef.current = setInterval(() => {
      setReplay((r) => {
        if (r.currentIndex >= timeline.length - 1) {
          return { ...r, playing: false };
        }
        return { ...r, currentIndex: r.currentIndex + 1 };
      });
    }, stepMs);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [replay.playing, replay.speed, replay.currentIndex, timeline.length]);

  const visibleEvents = useMemo(
    () => timeline.slice(0, replay.currentIndex + 1),
    [timeline, replay.currentIndex],
  );

  const scoreEvolution = useMemo(() => {
    let friendly = 0;
    let enemy = 0;
    const points: { index: number; friendly: number; enemy: number }[] = [{ index: 0, friendly: 0, enemy: 0 }];
    visibleEvents.forEach((ev, i) => {
      if (ev.type === 'death' && ev.isPvp) {
        if (ev.warCategory?.startsWith('friendly_kills')) friendly++;
        if (ev.warCategory?.startsWith('enemy_kills')) enemy++;
      }
      points.push({ index: i + 1, friendly, enemy });
    });
    return points;
  }, [visibleEvents]);

  if (loading) {
    return <div className="flex items-center justify-center min-h-[40vh]"><Clock className="size-8 text-pink-400 animate-spin" /></div>;
  }

  return (
    <div className="space-y-6">
      {loadWarning && <div role="alert" className="rounded-xl border-2 border-amber-200 bg-amber-50 p-3 text-sm font-semibold text-amber-800">⚠️ {loadWarning}</div>}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <Clock className="size-6 text-pink-400" />
          Candy War Replay
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          Replay recorded war sessions event by event
        </p>
      </div>

      {/* Session selector */}
      {!selectedSession && (
        <div className="space-y-3">
          {sessions.length === 0 ? (
            <div className="text-center py-16">
              <Clock className="size-12 mx-auto text-pink-200 mb-3" />
              <div className="text-sm font-bold text-muted-foreground">No war sessions to replay.</div>
              <Link href="/war-sessions" className="text-xs text-pink-400 hover:underline font-bold mt-2 inline-block">
                Create a session first →
              </Link>
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {sessions.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSelectedSession(s)}
                  className="text-left rounded-2xl border-2 border-pink-200 bg-white/70 p-4 hover:bg-pink-50 transition-colors shadow-bubbly"
                >
                  <div className="text-sm font-bold text-foreground">{s.name}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {new Date(s.started_at).toLocaleDateString()} — {s.ended_at ? new Date(s.ended_at).toLocaleDateString() : 'ongoing'}
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <span className={cn('rounded-full border px-2 py-0.5 text-[10px] font-bold', s.status === 'active' ? 'border-emerald-300 bg-emerald-100 text-emerald-600' : 'border-gray-200 bg-gray-50 text-gray-500')}>
                      {s.status}
                    </span>
                    <span className="text-[10px] font-bold text-pink-400">{s.scoring_mode === 'participation' ? '🤝' : '⚔️'} {s.scoring_mode}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Replay view */}
      {selectedSession && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-foreground">{selectedSession.name}</h2>
              <div className="text-xs text-muted-foreground">
                {timeline.length} events · {new Date(selectedSession.started_at).toLocaleString()} → {selectedSession.ended_at ? new Date(selectedSession.ended_at).toLocaleString() : 'ongoing'}
              </div>
            </div>
            <button
              onClick={() => { setSelectedSession(null); setReplay({ playing: false, currentIndex: 0, speed: 1 }); }}
              className="flex items-center gap-1.5 rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-1.5 text-xs font-bold text-pink-400 hover:bg-pink-50 transition-colors"
            >
              <X className="size-3.5" /> Change Session
            </button>
          </div>

          {/* Score display */}
          <div className="rounded-3xl border-2 border-pink-200 bg-gradient-to-br from-pink-50/80 to-purple-50/40 p-6 shadow-bubbly">
            <div className="flex items-center justify-center gap-6 sm:gap-12">
              <div className="text-center">
                <div className="text-5xl font-extrabold tabular-nums text-emerald-500">
                  {scoreEvolution[scoreEvolution.length - 1]?.friendly ?? 0}
                </div>
                <div className="text-xs font-bold text-emerald-600 mt-1">Everlast + Terrory</div>
              </div>
              <div className="text-2xl font-light text-muted-300">:</div>
              <div className="text-center">
                <div className="text-5xl font-extrabold tabular-nums text-pink-500">
                  {scoreEvolution[scoreEvolution.length - 1]?.enemy ?? 0}
                </div>
                <div className="text-xs font-bold text-pink-600 mt-1">Mandatory Again</div>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-3 rounded-2xl border-2 border-pink-200 bg-white/70 p-4">
            <button
              onClick={() => setReplay((r) => ({ ...r, playing: !r.playing }))}
              disabled={replay.currentIndex >= timeline.length - 1 && !replay.playing}
              className="flex items-center gap-2 rounded-xl border-2 border-pink-300 bg-gradient-to-r from-pink-100 to-purple-100 px-4 py-2 text-sm font-bold text-pink-500 hover:scale-105 transition-transform disabled:opacity-50"
            >
              {replay.playing ? <Pause className="size-4" /> : <Play className="size-4" />}
              {replay.playing ? 'Pause' : 'Play'}
            </button>
            <button
              onClick={() => setReplay((r) => ({ ...r, currentIndex: Math.min(r.currentIndex + 1, timeline.length - 1), playing: false }))}
              disabled={replay.currentIndex >= timeline.length - 1}
              className="flex items-center gap-2 rounded-xl border-2 border-pink-200 bg-white/60 px-3 py-2 text-sm font-bold text-pink-400 hover:bg-pink-50 transition-colors disabled:opacity-50"
            >
              <SkipForward className="size-4" /> Step
            </button>
            <div className="flex items-center gap-1">
              {[1, 2, 5].map((sp) => (
                <button
                  key={sp}
                  onClick={() => setReplay((r) => ({ ...r, speed: sp }))}
                  className={cn('rounded-lg border-2 px-2.5 py-1 text-xs font-bold transition-colors', replay.speed === sp ? 'border-pink-300 bg-pink-50 text-pink-500' : 'border-pink-100 bg-white/40 text-muted-foreground')}
                >
                  {sp}x
                </button>
              ))}
            </div>
            <button
              onClick={() => setReplay({ playing: false, currentIndex: 0, speed: replay.speed })}
              className="flex items-center gap-1 rounded-lg border-2 border-pink-100 bg-white/40 px-2.5 py-1 text-xs font-bold text-muted-foreground hover:bg-pink-50 transition-colors"
            >
              <Flag className="size-3" /> Reset
            </button>
          </div>

          {/* Progress bar */}
          <div className="h-2 rounded-full bg-pink-100 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-r from-pink-400 to-purple-400 transition-all"
              style={{ width: `${timeline.length > 0 ? ((replay.currentIndex + 1) / timeline.length) * 100 : 0}%` }}
            />
          </div>

          {/* Timeline */}
          <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-4 max-h-[500px] overflow-y-auto">
            <div className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">
              Event Timeline ({replay.currentIndex + 1} / {timeline.length})
            </div>
            <div className="space-y-2">
              {visibleEvents.map((ev, i) => (
                <TimelineCard key={`${ev.id}-${i}`} event={ev} isLatest={i === replay.currentIndex} />
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TimelineCard({ event, isLatest }: { event: TimelineEvent; isLatest: boolean }) {
  const sideColor = event.side === 'everlast' ? 'text-emerald-600' : event.side === 'ally' ? 'text-purple-600' : event.side === 'enemy' ? 'text-pink-600' : 'text-muted-foreground';
  const borderColor = event.side === 'everlast' ? 'border-emerald-200' : event.side === 'ally' ? 'border-purple-200' : event.side === 'enemy' ? 'border-pink-200' : 'border-gray-200';
  const bgColor = event.side === 'everlast' ? 'bg-emerald-50/50' : event.side === 'ally' ? 'bg-purple-50/50' : event.side === 'enemy' ? 'bg-pink-50/50' : 'bg-white/40';

  return (
    <Link
      href={event.detailHref}
      className={cn('block rounded-xl border-2 p-3 transition-all', borderColor, bgColor, isLatest && 'ring-2 ring-pink-400 animate-float-up')}
    >
      <div className="flex items-center gap-3">
        <div className="shrink-0">
          {event.type === 'death' && (event.isPvp ? <Swords className="size-4 text-pink-400" /> : <Skull className="size-4 text-muted-foreground" />)}
          {event.type === 'level-up' && <TrendingUp className="size-4 text-emerald-500" />}
          {event.type === 'level-down' && <TrendingDown className="size-4 text-pink-400" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className={cn('text-sm font-bold truncate', sideColor)}>{event.characterName}</span>
            {event.side && <span className="text-[10px] font-bold text-muted-foreground">{SIDE_LABELS[event.side]}</span>}
            <span className="text-xs font-bold tabular-nums text-muted-foreground">Lv {event.level}</span>
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            {event.type === 'death' && (event.isPvp ? `Killed by ${event.killerName || 'unknown'}` : 'PvE death')}
            {event.type === 'level-up' && 'Level up'}
            {event.type === 'level-down' && 'Level down'}
            {event.attribution && event.attribution !== 'confirmed' && (
              <span className="ml-2 text-[10px] font-bold text-amber-500">({event.attribution})</span>
            )}
          </div>
        </div>
        <div className="shrink-0 text-right">
          <div className="text-[10px] text-muted-foreground font-semibold">
            {new Date(event.timestamp).toLocaleTimeString()}
          </div>
        </div>
      </div>
    </Link>
  );
}
