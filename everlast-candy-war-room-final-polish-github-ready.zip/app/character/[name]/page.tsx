'use client';

import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft,
  Swords,
  Skull,
  TrendingUp,
  TrendingDown,
  Clock,
  Shield,
  Activity,
  User,
  Heart,
  Zap,
  Crown,
  Trophy,
  ExternalLink,
  Link2,
  Check,
  Eye,
  EyeOff,
  Target,
  Flame,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import {
  getCharacterByName,
  getDeathsForCharacter,
  getLevelEventsForCharacter,
  getCharactersBySide,
  getCombatEventsForCharacter,
} from '@/lib/queries';
import type { Character, DeathEvent, LevelEvent, CanonicalWarEvent, WarSide } from '@/lib/types';
import { LoadingState, MockDataBadge, StatCard } from '@/components/stat-card';
import { OnlineIndicator, SideBadge } from '@/components/character-tag';
import { timeAgo, formatDateTime, formatNumber } from '@/lib/format';
import { levelDelta, vocationColor, SIDE_LABELS } from '@/lib/tibia';
import { expForLevel, expToNextLevel, expBetween, formatExp } from '@/lib/experience';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { cn } from '@/lib/utils';

const CANDY_TOOLTIP = {
  backgroundColor: 'hsl(324 100% 98%)',
  border: '2px solid hsl(324 100% 85%)',
  borderRadius: '12px',
  fontSize: '12px',
  color: 'hsl(276 19% 35%)',
};

const SIDE_STYLE: Record<WarSide, { border: string; bg: string; bar: string; avatar: string; hex: string; text: string }> = {
  everlast: { border: 'border-emerald-200', bg: 'from-emerald-50', bar: 'bg-emerald-400', avatar: 'bg-emerald-100 text-emerald-600 border-emerald-300', hex: 'hsl(155 57% 50%)', text: 'text-emerald-500' },
  ally: { border: 'border-purple-200', bg: 'from-purple-50', bar: 'bg-purple-400', avatar: 'bg-purple-100 text-purple-500 border-purple-300', hex: 'hsl(270 60% 65%)', text: 'text-purple-500' },
  enemy: { border: 'border-pink-200', bg: 'from-pink-50', bar: 'bg-pink-400', avatar: 'bg-pink-100 text-pink-500 border-pink-300', hex: 'hsl(340 100% 68%)', text: 'text-pink-500' },
  neutral: { border: 'border-purple-200', bg: 'from-purple-50', bar: 'bg-purple-300', avatar: 'bg-purple-50 text-purple-400 border-purple-200', hex: 'hsl(270 40% 70%)', text: 'text-purple-400' },
};

type Tab = 'overview' | 'levels' | 'combat' | 'deaths';
const TABS: { key: Tab; label: string; icon: typeof Shield }[] = [
  { key: 'overview', label: 'Overview', icon: User },
  { key: 'levels', label: 'Levels & Exp', icon: TrendingUp },
  { key: 'combat', label: 'Combat', icon: Swords },
  { key: 'deaths', label: 'Deaths', icon: Skull },
];

export default function CharacterProfilePage() {
  const params = useParams();
  const name = decodeURIComponent(params.name as string);
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [partialErrors, setPartialErrors] = useState<string[]>([]);
  const [character, setCharacter] = useState<Character | null>(null);
  const [deaths, setDeaths] = useState<DeathEvent[]>([]);
  const [levelEvents, setLevelEvents] = useState<LevelEvent[]>([]);
  const [warEvents, setWarEvents] = useState<CanonicalWarEvent[]>([]);
  const [guildmates, setGuildmates] = useState<Character[]>([]);
  const [tab, setTab] = useState<Tab>('overview');
  const [watchId, setWatchId] = useState<string | null>(null);
  const [watchBusy, setWatchBusy] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setLoadError(null);
    setPartialErrors([]);
    setCharacter(null);
    setDeaths([]);
    setLevelEvents([]);
    setWarEvents([]);
    setGuildmates([]);
    setTab('overview');
    (async () => {
      try {
        const char = await getCharacterByName(name);
        if (cancelled) return;
        setCharacter(char);
        if (char) {
          const [d, le, we, mates] = await Promise.allSettled([
            getDeathsForCharacter(char.name, 2000),
            getLevelEventsForCharacter(char.name, 2000),
            getCombatEventsForCharacter(char.name, 5000),
            getCharactersBySide(char.side),
          ]);
          if (cancelled) return;
          const missing: string[] = [];
          if (d.status === 'fulfilled') setDeaths(d.value); else missing.push('death history');
          if (le.status === 'fulfilled') setLevelEvents(le.value); else missing.push('level history');
          if (we.status === 'fulfilled') setWarEvents(we.value); else missing.push('combat statistics');
          if (mates.status === 'fulfilled') setGuildmates(mates.value); else missing.push('guild rankings');
          setPartialErrors(missing);
        }
      } catch (e) {
        if (!cancelled) setLoadError(e instanceof Error ? e.message : 'Unable to load character.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [name]);

  // Is this character on the signed-in user's watchlist?
  useEffect(() => {
    if (!user || !character) { setWatchId(null); return; }
    supabase
      .from('watchlists')
      .select('id')
      .eq('user_id', user.id)
      .eq('character_id', character.id)
      .maybeSingle()
      .then(({ data }) => setWatchId(data?.id ?? null));
  }, [user, character]);

  async function toggleWatch() {
    if (!user || !character || watchBusy) return;
    setWatchBusy(true);
    if (watchId) {
      const { error } = await supabase.from('watchlists').delete().eq('id', watchId);
      if (!error) setWatchId(null);
    } else {
      const { data, error } = await supabase
        .from('watchlists')
        .insert({ user_id: user.id, character_id: character.id })
        .select('id')
        .single();
      if (!error && data) setWatchId(data.id);
    }
    setWatchBusy(false);
  }

  function copyLink() {
    navigator.clipboard?.writeText(window.location.href).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    });
  }

  // ----- Derived data -----
  const stats = useMemo(() => {
    const me = (character?.name ?? name).toLowerCase();
    const pvpDeaths = deaths.filter((d) => d.is_pvp);
    const pveDeaths = deaths.filter((d) => !d.is_pvp);

    // A kill (last hit), a participant credit and an assist are distinct metrics.
    // All sets are sourced from the character-specific canonical PvP query.
    const kills = warEvents.filter((e) =>
      e.is_player_kill && (e.killer_name ?? '').toLowerCase() === me,
    );
    const participations = warEvents.filter((e) =>
      e.is_player_kill && (
        (e.killer_name ?? '').toLowerCase() === me ||
        (e.participated_players ?? []).some((p) => p.toLowerCase() === me) ||
        (e.assisted_players ?? []).some((p) => p.toLowerCase() === me)
      ),
    );
    const assists = warEvents.filter((e) =>
      (e.assisted_players ?? []).some((p) => p.toLowerCase() === me),
    );

    // Nemesis (who kills them) and victims (who they kill)
    const nemesisMap = new Map<string, number>();
    for (const d of pvpDeaths) {
      if (d.killer_name) nemesisMap.set(d.killer_name, (nemesisMap.get(d.killer_name) ?? 0) + 1);
    }
    const victimMap = new Map<string, number>();
    for (const k of kills) victimMap.set(k.character_name, (victimMap.get(k.character_name) ?? 0) + 1);
    const top = (m: Map<string, number>) =>
      Array.from(m.entries()).sort((a, b) => b[1] - a[1]).slice(0, 5);

    // Deaths by hour (local time)
    const hours = Array.from({ length: 24 }, (_, h) => ({ hour: `${String(h).padStart(2, '0')}`, deaths: 0 }));
    for (const d of deaths) hours[new Date(d.death_time).getHours()].deaths++;

    const now = Date.now();
    const deaths7d = deaths.filter((d) => now - new Date(d.death_time).getTime() < 7 * 86_400_000).length;
    const deaths24h = deaths.filter((d) => now - new Date(d.death_time).getTime() < 86_400_000).length;
    const levelsLostToDeaths = levelEvents.filter((e) => e.level_diff < 0).reduce((a, e) => a + Math.abs(e.level_diff), 0);

    return {
      pvpDeaths, pveDeaths, kills, participations, assists,
      nemesis: top(nemesisMap), victims: top(victimMap),
      hours, deaths7d, deaths24h, levelsLostToDeaths,
      kd: pvpDeaths.length > 0 ? kills.length / pvpDeaths.length : kills.length,
      peakHour: hours.reduce((best, h) => (h.deaths > best.deaths ? h : best), hours[0]),
    };
  }, [deaths, levelEvents, warEvents, character, name]);

  // Level history: merge level events (and deaths as fallback points) into one timeline
  const levelTimeline = useMemo(() => {
    const pts = levelEvents
      .filter((e) => e.new_level != null)
      .map((e) => ({ t: new Date(e.observed_at).getTime(), level: e.new_level as number }));
    if (pts.length === 0) {
      deaths.forEach((d) => pts.push({ t: new Date(d.death_time).getTime(), level: d.character_level }));
    }
    if (character?.level != null) pts.push({ t: Date.now(), level: character.level });
    return pts
      .sort((a, b) => a.t - b.t)
      .map((p) => ({
        label: new Date(p.t).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        level: p.level,
      }));
  }, [levelEvents, deaths, character]);

  const levelWindows = useMemo(() => {
    const calc = (days: number) => {
      const cutoff = Date.now() - days * 86_400_000;
      const evs = levelEvents.filter((e) => new Date(e.observed_at).getTime() >= cutoff);
      const gained = evs.filter((e) => e.level_diff > 0).reduce((a, e) => a + e.level_diff, 0);
      const lost = evs.filter((e) => e.level_diff < 0).reduce((a, e) => a + Math.abs(e.level_diff), 0);
      const exp = evs.reduce((a, e) => a + expBetween(e.previous_level, e.new_level), 0);
      return { gained, lost, net: gained - lost, exp };
    };
    return { d1: calc(1), d7: calc(7), d30: calc(30) };
  }, [levelEvents]);

  const guildRank = useMemo(() => {
    if (!character || guildmates.length === 0) return null;
    const sorted = [...guildmates].filter((g) => g.level != null).sort((a, b) => (b.level ?? 0) - (a.level ?? 0));
    const idx = sorted.findIndex((g) => g.id === character.id);
    if (idx < 0) return null;
    const avg = Math.round(sorted.reduce((a, g) => a + (g.level ?? 0), 0) / sorted.length);
    const sameVoc = sorted.filter((g) => g.vocation === character.vocation);
    return {
      rank: idx + 1,
      total: sorted.length,
      avg,
      vocRank: sameVoc.findIndex((g) => g.id === character.id) + 1,
      vocTotal: sameVoc.length,
      above: idx > 0 ? sorted[idx - 1] : null,
      below: idx < sorted.length - 1 ? sorted[idx + 1] : null,
      neighbours: sorted.slice(Math.max(0, idx - 3), idx + 4),
    };
  }, [guildmates, character]);

  if (loading) return <LoadingState label="Loading character profile..." />;

  if (loadError) {
    return (
      <div className="rounded-2xl border-2 border-amber-200 bg-amber-50 p-5 text-sm font-semibold text-amber-700">
        Could not load the character profile: {loadError}
      </div>
    );
  }

  if (!character) {
    return (
      <div className="space-y-6">
        <Link href="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground font-semibold">
          <ArrowLeft className="size-4" /> Back to Dashboard
        </Link>
        <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-12 text-center shadow-bubbly">
          <User className="size-12 text-pink-200 mx-auto mb-3" />
          <h2 className="text-lg font-bold text-foreground">Character Not Found</h2>
          <p className="text-sm text-muted-foreground mt-1 font-semibold">
            &ldquo;{name}&rdquo; is not in the candy war room database.
          </p>
          <a
            href={`https://www.tibia.com/community/?name=${encodeURIComponent(name)}`}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 inline-flex items-center gap-1.5 rounded-xl border-2 border-pink-200 bg-pink-50 px-3 py-1.5 text-xs font-bold text-pink-500 hover:bg-pink-100"
          >
            <ExternalLink className="size-3.5" /> Look up on Tibia.com
          </a>
        </div>
      </div>
    );
  }

  const side = character.side;
  const sty = SIDE_STYLE[side];
  const delta = levelDelta(character);
  const hasMockData = deaths.some((d) => d.source === 'mock-dev');
  const level = character.level ?? 0;
  const totalExp = expForLevel(level);
  const dangerScore = Math.min(100, Math.round(stats.deaths24h * 25 + stats.deaths7d * 6 + stats.pvpDeaths.length * 1.5));
  const dangerLabel = dangerScore >= 60 ? 'Feeding' : dangerScore >= 30 ? 'Risky' : dangerScore >= 10 ? 'Normal' : 'Safe';

  return (
    <div className="space-y-6 animate-float-up">
      {partialErrors.length > 0 && (
        <div role="alert" className="rounded-xl border-2 border-amber-200 bg-amber-50 p-3 text-xs font-semibold text-amber-700">
          Some data could not be loaded ({partialErrors.join(', ')}). The corresponding statistics may be incomplete.
        </div>
      )}
      {(deaths.length >= 2000 || levelEvents.length >= 2000) && (
        <div role="status" className="rounded-xl border-2 border-amber-200 bg-amber-50 p-3 text-xs font-semibold text-amber-700">
          This character reached the 2,000-event history limit. Some older events may be missing.
        </div>
      )}
      {warEvents.length >= 5000 && (
        <div role="status" className="rounded-xl border-2 border-amber-200 bg-amber-50 p-3 text-xs font-semibold text-amber-700">
          Combat history reached its 5,000-event safety limit. Totals may be incomplete.
        </div>
      )}
      <Link href="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors font-semibold">
        <ArrowLeft className="size-4" /> Back to Dashboard
      </Link>

      {/* Header */}
      <div className={cn('relative overflow-hidden rounded-2xl border-2 bg-gradient-to-br to-white p-6 shadow-bubbly', sty.border, sty.bg)}>
        <div className={cn('absolute inset-x-0 top-0 h-1.5', sty.bar)} />
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-4">
            <div className={cn('flex size-16 shrink-0 items-center justify-center rounded-2xl text-xl font-bold border-2', sty.avatar)}>
              {character.name.slice(0, 2).toUpperCase()}
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <h1 className="text-2xl font-bold text-foreground break-all">{character.name}</h1>
                <SideBadge side={side} />
                {character.rank === 'Leader' && <Crown className="size-4 text-amber-400" fill="currentColor" />}
              </div>
              <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-sm font-semibold">
                {character.vocation && <span className={vocationColor(character.vocation)}>{character.vocation}</span>}
                <span className="text-muted-foreground">Level {character.level ?? '?'}</span>
                {character.guild_name && <span className="text-muted-foreground">· {character.guild_name}</span>}
                {character.rank && <span className="text-xs text-muted-foreground uppercase tracking-wider font-bold">{character.rank}</span>}
              </div>
              <div className="mt-2 flex items-center gap-3">
                <OnlineIndicator online={character.online} />
                <span className="flex items-center gap-1 text-[11px] text-muted-foreground font-semibold">
                  <Clock className="size-3" /> Last seen {timeAgo(character.last_seen_at)}
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-col items-start gap-2 lg:items-end">
            <MockDataBadge show={hasMockData} />
            <div className="flex flex-wrap gap-2">
              {user && (
                <button
                  onClick={toggleWatch}
                  disabled={watchBusy}
                  className={cn(
                    'flex items-center gap-1.5 rounded-xl border-2 px-3 py-1.5 text-xs font-bold transition-colors disabled:opacity-60',
                    watchId ? 'border-emerald-300 bg-emerald-50 text-emerald-600' : 'border-pink-200 bg-white text-pink-500 hover:bg-pink-50',
                  )}
                >
                  {watchId ? <EyeOff className="size-3.5" /> : <Eye className="size-3.5" />}
                  {watchId ? 'Unwatch' : 'Watch'}
                </button>
              )}
              <button
                onClick={copyLink}
                className="flex items-center gap-1.5 rounded-xl border-2 border-pink-200 bg-white px-3 py-1.5 text-xs font-bold text-pink-500 hover:bg-pink-50"
              >
                {copied ? <Check className="size-3.5" /> : <Link2 className="size-3.5" />}
                {copied ? 'Copied' : 'Copy link'}
              </button>
              <a
                href={`https://www.tibia.com/community/?name=${encodeURIComponent(character.name)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 rounded-xl border-2 border-pink-200 bg-white px-3 py-1.5 text-xs font-bold text-pink-500 hover:bg-pink-50"
              >
                <ExternalLink className="size-3.5" /> Tibia.com
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Key stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          label="Level"
          value={character.level ?? '—'}
          sublabel={delta !== null ? `${delta > 0 ? '+' : ''}${delta} since last sync` : 'No change since last sync'}
          icon={Shield}
          side={side}
        />
        <StatCard label="Experience" value={formatExp(totalExp)} sublabel={`${formatExp(expToNextLevel(level))} to level ${level + 1}`} icon={Zap} side={side} />
        <StatCard
          label="Guild rank"
          value={guildRank ? `#${guildRank.rank}` : '—'}
          sublabel={guildRank ? `of ${guildRank.total} in ${SIDE_LABELS[side]}` : 'Not ranked'}
          icon={Trophy}
          side="neutral"
        />
        <StatCard
          label="K / D (PvP)"
          value={stats.kd.toFixed(2)}
          sublabel={`${stats.kills.length} last hits · ${stats.pvpDeaths.length} PvP deaths`}
          icon={Swords}
          side="enemy"
        />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 overflow-x-auto rounded-2xl border-2 border-pink-200 bg-white/70 p-1 shadow-bubbly">
        {TABS.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                'flex flex-1 items-center justify-center gap-1.5 whitespace-nowrap rounded-xl px-3 py-2 text-xs font-bold transition-colors',
                tab === t.key ? 'bg-pink-400 text-white' : 'text-purple-400 hover:bg-pink-50',
              )}
            >
              <Icon className="size-3.5" /> {t.label}
            </button>
          );
        })}
      </div>

      {/* ---------- OVERVIEW ---------- */}
      {tab === 'overview' && (
        <div className="grid gap-4 lg:grid-cols-3">
          <div className="space-y-4 lg:col-span-2">
            <Panel title="Level progression" icon={<TrendingUp className="size-4 text-emerald-500" />}>
              <LevelChart data={levelTimeline} color={sty.hex} />
            </Panel>

            <div className="grid gap-4 sm:grid-cols-3">
              <WindowCard label="24 hours" w={levelWindows.d1} />
              <WindowCard label="7 days" w={levelWindows.d7} />
              <WindowCard label="30 days" w={levelWindows.d30} />
            </div>

            <Panel title="Recent activity" icon={<Activity className="size-4 text-purple-400" />}>
              <ActivityFeed deaths={deaths} levelEvents={levelEvents} />
            </Panel>
          </div>

          <div className="space-y-4">
            <Panel title="Danger meter" icon={<Flame className="size-4 text-pink-400" />}>
              <div className="flex items-end justify-between">
                <div className="text-3xl font-bold tabular-nums text-foreground">{dangerScore}</div>
                <span className={cn('rounded-lg px-2 py-1 text-xs font-bold', dangerScore >= 60 ? 'bg-pink-100 text-pink-500' : dangerScore >= 30 ? 'bg-amber-100 text-amber-600' : 'bg-emerald-100 text-emerald-600')}>
                  {dangerLabel}
                </span>
              </div>
              <div className="mt-2 h-2 overflow-hidden rounded-full bg-pink-100">
                <div className={cn('h-full rounded-full', dangerScore >= 60 ? 'bg-pink-400' : dangerScore >= 30 ? 'bg-amber-400' : 'bg-emerald-400')} style={{ width: `${dangerScore}%` }} />
              </div>
              <p className="mt-2 text-[11px] font-semibold text-muted-foreground">
                {stats.deaths24h} deaths in 24h · {stats.deaths7d} in 7 days
              </p>
            </Panel>

            {guildRank && (
              <Panel title="Guild standing" icon={<Crown className="size-4 text-amber-400" />}>
                <div className="grid grid-cols-2 gap-2 text-center">
                  <MiniStat label={`${character.vocation ?? 'Vocation'} rank`} value={`#${guildRank.vocRank}/${guildRank.vocTotal}`} />
                  <MiniStat label="Guild avg" value={guildRank.avg} />
                </div>
                <p className="mt-2 text-[11px] font-semibold text-muted-foreground">
                  {level >= guildRank.avg ? `${level - guildRank.avg} levels above` : `${guildRank.avg - level} levels below`} the guild average.
                </p>
                <div className="mt-3 space-y-1.5">
                  {guildRank.neighbours.map((m) => (
                    <Link
                      key={m.id}
                      href={`/character/${encodeURIComponent(m.name)}`}
                      className={cn(
                        'flex items-center justify-between rounded-lg border-2 px-2.5 py-1.5 text-xs font-bold hover:bg-pink-50',
                        m.id === character.id ? 'border-pink-300 bg-pink-50 text-pink-500' : 'border-pink-100 text-foreground',
                      )}
                    >
                      <span className="flex items-center gap-1.5 truncate">
                        <span className={cn('size-1.5 rounded-full', m.online ? 'bg-emerald-400' : 'bg-gray-300')} />
                        {m.name}
                      </span>
                      <span className="tabular-nums">{m.level}</span>
                    </Link>
                  ))}
                </div>
              </Panel>
            )}
          </div>
        </div>
      )}

      {/* ---------- LEVELS ---------- */}
      {tab === 'levels' && (
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Gained (7d)" value={`+${levelWindows.d7.gained}`} sublabel={`${formatExp(levelWindows.d7.exp)} exp net`} icon={TrendingUp} side="everlast" />
            <StatCard label="Lost (7d)" value={levelWindows.d7.lost} sublabel="From deaths & drops" icon={TrendingDown} side="enemy" />
            <StatCard label="Gained (30d)" value={`+${levelWindows.d30.gained}`} sublabel={`${formatExp(levelWindows.d30.exp)} exp net`} icon={TrendingUp} side="ally" />
            <StatCard label="Total lost" value={stats.levelsLostToDeaths} sublabel="All tracked history" icon={Skull} side="neutral" />
          </div>
          <Panel title="Level progression" icon={<TrendingUp className="size-4 text-emerald-500" />}>
            <LevelChart data={levelTimeline} color={sty.hex} height={260} />
          </Panel>
          <Panel title="Level change history" icon={<Clock className="size-4 text-purple-400" />}>
            {levelEvents.length === 0 && <Empty text="No level changes tracked yet." />}
            <div className="space-y-2.5">
              {levelEvents.map((ev) => (
                <div key={ev.id} className="flex items-center gap-3 rounded-xl border-2 border-pink-100 bg-pink-50/50 p-3">
                  <div className={cn('flex size-8 shrink-0 items-center justify-center rounded-xl', ev.level_diff > 0 ? 'bg-emerald-100 text-emerald-500' : 'bg-pink-100 text-pink-500')}>
                    {ev.level_diff > 0 ? <TrendingUp className="size-4" /> : <TrendingDown className="size-4" />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-bold text-foreground">{ev.previous_level ?? '?'} → {ev.new_level ?? '?'}</div>
                    <div className="text-xs text-muted-foreground mt-0.5 font-semibold">
                      {timeAgo(ev.observed_at)} · {formatDateTime(ev.observed_at)}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className={cn('block rounded-lg px-2.5 py-0.5 text-xs font-bold', ev.level_diff > 0 ? 'bg-emerald-100 text-emerald-500' : 'bg-pink-100 text-pink-500')}>
                      {ev.level_diff > 0 ? '+' : ''}{ev.level_diff}
                    </span>
                    <span className="text-[10px] font-bold text-muted-foreground">
                      {formatExp(expBetween(ev.previous_level, ev.new_level))} exp
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      )}

      {/* ---------- COMBAT ---------- */}
      {tab === 'combat' && (
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="PvP last hits" value={stats.kills.length} sublabel="Recorded final blows" icon={Swords} side="everlast" />
            <StatCard label="PvP participation" value={stats.participations.length} sublabel={`${stats.assists.length} recorded assists`} icon={Target} side="ally" />
            <StatCard label="PvP deaths" value={stats.pvpDeaths.length} sublabel="Killed by players" icon={Skull} side="enemy" />
            <StatCard label="PvE deaths" value={stats.pveDeaths.length} sublabel="Killed by monsters" icon={Activity} side="neutral" />
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <Panel title="Nemesis — killed by most" icon={<Skull className="size-4 text-pink-400" />}>
              {stats.nemesis.length === 0 && <Empty text="No PvP deaths recorded." />}
              <RankList rows={stats.nemesis} unit="deaths" tone="pink" />
            </Panel>
            <Panel title="Favourite victims" icon={<Swords className="size-4 text-emerald-500" />}>
              {stats.victims.length === 0 && <Empty text="No kills recorded in the war log." />}
              <RankList rows={stats.victims} unit="kills" tone="emerald" />
            </Panel>
          </div>

          <Panel title="When do they die?" icon={<Clock className="size-4 text-purple-400" />}>
            <ResponsiveContainer width="100%" height={180}>
              <BarChart data={stats.hours} margin={{ top: 5, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(324 50% 90%)" />
                <XAxis dataKey="hour" stroke="hsl(276 12% 50%)" fontSize={10} tickLine={false} axisLine={false} interval={1} />
                <YAxis stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip contentStyle={CANDY_TOOLTIP} labelFormatter={(h) => `${h}:00 (your local time)`} />
                <Bar dataKey="deaths" fill={sty.hex} radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
            {stats.peakHour.deaths > 0 && (
              <p className="mt-1 text-[11px] font-semibold text-muted-foreground">
                Most dangerous hour: <span className="font-bold text-foreground">{stats.peakHour.hour}:00</span> ({stats.peakHour.deaths} deaths).
              </p>
            )}
          </Panel>

          <Panel title="Recent kills" icon={<Swords className="size-4 text-emerald-500" />}>
            {stats.kills.length === 0 && <Empty text="No kills in the war log." />}
            <div className="space-y-2">
              {stats.kills.slice(0, 15).map((k) => (
                <div key={k.event_id} className="flex items-center justify-between gap-3 rounded-xl border-2 border-emerald-100 bg-emerald-50/40 px-3 py-2">
                  <Link href={`/character/${encodeURIComponent(k.character_name)}`} className="truncate text-sm font-bold text-foreground hover:underline">
                    {k.character_name} <span className="text-xs text-muted-foreground font-semibold">Lv {k.character_level}</span>
                  </Link>
                  <span className="shrink-0 text-[11px] font-semibold text-muted-foreground">{timeAgo(k.death_time)}</span>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      )}

      {/* ---------- DEATHS ---------- */}
      {tab === 'deaths' && (
        <Panel title={`Death history (${deaths.length})`} icon={<Heart className="size-4 text-pink-400" fill="currentColor" />}>
          {deaths.length === 0 && <Empty text="No deaths recorded for this character." />}
          <div className="space-y-2.5">
            {deaths.map((death) => (
              <div key={death.id} className="flex items-start gap-3 rounded-xl border-2 border-pink-100 bg-pink-50/50 p-3">
                <div className={cn('flex size-8 shrink-0 items-center justify-center rounded-xl', death.is_pvp ? 'bg-pink-100 text-pink-500' : 'bg-purple-100 text-purple-400')}>
                  {death.is_pvp ? <Swords className="size-4" /> : <Skull className="size-4" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-sm text-foreground font-semibold">
                    {death.is_pvp && death.killer_name ? (
                      <>
                        Killed by{' '}
                        <Link href={`/character/${encodeURIComponent(death.killer_name)}`} className="font-bold text-emerald-500 hover:underline">
                          {death.killer_name}
                        </Link>
                        {death.killer_guild_name && <span className="text-muted-foreground"> ({death.killer_guild_name})</span>}
                        {(death.participated_players?.length ?? 0) > 1 && (
                          <span className="text-muted-foreground"> +{(death.participated_players?.length ?? 1) - 1} more</span>
                        )}
                      </>
                    ) : (
                      death.reason
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground mt-0.5 font-semibold">
                    Level {death.character_level} · {formatDateTime(death.death_time)} · {timeAgo(death.death_time)}
                  </div>
                </div>
                <span className={cn('shrink-0 rounded-lg px-2 py-1 text-[10px] font-bold', death.is_pvp ? 'bg-pink-100 text-pink-500' : 'bg-purple-100 text-purple-400')}>
                  {death.is_pvp ? 'PvP' : 'PvE'}
                </span>
              </div>
            ))}
          </div>
        </Panel>
      )}
    </div>
  );
}

/* ---------- small building blocks ---------- */

function Panel({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
      <h2 className="text-sm font-bold text-foreground mb-4 flex items-center gap-1.5">{icon} {title}</h2>
      {children}
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return <div className="text-sm text-muted-foreground py-4 text-center font-semibold">{text}</div>;
}

function MiniStat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl bg-pink-50/60 py-2">
      <div className="text-base font-bold tabular-nums text-foreground">{value}</div>
      <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}

function LevelChart({ data, color, height = 200 }: { data: { label: string; level: number }[]; color: string; height?: number }) {
  if (data.length < 2) return <Empty text="Not enough level data to draw a chart yet." />;
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="levelGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.4} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(324 50% 90%)" />
        <XAxis dataKey="label" stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} />
        <YAxis stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} domain={['dataMin - 5', 'dataMax + 5']} allowDecimals={false} />
        <Tooltip contentStyle={CANDY_TOOLTIP} />
        <Area type="stepAfter" dataKey="level" stroke={color} strokeWidth={2} fill="url(#levelGrad)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}

function WindowCard({ label, w }: { label: string; w: { gained: number; lost: number; net: number; exp: number } }) {
  return (
    <div className="rounded-2xl border-2 border-purple-200 bg-white/70 p-4 shadow-bubbly">
      <div className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={cn('mt-1 text-2xl font-bold tabular-nums', w.net > 0 ? 'text-emerald-500' : w.net < 0 ? 'text-pink-500' : 'text-foreground')}>
        {w.net > 0 ? '+' : ''}{w.net} lvl
      </div>
      <div className="text-[11px] font-semibold text-muted-foreground">
        {w.exp >= 0 ? '+' : ''}{formatExp(w.exp)} exp · <span className="text-emerald-500">▲{w.gained}</span> <span className="text-pink-500">▼{w.lost}</span>
      </div>
    </div>
  );
}

function RankList({ rows, unit, tone }: { rows: [string, number][]; unit: string; tone: 'pink' | 'emerald' }) {
  const max = rows[0]?.[1] ?? 1;
  return (
    <div className="space-y-2">
      {rows.map(([n, count]) => (
        <Link key={n} href={`/character/${encodeURIComponent(n)}`} className="block group">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="truncate text-foreground group-hover:underline">{n}</span>
            <span className={tone === 'pink' ? 'text-pink-500' : 'text-emerald-500'}>{formatNumber(count)} {unit}</span>
          </div>
          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-pink-50">
            <div className={cn('h-full rounded-full', tone === 'pink' ? 'bg-pink-300' : 'bg-emerald-300')} style={{ width: `${(count / max) * 100}%` }} />
          </div>
        </Link>
      ))}
    </div>
  );
}

function ActivityFeed({ deaths, levelEvents }: { deaths: DeathEvent[]; levelEvents: LevelEvent[] }) {
  const items = [
    ...deaths.slice(0, 10).map((d) => ({
      id: `d-${d.id}`,
      t: new Date(d.death_time).getTime(),
      kind: 'death' as const,
      text: d.is_pvp && d.killer_name ? `Died to ${d.killer_name} at level ${d.character_level}` : `Died (${d.reason}) at level ${d.character_level}`,
    })),
    ...levelEvents.slice(0, 10).map((e) => ({
      id: `l-${e.id}`,
      t: new Date(e.observed_at).getTime(),
      kind: e.level_diff > 0 ? ('up' as const) : ('down' as const),
      text: `Level ${e.previous_level ?? '?'} → ${e.new_level ?? '?'} (${e.level_diff > 0 ? '+' : ''}${e.level_diff})`,
    })),
  ]
    .sort((a, b) => b.t - a.t)
    .slice(0, 8);

  if (items.length === 0) return <Empty text="Nothing recorded yet." />;
  return (
    <div className="space-y-2">
      {items.map((it) => (
        <div key={it.id} className="flex items-center gap-3 rounded-xl border-2 border-pink-100 bg-pink-50/40 px-3 py-2">
          <span className={cn('flex size-6 shrink-0 items-center justify-center rounded-lg', it.kind === 'up' ? 'bg-emerald-100 text-emerald-500' : it.kind === 'down' ? 'bg-pink-100 text-pink-500' : 'bg-purple-100 text-purple-400')}>
            {it.kind === 'up' ? <TrendingUp className="size-3.5" /> : it.kind === 'down' ? <TrendingDown className="size-3.5" /> : <Skull className="size-3.5" />}
          </span>
          <span className="min-w-0 flex-1 truncate text-xs font-semibold text-foreground">{it.text}</span>
          <span className="shrink-0 text-[10px] font-semibold text-muted-foreground">{timeAgo(new Date(it.t))}</span>
        </div>
      ))}
    </div>
  );
}
