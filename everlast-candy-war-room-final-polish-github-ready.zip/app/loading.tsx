import { Candy, Loader2 } from 'lucide-react';

/** Shared App Router loading screen keeps page transitions consistent. */
export default function Loading() {
  return (
    <div className="mx-auto flex min-h-[45vh] max-w-xl flex-col items-center justify-center gap-4 rounded-3xl border-2 border-pink-200 bg-gradient-to-br from-pink-50 via-white to-purple-50 p-8 text-center shadow-bubbly" role="status" aria-live="polite">
      <div className="relative flex size-14 items-center justify-center rounded-2xl bg-gradient-to-br from-pink-300 to-purple-300 text-white">
        <Candy className="size-7" aria-hidden="true" />
        <Loader2 className="absolute -bottom-2 -right-2 size-6 animate-spin rounded-full bg-white p-1 text-purple-500" aria-hidden="true" />
      </div>
      <h2 className="text-lg font-black text-foreground">🍬 Ładowanie Candy War Room</h2>
      <p className="text-sm text-muted-foreground">Przygotowujemy stronę…</p>
    </div>
  );
}
