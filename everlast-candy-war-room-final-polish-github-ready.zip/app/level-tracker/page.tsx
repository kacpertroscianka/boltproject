'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import {
  TrendingUp,
  TrendingDown,
  Search,
  Crown,
  Sparkles,
  Users,
  Zap,
  ArrowUp,
  ArrowDown,
  Info,
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { getCharactersBySides, getLevelEventsSince } from '@/lib/queries';
import {
  TRACKED_SIDES,
  buildDailyLevelSeries,
  buildGuildProgress,
  buildPlayerProgress,
  expToNextLevel,
  formatExp,
  type PlayerProgress,
  type TrackedSide,
} from '@/lib/experience';
import type { Character, LevelEvent } from '@/lib/types';
import { LoadingState, StatCard } from '@/components/stat-card';
import { CharacterTag } from '@/components/character-tag';
import { SIDE_LABELS, vocationColor } from '@/lib/tibia';
import { formatNumber } from '@/lib/format';
import { cn } from '@/lib/utils';

const CANDY_TOOLTIP = {
  backgroundColor: 'hsl(324 100% 98%)',
  border: '2px solid hsl(324 100% 85%)',
  borderRadius: '12px',
  fontSize: '12px',
  color: 'hsl(276 19% 35%)',
};

const SIDE_HEX: Record<TrackedSide, string> = {
  everlast: 'hsl(155 57% 50%)',
  ally: 'hsl(270 60% 65%)',
  enemy: 'hsl(340 100% 68%)',
};

const PERIODS = [
  { key: '1', label: '24h', days: 1 },
  { key: '7', label: '7 days', days: 7 },
  { key: '30', label: '30 days', days: 30 },
] as const;

type GuildFilter = 'all' | TrackedSide;
type SortKey = 'level' | 'exp' | 'gained' | 'expGained';

export default function LevelTrackerPage() {
  const [loading, setLoading] = useState(true);
  const [rosterLoading, setRosterLoading] = useState(true);
  const [rosterError, setRosterError] = useState<string | null>(null);
  const [eventsError, setEventsError] = useState<string | null>(null);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [events, setEvents] = useState<LevelEvent[]>([]);
  const [days, setDays] = useState<number>(7);
  const [guild, setGuild] = useState<GuildFilter>('all');
  const [sort, setSort] = useState<SortKey>('level');
  const [query, setQuery] = useState('');
  const [onlineOnly, setOnlineOnly] = useState(false);
  const [limit, setLimit] = useState(50);

  // Roster only needs to load once; events reload when the window changes.
  useEffect(() => {
    let active = true;
    getCharactersBySides(TRACKED_SIDES)
      .then((roster) => { if (active) setCharacters(roster); })
      .catch((e) => { if (active) setRosterError(e instanceof Error ? e.message : 'Failed to load roster'); })
      .finally(() => { if (active) setRosterLoading(false); });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setEvents([]); // Avoid showing a different period's statistics while reloading.
    setEventsError(null);
    const since = new Date(Date.now() - days * 86_400_000).toISOString();
    getLevelEventsSince(since, 1000)
      .then((ev) => { if (active) setEvents(ev); })
      .catch((e) => { if (active) setEventsError(e instanceof Error ? e.message : 'Failed to load level events'); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [days]);

  const players = useMemo(() => buildPlayerProgress(characters, events), [characters, events]);
  const guilds = useMemo(
    () => TRACKED_SIDES.map((s) => buildGuildProgress(players, s)),
    [players],
  );
  const daily = useMemo(() => buildDailyLevelSeries(events, Math.max(days, 7)), [events, days]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    const rows = players.filter((p) =>
      (guild === 'all' || p.side === guild) &&
      (!onlineOnly || p.online) &&
      (!q || p.name.toLowerCase().includes(q)),
    );
    const key: Record<SortKey, (p: PlayerProgress) => number> = {
      level: (p) => p.level,
      exp: (p) => p.totalExp,
      gained: (p) => p.netLevels,
      expGained: (p) => p.expGained,
    };
    return rows.sort((a, b) => key[sort](b) - key[sort](a) || b.level - a.level);
  }, [players, guild, onlineOnly, query, sort]);

  const topGainers = useMemo(
    () =>
      players
        .filter((p) => (guild === 'all' || p.side === guild) && p.netLevels > 0)
        .sort((a, b) => b.expGained - a.expGained)
        .slice(0, 8),
    [players, guild],
  );
  const biggestLosses = useMemo(
    () =>
      players
        .filter((p) => (guild === 'all' || p.side === guild) && p.netLevels < 0)
        .sort((a, b) => a.expGained - b.expGained)
        .slice(0, 5),
    [players, guild],
  );

  const bracketData = useMemo(
    () =>
      guilds[0].brackets.map((b, i) => ({
        bracket: b.label,
        Everlast: guilds[0].brackets[i].count,
        Terrory: guilds[1].brackets[i].count,
        'Mandatory Again': guilds[2].brackets[i].count,
      })),
    [guilds],
  );

  const truncated = events.length >= 1000;
  const periodLabel = PERIODS.find((p) => p.days === days)?.label ?? `${days}d`;
  const error = rosterError ?? eventsError;

  if (loading || rosterLoading) return <LoadingState label="Counting candy XP..." />;
  if (error) return (
    <div role="alert" className="rounded-2xl border-2 border-amber-200 bg-amber-50 p-5 text-sm font-semibold text-amber-700">
      Failed to load level tracking data: {error}
      <button type="button" onClick={() => window.location.reload()} className="ml-3 rounded-lg bg-white px-3 py-1 text-purple-600 underline">
        Retry
      </button>
    </div>
  );

  return (
    <div className="space-y-6 animate-float-up">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <TrendingUp className="size-6 text-emerald-500" /> Level &amp; Experience Tracker
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5 font-semibold">
            Who is levelling, who is falling behind &mdash; per guild, per player.
          </p>
        </div>
        <div className="flex items-center gap-1 rounded-xl border-2 border-pink-200 bg-white/70 p-1 shadow-bubbly self-start">
          {PERIODS.map((p) => (
            <button
              key={p.key}
              onClick={() => setDays(p.days)}
              className={cn(
                'rounded-lg px-3 py-1.5 text-xs font-bold transition-colors',
                days === p.days ? 'bg-pink-400 text-white' : 'text-purple-400 hover:bg-pink-50',
              )}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="rounded-xl border-2 border-pink-200 bg-pink-50 p-3 text-xs font-bold text-pink-500">{error}</div>
      )}

      {loading ? (
        <LoadingState label="Counting candy XP..." />
      ) : (
        <>
          {/* Guild summary cards */}
          <div className="grid gap-4 lg:grid-cols-3">
            {guilds.map((g) => (
              <GuildCard
                key={g.side}
                g={g}
                periodLabel={periodLabel}
                active={guild === g.side}
                onClick={() => setGuild(guild === g.side ? 'all' : g.side)}
              />
            ))}
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard
              label="Levels gained"
              value={formatNumber(guilds.filter((g) => guild === 'all' || g.side === guild).reduce((a, g) => a + g.levelsGained, 0))}
              sublabel={`Last ${periodLabel}`}
              icon={ArrowUp}
              side="everlast"
            />
            <StatCard
              label="Levels lost"
              value={formatNumber(guilds.filter((g) => guild === 'all' || g.side === guild).reduce((a, g) => a + g.levelsLost, 0))}
              sublabel="Deaths & drops"
              icon={ArrowDown}
              side="enemy"
            />
            <StatCard
              label="Net exp"
              value={formatExp(guilds.filter((g) => guild === 'all' || g.side === guild).reduce((a, g) => a + g.expGained, 0))}
              sublabel="Estimated from level changes"
              icon={Zap}
              side="ally"
            />
            <StatCard
              label="Active levellers"
              value={guilds.filter((g) => guild === 'all' || g.side === guild).reduce((a, g) => a + g.activeGainers, 0)}
              sublabel="Players with a net gain"
              icon={Users}
              side="neutral"
            />
          </div>

          {/* Daily chart */}
          <div className="rounded-2xl border-2 border-purple-200 bg-white/70 p-5 shadow-bubbly">
            <h2 className="text-sm font-bold text-foreground mb-4 flex items-center gap-1.5">
              <Sparkles className="size-4 text-purple-400" /> Levels gained per day
            </h2>
            <ResponsiveContainer width="100%" height={230}>
              <LineChart data={daily} margin={{ top: 5, right: 16, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(324 50% 90%)" />
                <XAxis dataKey="label" stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip contentStyle={CANDY_TOOLTIP} />
                <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 600 }} />
                <Line type="monotone" dataKey="everlast" name="Everlast" stroke={SIDE_HEX.everlast} strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="ally" name="Terrory" stroke={SIDE_HEX.ally} strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="enemy" name="Mandatory Again" stroke={SIDE_HEX.enemy} strokeWidth={2.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            {/* Top gainers */}
            <div className="rounded-2xl border-2 border-emerald-200 bg-white/70 p-5 shadow-bubbly-everlast">
              <h2 className="text-sm font-bold text-foreground mb-3 flex items-center gap-1.5">
                <Crown className="size-4 text-amber-400" fill="currentColor" /> Top levellers &middot; {periodLabel}
              </h2>
              {topGainers.length === 0 && (
                <div className="py-6 text-center text-sm font-semibold text-muted-foreground">No level gains recorded in this window.</div>
              )}
              <div className="space-y-2">
                {topGainers.map((p, i) => (
                  <Link
                    key={p.name}
                    href={`/character/${encodeURIComponent(p.name)}`}
                    className="flex items-center gap-3 rounded-xl border-2 border-emerald-100 bg-emerald-50/40 p-2.5 hover:bg-emerald-50 transition-colors"
                  >
                    <span className="w-5 text-center text-xs font-bold text-muted-foreground">{i + 1}</span>
                    <CharacterTag name={p.name} vocation={p.vocation} level={p.level} side={p.side} className="flex-1" />
                    <div className="text-right">
                      <div className="text-sm font-bold text-emerald-500">+{p.netLevels} lvl</div>
                      <div className="text-[10px] font-bold text-muted-foreground">{formatExp(p.expGained)} exp</div>
                    </div>
                  </Link>
                ))}
              </div>
              {biggestLosses.length > 0 && (
                <>
                  <h3 className="mt-5 mb-2 text-xs font-bold uppercase tracking-wider text-pink-400 flex items-center gap-1.5">
                    <TrendingDown className="size-3.5" /> Biggest losses
                  </h3>
                  <div className="space-y-1.5">
                    {biggestLosses.map((p) => (
                      <Link
                        key={p.name}
                        href={`/character/${encodeURIComponent(p.name)}`}
                        className="flex items-center justify-between rounded-lg border-2 border-pink-100 bg-pink-50/40 px-2.5 py-1.5 text-xs font-bold hover:bg-pink-50"
                      >
                        <span className="truncate text-foreground">{p.name}</span>
                        <span className="text-pink-500">{p.netLevels} lvl &middot; {formatExp(p.expGained)}</span>
                      </Link>
                    ))}
                  </div>
                </>
              )}
            </div>

            {/* Level brackets */}
            <div className="rounded-2xl border-2 border-purple-200 bg-white/70 p-5 shadow-bubbly">
              <h2 className="text-sm font-bold text-foreground mb-4 flex items-center gap-1.5">
                <Users className="size-4 text-purple-400" /> Level distribution
              </h2>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={bracketData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(324 50% 90%)" />
                  <XAxis dataKey="bracket" stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="hsl(276 12% 50%)" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                  <Tooltip contentStyle={CANDY_TOOLTIP} />
                  <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 600 }} />
                  <Bar dataKey="Everlast" fill={SIDE_HEX.everlast} radius={[5, 5, 0, 0]} />
                  <Bar dataKey="Terrory" fill={SIDE_HEX.ally} radius={[5, 5, 0, 0]} />
                  <Bar dataKey="Mandatory Again" fill={SIDE_HEX.enemy} radius={[5, 5, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Roster table */}
          <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between mb-4">
              <h2 className="text-sm font-bold text-foreground">
                Player experience board <span className="text-muted-foreground font-semibold">({visible.length})</span>
              </h2>
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1 rounded-xl border-2 border-pink-200 bg-white p-1">
                  {(['all', ...TRACKED_SIDES] as GuildFilter[]).map((g) => (
                    <button
                      key={g}
                      onClick={() => setGuild(g)}
                      className={cn(
                        'rounded-lg px-2.5 py-1 text-[11px] font-bold transition-colors',
                        guild === g ? 'bg-pink-400 text-white' : 'text-purple-400 hover:bg-pink-50',
                      )}
                    >
                      {g === 'all' ? 'All' : SIDE_LABELS[g]}
                    </button>
                  ))}
                </div>
                <label className="flex items-center gap-1.5 text-[11px] font-bold text-purple-400 cursor-pointer">
                  <input type="checkbox" checked={onlineOnly} onChange={(e) => setOnlineOnly(e.target.checked)} className="accent-pink-400" />
                  Online only
                </label>
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 size-3.5 text-pink-300" />
                  <input
                    value={query}
                    onChange={(e) => { setQuery(e.target.value); setLimit(50); }}
                    placeholder="Search player"
                    className="w-40 rounded-xl border-2 border-pink-200 bg-white py-1.5 pl-8 pr-2 text-xs font-semibold outline-none focus:border-pink-300"
                  />
                </div>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px] text-left">
                <thead>
                  <tr className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                    <th className="pb-2 pr-2 w-8">#</th>
                    <th className="pb-2 pr-2">Player</th>
                    <SortTh label="Level" k="level" sort={sort} setSort={setSort} />
                    <SortTh label="Total exp" k="exp" sort={sort} setSort={setSort} />
                    <th className="pb-2 pr-2 text-right">To next</th>
                    <SortTh label={`Levels (${periodLabel})`} k="gained" sort={sort} setSort={setSort} />
                    <SortTh label="Exp change" k="expGained" sort={sort} setSort={setSort} />
                  </tr>
                </thead>
                <tbody>
                  {visible.slice(0, limit).map((p, i) => (
                    <tr key={p.name} className="border-t border-pink-100 hover:bg-pink-50/40">
                      <td className="py-2 pr-2 text-xs font-bold text-muted-foreground">{i + 1}</td>
                      <td className="py-2 pr-2">
                        <Link href={`/character/${encodeURIComponent(p.name)}`} className="flex items-center gap-2 hover:opacity-80">
                          <span className={cn('size-2 shrink-0 rounded-full', p.online ? 'bg-emerald-400' : 'bg-gray-300')} />
                          <CharacterTag name={p.name} vocation={p.vocation} side={p.side} />
                        </Link>
                      </td>
                      <td className={cn('py-2 pr-2 text-right text-sm font-bold tabular-nums', vocationColor(p.vocation))}>{p.level}</td>
                      <td className="py-2 pr-2 text-right text-xs font-bold tabular-nums text-foreground">{formatExp(p.totalExp)}</td>
                      <td className="py-2 pr-2 text-right text-[11px] font-semibold tabular-nums text-muted-foreground">{formatExp(expToNextLevel(p.level))}</td>
                      <td className={cn('py-2 pr-2 text-right text-xs font-bold tabular-nums', p.netLevels > 0 ? 'text-emerald-500' : p.netLevels < 0 ? 'text-pink-500' : 'text-muted-foreground')}>
                        {p.netLevels > 0 ? '+' : ''}{p.netLevels}
                      </td>
                      <td className={cn('py-2 text-right text-xs font-bold tabular-nums', p.expGained > 0 ? 'text-emerald-500' : p.expGained < 0 ? 'text-pink-500' : 'text-muted-foreground')}>
                        {p.expGained > 0 ? '+' : ''}{formatExp(p.expGained)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {visible.length === 0 && (
                <div className="py-8 text-center text-sm font-semibold text-muted-foreground">No players match these filters.</div>
              )}
            </div>
            {visible.length > limit && (
              <button
                onClick={() => setLimit((l) => l + 50)}
                className="mt-3 w-full rounded-xl border-2 border-pink-200 bg-pink-50 py-2 text-xs font-bold text-pink-500 hover:bg-pink-100"
              >
                Show more ({visible.length - limit} remaining)
              </button>
            )}
          </div>

          <div className="flex items-start gap-2 rounded-xl border-2 border-purple-100 bg-purple-50/50 p-3 text-[11px] font-semibold text-muted-foreground">
            <Info className="size-4 shrink-0 text-purple-300" />
            <p>
              Experience is calculated from level with Tibia&apos;s official formula, so it is the <em>minimum</em> exp
              for that level &mdash; TibiaData doesn&apos;t expose exact exp points. Level changes are detected on each
              guild sync, so several levels gained between syncs appear as one event.
              {truncated && ' This window hit the 1000-event limit; the oldest events were cut off.'}
            </p>
          </div>
        </>
      )}
    </div>
  );
}

function SortTh({ label, k, sort, setSort }: { label: string; k: SortKey; sort: SortKey; setSort: (k: SortKey) => void }) {
  return (
    <th className="pb-2 pr-2 text-right">
      <button
        onClick={() => setSort(k)}
        className={cn('font-bold uppercase tracking-wider', sort === k ? 'text-pink-500' : 'hover:text-pink-400')}
      >
        {label}{sort === k && ' ↓'}
      </button>
    </th>
  );
}

function GuildCard({
  g,
  periodLabel,
  active,
  onClick,
}: {
  g: ReturnType<typeof buildGuildProgress>;
  periodLabel: string;
  active: boolean;
  onClick: () => void;
}) {
  const palette = {
    everlast: { border: 'border-emerald-200', ring: 'ring-emerald-300', bar: 'bg-emerald-400', text: 'text-emerald-500', bg: 'from-emerald-50' },
    ally: { border: 'border-purple-200', ring: 'ring-purple-300', bar: 'bg-purple-400', text: 'text-purple-500', bg: 'from-purple-50' },
    enemy: { border: 'border-pink-200', ring: 'ring-pink-300', bar: 'bg-pink-400', text: 'text-pink-500', bg: 'from-pink-50' },
  }[g.side];
  const topVoc = g.vocations.slice(0, 4);
  return (
    <button
      onClick={onClick}
      className={cn(
        'text-left relative overflow-hidden rounded-2xl border-2 bg-gradient-to-br to-white p-5 shadow-bubbly transition-all hover:-translate-y-0.5',
        palette.border,
        palette.bg,
        active && `ring-2 ${palette.ring}`,
      )}
    >
      <div className={cn('absolute inset-x-0 top-0 h-1.5', palette.bar)} />
      <div className="flex items-center justify-between">
        <h3 className={cn('text-base font-bold', palette.text)}>{SIDE_LABELS[g.side]}</h3>
        <span className="text-[11px] font-bold text-muted-foreground">
          {g.online}/{g.members} online
        </span>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2 text-center">
        <Mini label="Avg level" value={g.avgLevel} />
        <Mini label="Median" value={g.medianLevel} />
        <Mini label="Total exp" value={formatExp(g.totalExp)} />
      </div>
      <div className="mt-3 flex items-center justify-between rounded-xl bg-white/70 px-3 py-2 text-xs font-bold">
        <span className="text-muted-foreground">{periodLabel}</span>
        <span className={g.netLevels >= 0 ? 'text-emerald-500' : 'text-pink-500'}>
          {g.netLevels >= 0 ? '+' : ''}{g.netLevels} lvl
        </span>
        <span className={g.expGained >= 0 ? 'text-emerald-500' : 'text-pink-500'}>
          {g.expGained >= 0 ? '+' : ''}{formatExp(g.expGained)} exp
        </span>
      </div>
      {g.highest && (
        <div className="mt-2 flex items-center gap-1.5 text-[11px] font-bold text-muted-foreground">
          <Crown className="size-3 text-amber-400" fill="currentColor" />
          Highest: <span className="text-foreground">{g.highest.name}</span> ({g.highest.level})
        </div>
      )}
      <div className="mt-3 flex flex-wrap gap-1.5">
        {topVoc.map((v) => (
          <span key={v.vocation} className="rounded-md bg-white/80 px-1.5 py-0.5 text-[10px] font-bold text-muted-foreground">
            {v.count}&times; {v.vocation} <span className="opacity-60">~{v.avgLevel}</span>
          </span>
        ))}
      </div>
    </button>
  );
}

function Mini({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl bg-white/70 py-1.5">
      <div className="text-base font-bold tabular-nums text-foreground">{value}</div>
      <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">{label}</div>
    </div>
  );
}
