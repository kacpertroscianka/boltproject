'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { CaptainPanel } from '@/components/captain-panel';
import { BattleSupplies } from '@/components/battle-supplies';
import { AfterBattleReport } from '@/components/after-battle-report';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Character, TeamWarCall, TeamWarCallResponse, RetroFragGuardEntry } from '@/lib/types';
import { evaluateFragRisk, FRAG_RISK_CLASSES } from '@/lib/retro-frag-risk';
import { getCharactersBySides, getTeamWarCallResponses, getTeamWarCalls, getRetroFragGuardEntries } from '@/lib/queries';
import { SIDE_LABELS, VOCATION_ICONS, vocationAbbr } from '@/lib/tibia';
import {
  AlertCircle,
  CalendarClock,
  CheckCircle2,
  Copy,
  Crosshair,
  Loader2,
  MapPin,
  Radio,
  Shield,
  Siren,
  Sparkles,
  Users,
} from 'lucide-react';

const STATUS_META = {
  ready: { label: 'READY', classes: 'bg-emerald-100 text-emerald-700 border-emerald-300' },
  omw: { label: 'ON MY WAY', classes: 'bg-amber-100 text-amber-700 border-amber-300' },
  afk: { label: 'AFK', classes: 'bg-rose-100 text-rose-700 border-rose-300' },
} as const;

type Readiness = keyof typeof STATUS_META;

function formatRelativeTime(value: string | null) {
  if (!value) return 'Brak';
  const diffMs = new Date(value).getTime() - Date.now();
  const diffMin = Math.round(diffMs / 60000);
  if (Math.abs(diffMin) < 1) return 'Teraz';
  if (diffMin > 0) return `Za ${diffMin} min`;
  return `${Math.abs(diffMin)} min temu`;
}

function getBattleClientId() {
  if (typeof window === 'undefined') return 'server';
  const key = 'battle_command_client_id';
  const existing = window.localStorage.getItem(key);
  if (existing) return existing;
  const value = `bc_${window.crypto.randomUUID()}`;
  window.localStorage.setItem(key, value);
  return value;
}

export default function BattleCommandPage() {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [warCalls, setWarCalls] = useState<TeamWarCall[]>([]);
  const [responses, setResponses] = useState<TeamWarCallResponse[]>([]);
  const [fragEntries, setFragEntries] = useState<RetroFragGuardEntry[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [rosterAvailable, setRosterAvailable] = useState(false);
  const [callsAvailable, setCallsAvailable] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [captain, setCaptain] = useState(false);
  const [reportCallId, setReportCallId] = useState<string | null>(null);

  const [title, setTitle] = useState('Retro Open PvP team call');
  const [meetingPoint, setMeetingPoint] = useState('Thais depot (set actual place)');
  const [startsAt, setStartsAt] = useState('');
  const [notes, setNotes] = useState('Focus enemy online, prepare blockers + bomb chars.');

  const [selectedPlayer, setSelectedPlayer] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<Readiness>('ready');
  const [responseNote, setResponseNote] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const [charsResult, callsResult, fragResult] = await Promise.allSettled([
      getCharactersBySides(['everlast', 'ally', 'enemy']),
      getTeamWarCalls(),
      getRetroFragGuardEntries(),
    ]);
    if (fragResult.status === 'fulfilled') setFragEntries(fragResult.value);

    let fetchedCalls: TeamWarCall[] = [];

    if (charsResult.status === 'fulfilled') { setCharacters(charsResult.value); setRosterAvailable(true); }
    else setRosterAvailable(false);
    if (callsResult.status === 'fulfilled') {
      setCallsAvailable(true);
      fetchedCalls = callsResult.value;
      setWarCalls(fetchedCalls);
    } else setCallsAvailable(false);

    const activeCall = fetchedCalls.find((call) => call.status === 'active') ?? null;
    if (activeCall) {
      const respResult = await Promise.allSettled([getTeamWarCallResponses(activeCall.id)]);
      if (respResult[0].status === 'fulfilled') {
        setResponses(respResult[0].value);
      } else {
        setResponses([]);
        setError('Nie udało się pobrać statusów READY/OMW/AFK.');
      }
    } else {
      setResponses([]);
    }

    if ([charsResult, callsResult].some((item) => item.status === 'rejected')) {
      setError('Część danych Battle Command nie załadowała się. Jeśli to nowa funkcja, sprawdź migrację Supabase i RPC.');
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    const timer = window.setInterval(() => {
      if (document.visibilityState === 'visible') void load();
    }, 30000);
    return () => window.clearInterval(timer);
  }, [load]);

  const activeCall = useMemo(() => warCalls.find((call) => call.status === 'active') ?? null, [warCalls]);
  const recentCalls = useMemo(() => warCalls.filter((call) => call.status !== 'active').slice(0, 5), [warCalls]);
  const allianceChars = useMemo(() => characters.filter((char) => char.side === 'everlast' || char.side === 'ally'), [characters]);
  const enemyChars = useMemo(() => characters.filter((char) => char.side === 'enemy'), [characters]);
  const readyRoster = useMemo(() => {
    const byName = new Map(characters.map((char) => [char.name.toLowerCase(), char]));
    return responses.map((response) => ({
      response,
      character: byName.get(response.player_name.toLowerCase()) ?? null,
    }));
  }, [responses, characters]);

  const composition = useMemo(() => {
    const summary = new Map<string, { online: number; ready: number; omw: number; afk: number }>();
    for (const char of allianceChars) {
      const key = char.vocation || 'Unknown';
      const existing = summary.get(key) ?? { online: 0, ready: 0, omw: 0, afk: 0 };
      if (char.online) existing.online += 1;
      summary.set(key, existing);
    }
    for (const item of readyRoster) {
      const key = item.character?.vocation || 'Unknown';
      const existing = summary.get(key) ?? { online: 0, ready: 0, omw: 0, afk: 0 };
      existing[item.response.readiness_status] += 1;
      summary.set(key, existing);
    }
    return Array.from(summary.entries()).map(([vocation, stats]) => ({ vocation, ...stats }));
  }, [allianceChars, readyRoster]);

  const fragWarnings = useMemo(() => (fragEntries ?? [])
    .map(entry => ({ entry, risk: evaluateFragRisk(entry) }))
    .filter(item => item.risk.priority >= 2)
    .sort((a,b) => b.risk.priority - a.risk.priority)
    .slice(0, 8), [fragEntries]);

  const responseCounts = useMemo(() => ({
    ready: responses.filter((r) => r.readiness_status === 'ready').length,
    omw: responses.filter((r) => r.readiness_status === 'omw').length,
    afk: responses.filter((r) => r.readiness_status === 'afk').length,
  }), [responses]);

  const onlineAlliance = allianceChars.filter((char) => char.online);
  const onlineEnemy = enemyChars.filter((char) => char.online);
  const availablePlayers = useMemo(() => [...allianceChars].sort((a,b)=> (b.level ?? 0) - (a.level ?? 0)), [allianceChars]);

  const handleCreateCall = async () => {
    setSaving(true);
    setError(null);
    try {
      const response = await fetch('/api/battle-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          action: 'create-call',
          title,
          meetingPoint,
          startsAt: startsAt ? new Date(startsAt).toISOString() : null,
          notes,
          createdBy: selectedPlayer || null,
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || 'Nie udało się utworzyć war call');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Nie udało się utworzyć war call');
    } finally {
      setSaving(false);
    }
  };

  const handleRespond = async () => {
    if (!activeCall || !selectedPlayer) {
      setError('Wybierz swoją postać i aktywny war call.');
      return;
    }
    const char = allianceChars.find((entry) => entry.name === selectedPlayer);
    if (!char) {
      setError('Wybrana postać nie należy do Everlast/Terrory.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const response = await fetch('/api/battle-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          action: 'respond',
          warCallId: activeCall.id,
          clientId: getBattleClientId(),
          playerName: char.name,
          playerSide: char.side,
          readinessStatus: selectedStatus,
          note: responseNote || null,
        }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || 'Nie udało się zapisać statusu');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Nie udało się zapisać statusu');
    } finally {
      setSaving(false);
    }
  };

  const handleEndCall = async () => {
    if (!activeCall) return;
    setSaving(true);
    try {
      const response = await fetch('/api/battle-command', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ action: 'end-call', warCallId: activeCall.id }),
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(body.error || 'Nie udało się zakończyć war call');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Nie udało się zakończyć war call');
    } finally {
      setSaving(false);
    }
  };

  const copyTeamspeakMessage = async () => {
    if (!activeCall) return;
    const message = `[WAR CALL] ${activeCall.title}\nMeet: ${activeCall.meeting_point ?? 'TBA'}\nWhen: ${activeCall.starts_at ? new Date(activeCall.starts_at).toLocaleString() : 'ASAP'}\nReady: ${responseCounts.ready} | OMW: ${responseCounts.omw} | AFK: ${responseCounts.afk}\nNotes: ${activeCall.notes ?? '-'}`;
    await navigator.clipboard.writeText(message);
  };

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-3xl font-black tracking-tight text-foreground flex items-center gap-2">
            <Users className="size-8 text-pink-500" /> Candy Battle Command
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Gather Everlast + Terrory fast, compare online power, and prepare a clean Retro Open PvP push.
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Badge className="rounded-full border-2 border-emerald-300 bg-emerald-50 px-3 py-1 text-emerald-700">Alliance online: {rosterAvailable ? onlineAlliance.length : '—'}</Badge>
          <Badge className="rounded-full border-2 border-pink-300 bg-pink-50 px-3 py-1 text-pink-700">Enemy online: {rosterAvailable ? onlineEnemy.length : '—'}</Badge>
          <Badge className="rounded-full border-2 border-purple-300 bg-purple-50 px-3 py-1 text-purple-700">Active call: {callsAvailable ? activeCall ? 'YES' : 'NO' : '—'}</Badge>
        </div>
      </div>

      {error && (
        <Alert className="border-amber-300 bg-amber-50 text-amber-900">
          <AlertCircle className="size-4" />
          <AlertTitle>Battle Command notice</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <CaptainPanel onChange={setCaptain} />

      {fragEntries === null && !loading && <p className="text-xs text-amber-700">Frag Guard manual status unavailable; no risk assessment can be made.</p>}
      {fragWarnings.length > 0 && (
        <Alert className="border-amber-300 bg-amber-50 text-amber-900">
          <Shield className="size-4" />
          <AlertTitle>⚠️ Retro Frag Guard: check these alliance characters before fighting</AlertTitle>
          <AlertDescription>
            <div className="mt-2 flex flex-wrap gap-2">
              {fragWarnings.map(({ entry, risk }) => <span key={entry.id} className={`rounded-full border px-2 py-1 text-xs font-bold ${FRAG_RISK_CLASSES[risk.level]}`} title={risk.detail}>{entry.character_name} · {risk.label}</span>)}
            </div>
            <p className="mt-2 text-xs">Based only on manually entered counts; not a verified in-game skull status.</p>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-4 md:grid-cols-4">
        <Card className="rounded-3xl border-2 border-emerald-200 bg-gradient-to-br from-emerald-50 to-white shadow-bubbly-everlast">
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Shield className="size-4 text-emerald-500" /> Alliance online</CardTitle></CardHeader>
          <CardContent><div className="text-4xl font-black text-emerald-600">{rosterAvailable ? onlineAlliance.length : '—'}</div><p className="text-xs text-muted-foreground mt-1">Everlast + Terrory visible on Sinistra.</p></CardContent>
        </Card>
        <Card className="rounded-3xl border-2 border-pink-200 bg-gradient-to-br from-pink-50 to-white shadow-bubbly-enemy">
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Crosshair className="size-4 text-pink-500" /> Enemy online</CardTitle></CardHeader>
          <CardContent><div className="text-4xl font-black text-pink-600">{rosterAvailable ? onlineEnemy.length : '—'}</div><p className="text-xs text-muted-foreground mt-1">Mandatory Again online now.</p></CardContent>
        </Card>
        <Card className="rounded-3xl border-2 border-amber-200 bg-gradient-to-br from-amber-50 to-white shadow-bubbly">
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><CheckCircle2 className="size-4 text-amber-500" /> Team status</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-black text-amber-600">{callsAvailable ? `${responseCounts.ready} / ${responseCounts.omw} / ${responseCounts.afk}` : '—'}</div><p className="text-xs text-muted-foreground mt-1">READY / OMW / AFK for current call.</p></CardContent>
        </Card>
        <Card className="rounded-3xl border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-white shadow-bubbly">
          <CardHeader className="pb-2"><CardTitle className="text-sm flex items-center gap-2"><Radio className="size-4 text-purple-500" /> Call ETA</CardTitle></CardHeader>
          <CardContent><div className="text-2xl font-black text-purple-600">{callsAvailable ? activeCall ? formatRelativeTime(activeCall.starts_at) : 'No call' : '—'}</div><p className="text-xs text-muted-foreground mt-1">Next rally timing for alliance.</p></CardContent>
        </Card>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="space-y-6">
          <Card className="rounded-3xl border-2 border-pink-200 bg-white/90 shadow-bubbly">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl"><Siren className="size-5 text-pink-500" /> Active War Call</CardTitle>
              <CardDescription>Create one active rally call for Everlast + Terrory, then let people mark READY / OMW / AFK.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {activeCall ? (
                <div className="space-y-4">
                  <div className="rounded-3xl border-2 border-pink-200 bg-gradient-to-r from-pink-50 to-purple-50 p-4">
                    <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                      <div className="space-y-2">
                        <h2 className="text-2xl font-black text-foreground">{activeCall.title}</h2>
                        <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
                          <span className="inline-flex items-center gap-1"><MapPin className="size-3.5" /> {activeCall.meeting_point || 'No meeting point'}</span>
                          <span className="inline-flex items-center gap-1"><CalendarClock className="size-3.5" /> {activeCall.starts_at ? new Date(activeCall.starts_at).toLocaleString() : 'ASAP'}</span>
                        </div>
                        {activeCall.notes && <p className="text-sm text-foreground/80 whitespace-pre-wrap">{activeCall.notes}</p>}
                      </div>
                      <div className="flex gap-2 flex-wrap">
                        <Button type="button" variant="outline" className="rounded-2xl" onClick={copyTeamspeakMessage}><Copy className="mr-2 size-4" /> Copy TS call</Button>
                        {captain && <Button type="button" className="rounded-2xl bg-pink-500 hover:bg-pink-600" disabled={saving} onClick={handleEndCall}>End call</Button>}
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                    {(['ready','omw','afk'] as Readiness[]).map((status) => (
                      <div key={status} className={`rounded-3xl border-2 p-4 ${STATUS_META[status].classes}`}>
                        <div className="text-xs font-black uppercase tracking-wider">{STATUS_META[status].label}</div>
                        <div className="mt-2 text-3xl font-black">{responseCounts[status]}</div>
                      </div>
                    ))}
                  </div>

                  <div className="rounded-3xl border-2 border-purple-200 bg-purple-50/50 p-4 space-y-3">
                    <div className="text-sm font-black text-purple-700">Check in with your character</div>
                    <div className="grid gap-3 md:grid-cols-2">
                      <div>
                        <label className="text-xs font-bold text-muted-foreground">Character</label>
                        <select value={selectedPlayer} onChange={(e)=>setSelectedPlayer(e.target.value)} className="mt-1 w-full rounded-2xl border-2 border-purple-200 bg-white px-3 py-2 text-sm">
                          <option value="">Select alliance character...</option>
                          {availablePlayers.map((char) => (
                            <option key={char.id} value={char.name}>{char.name} • {SIDE_LABELS[char.side]} • lvl {char.level ?? '?'} {vocationAbbr(char.vocation)}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-xs font-bold text-muted-foreground">Status</label>
                        <select value={selectedStatus} onChange={(e)=>setSelectedStatus(e.target.value as Readiness)} className="mt-1 w-full rounded-2xl border-2 border-purple-200 bg-white px-3 py-2 text-sm">
                          <option value="ready">READY</option>
                          <option value="omw">ON MY WAY</option>
                          <option value="afk">AFK</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="text-xs font-bold text-muted-foreground">Short note (optional)</label>
                      <Input value={responseNote} onChange={(e)=>setResponseNote(e.target.value)} placeholder="e.g. waiting for supplies / 3 min / blocker ready" className="mt-1 rounded-2xl border-2 border-purple-200" />
                    </div>
                    <Button type="button" onClick={handleRespond} disabled={saving || !selectedPlayer} className="rounded-2xl bg-purple-500 hover:bg-purple-600">
                      {saving ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Sparkles className="mr-2 size-4" />} Save readiness
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <Alert className="border-purple-200 bg-purple-50">
                    <Siren className="size-4 text-purple-500" />
                    <AlertTitle>No active battle call</AlertTitle>
                    <AlertDescription>Create one shared war call for the alliance. Only one active call is needed most of the time.</AlertDescription>
                  </Alert>
                  <div className="grid gap-3 md:grid-cols-2">
                    <div>
                      <label className="text-xs font-bold text-muted-foreground">Call title</label>
                      <Input value={title} onChange={(e)=>setTitle(e.target.value)} className="mt-1 rounded-2xl border-2 border-pink-200" />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-muted-foreground">Meeting point</label>
                      <Input value={meetingPoint} onChange={(e)=>setMeetingPoint(e.target.value)} className="mt-1 rounded-2xl border-2 border-pink-200" />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-muted-foreground">Start time (optional)</label>
                    <Input type="datetime-local" value={startsAt} onChange={(e)=>setStartsAt(e.target.value)} className="mt-1 rounded-2xl border-2 border-pink-200 max-w-sm" />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-muted-foreground">Notes</label>
                    <Textarea value={notes} onChange={(e)=>setNotes(e.target.value)} className="mt-1 min-h-[120px] rounded-3xl border-2 border-pink-200" />
                  </div>
                  <Button type="button" onClick={handleCreateCall} disabled={saving || !captain} className="rounded-2xl bg-pink-500 hover:bg-pink-600">
                    {saving ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Siren className="mr-2 size-4" />} Create battle call
                  </Button>
                  {!captain && <p className="text-xs text-amber-700">Captain Mode required to create or end calls. Guests can mark readiness and supplies.</p>}
                </div>
              )}
            </CardContent>
          </Card>

          {activeCall && <BattleSupplies warCallId={activeCall.id} />}

          <Card className="rounded-3xl border-2 border-purple-200 bg-white/90 shadow-bubbly">
            <CardHeader>
              <CardTitle className="text-lg">Team composition</CardTitle>
              <CardDescription>Use this before engaging: how many are online vs already checked in by vocation.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {composition.map((row) => (
                  <div key={row.vocation} className="rounded-3xl border-2 border-purple-200 bg-purple-50/50 p-4">
                    <div className="flex items-center justify-between">
                      <div className="font-black text-foreground flex items-center gap-2"><span>{VOCATION_ICONS[row.vocation] ?? '🍬'}</span><span>{row.vocation}</span></div>
                      <Badge className="rounded-full border-purple-300 bg-white text-purple-700">{vocationAbbr(row.vocation)}</Badge>
                    </div>
                    <div className="mt-3 space-y-1 text-sm">
                      <div className="flex justify-between"><span className="text-muted-foreground">Online</span><span className="font-bold">{row.online}</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">READY</span><span className="font-bold text-emerald-600">{row.ready}</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">OMW</span><span className="font-bold text-amber-600">{row.omw}</span></div>
                      <div className="flex justify-between"><span className="text-muted-foreground">AFK</span><span className="font-bold text-rose-600">{row.afk}</span></div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="rounded-3xl border-2 border-emerald-200 bg-white/90 shadow-bubbly-everlast">
            <CardHeader>
              <CardTitle className="text-lg">Alliance ready board</CardTitle>
              <CardDescription>Self-reported readiness for Everlast + Terrory. Shared-password access does not verify which character a visitor owns.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {readyRoster.length === 0 ? (
                <div className="text-sm text-muted-foreground">No one has checked in yet.</div>
              ) : readyRoster.map(({ response, character }) => (
                <div key={response.id} className="rounded-2xl border-2 border-emerald-200 bg-emerald-50/50 p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-black text-foreground">{response.player_name}</div>
                      <div className="text-xs text-muted-foreground">{character?.guild_name || SIDE_LABELS[response.player_side]} • {character?.vocation || 'Unknown'} • lvl {character?.level ?? '?'}</div>
                      {response.note && <div className="mt-1 text-xs text-foreground/80">{response.note}</div>}
                    </div>
                    <Badge className={`rounded-full border ${STATUS_META[response.readiness_status].classes}`}>{STATUS_META[response.readiness_status].label}</Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-2 border-pink-200 bg-white/90 shadow-bubbly-enemy">
            <CardHeader>
              <CardTitle className="text-lg">Enemy online scout</CardTitle>
              <CardDescription>Quick look at Mandatory Again online pressure right now.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 max-h-[520px] overflow-y-auto">
              {onlineEnemy.length === 0 ? (
                <div className="text-sm text-muted-foreground">{rosterAvailable ? 'No enemy players reported online in the last roster fetch.' : 'Enemy online roster unavailable.'}</div>
              ) : onlineEnemy.slice(0, 40).map((char) => (
                <div key={char.id} className="rounded-2xl border-2 border-pink-200 bg-pink-50/50 p-3 flex items-center justify-between gap-3">
                  <div>
                    <div className="font-black text-foreground">{char.name}</div>
                    <div className="text-xs text-muted-foreground">{char.vocation || 'Unknown'} • lvl {char.level ?? '?'} • {char.rank || 'Member'}</div>
                  </div>
                  <Badge className="rounded-full border-pink-300 bg-white text-pink-700">ONLINE</Badge>
                </div>
              ))}
            </CardContent>
          </Card>

          {reportCallId && <AfterBattleReport warCallId={reportCallId} />}

          <Card className="rounded-3xl border-2 border-yellow-200 bg-gradient-to-br from-yellow-50 to-pink-50 shadow-bubbly">
            <CardHeader>
              <CardTitle className="text-lg">Recent calls</CardTitle>
              <CardDescription>History of your latest rally calls for the alliance.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentCalls.length === 0 ? <div className="text-sm text-muted-foreground">No archived calls yet.</div> : recentCalls.map((call) => (
                <div key={call.id} className="rounded-2xl border-2 border-yellow-200 bg-white/70 p-3">
                  <div className="font-black text-foreground">{call.title}</div>
                  <Button type="button" variant="outline" size="sm" onClick={() => setReportCallId(call.id)} className="mt-2 rounded-xl">View battle report</Button>
                  <div className="text-xs text-muted-foreground mt-1">{call.meeting_point || 'No place'} • {call.starts_at ? new Date(call.starts_at).toLocaleString() : 'ASAP'}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
