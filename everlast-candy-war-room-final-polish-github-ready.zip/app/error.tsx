'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import { AlertTriangle, Home, RefreshCw } from 'lucide-react';

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error('Candy War Room route error', error); }, [error]);
  return (
    <div className="mx-auto max-w-2xl rounded-3xl border-2 border-rose-200 bg-gradient-to-br from-rose-50 via-white to-purple-50 p-8 text-center shadow-bubbly" role="alert">
      <AlertTriangle className="mx-auto size-11 text-rose-500" aria-hidden="true" />
      <h2 className="mt-4 text-xl font-black text-foreground">Nie udało się wyświetlić tej podstrony</h2>
      <p className="mt-2 text-sm text-muted-foreground">Pozostałe części War Room nadal są dostępne. Możesz ponowić próbę lub wrócić do dashboardu.</p>
      <div className="mt-5 flex flex-wrap justify-center gap-3">
        <button onClick={reset} className="inline-flex items-center gap-2 rounded-xl bg-pink-500 px-4 py-2 text-sm font-bold text-white hover:bg-pink-600"><RefreshCw className="size-4" /> Spróbuj ponownie</button>
        <Link href="/" className="inline-flex items-center gap-2 rounded-xl border-2 border-purple-200 bg-white px-4 py-2 text-sm font-bold text-purple-700 hover:bg-purple-50"><Home className="size-4" /> Dashboard</Link>
      </div>
    </div>
  );
}
