'use client';

import { useEffect, useState, useMemo } from 'react';
import Link from 'next/link';
import {
  Crosshair,
  Search,
  TrendingUp,
  TrendingDown,
  Minus,
  Clock,
  Users,
} from 'lucide-react';
import { getCharactersBySide } from '@/lib/queries';
import type { Character } from '@/lib/types';
import { LoadingState, MockDataBadge, StatCard } from '@/components/stat-card';
import { CharacterTag, OnlineIndicator } from '@/components/character-tag';
import { timeAgo } from '@/lib/format';
import { levelDelta } from '@/lib/tibia';
import { cn } from '@/lib/utils';

type SortField = 'level' | 'name' | 'online' | 'last_seen';
type SortDir = 'asc' | 'desc';
type OnlineFilter = 'all' | 'online' | 'offline';

export default function EnemyTrackerPage() {
  const [loading, setLoading] = useState(true);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<OnlineFilter>('all');
  const [sortField, setSortField] = useState<SortField>('level');
  const [sortDir, setSortDir] = useState<SortDir>('desc');

  useEffect(() => {
    getCharactersBySide('enemy')
      .then(setCharacters)
      .catch((e) => console.error(e))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    let result = [...characters];
    if (filter === 'online') result = result.filter((c) => c.online);
    if (filter === 'offline') result = result.filter((c) => !c.online);
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      result = result.filter(
        (c) => c.name.toLowerCase().includes(q) || (c.vocation?.toLowerCase().includes(q) ?? false),
      );
    }
    result.sort((a, b) => {
      let cmp = 0;
      if (sortField === 'level') cmp = (a.level ?? 0) - (b.level ?? 0);
      if (sortField === 'name') cmp = a.name.localeCompare(b.name);
      if (sortField === 'online') cmp = Number(a.online) - Number(b.online);
      if (sortField === 'last_seen') {
        cmp = (a.last_seen_at ? new Date(a.last_seen_at).getTime() : 0) - (b.last_seen_at ? new Date(b.last_seen_at).getTime() : 0);
      }
      return sortDir === 'desc' ? -cmp : cmp;
    });
    return result;
  }, [characters, search, filter, sortField, sortDir]);

  const onlineCount = characters.filter((c) => c.online).length;
  const avgLevel = characters.length > 0 ? Math.round(characters.reduce((sum, c) => sum + (c.level ?? 0), 0) / characters.length) : 0;
  const levelUps = characters.filter((c) => { const delta = levelDelta(c); return delta !== null && delta > 0; }).length;

  const toggleSort = (field: SortField) => {
    if (sortField === field) { setSortDir(sortDir === 'desc' ? 'asc' : 'desc'); }
    else { setSortField(field); setSortDir('desc'); }
  };

  if (loading) return <LoadingState label="Tracking enemy movements..." />;

  return (
    <div className="space-y-6 animate-float-up">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <Crosshair className="size-6 text-pink-400" />
            Enemy Tracker
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5 font-semibold">
            Mandatory Again members — online status, level changes, last seen
          </p>
        </div>
        <MockDataBadge show={true} />
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label="Members Online" value={`${onlineCount}/${characters.length}`} sublabel="Currently active" icon={Users} side="enemy" />
        <StatCard label="Average Level" value={avgLevel} sublabel="Across all members" icon={TrendingUp} side="enemy" />
        <StatCard label="Level Gains" value={levelUps} sublabel="Since last sync" icon={TrendingUp} side="neutral" />
      </div>

      <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-pink-300" />
          <input
            type="text"
            placeholder="Search enemy characters..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border-2 border-pink-200 bg-white/70 py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-200 font-semibold shadow-bubbly"
          />
        </div>
        <div className="flex items-center gap-1 rounded-xl border-2 border-pink-200 bg-white/70 p-1 shadow-bubbly">
          {(['all', 'online', 'offline'] as OnlineFilter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                'rounded-lg px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition-all',
                filter === f ? 'bg-gradient-to-r from-pink-200 to-rose-200 text-pink-500' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border-2 border-pink-200 bg-white/70 overflow-hidden shadow-bubbly">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b-2 border-pink-200 bg-pink-50/50">
                <th className="px-4 py-3 text-left"><SortButton label="Character" field="name" sortField={sortField} sortDir={sortDir} onClick={toggleSort} /></th>
                <th className="px-4 py-3 text-left text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Vocation</th>
                <th className="px-4 py-3 text-left"><SortButton label="Level" field="level" sortField={sortField} sortDir={sortDir} onClick={toggleSort} /></th>
                <th className="px-4 py-3 text-left"><SortButton label="Status" field="online" sortField={sortField} sortDir={sortDir} onClick={toggleSort} /></th>
                <th className="px-4 py-3 text-left text-[11px] font-bold uppercase tracking-wider text-muted-foreground hidden md:table-cell">Level Change</th>
                <th className="px-4 py-3 text-left"><SortButton label="Last Seen" field="last_seen" sortField={sortField} sortDir={sortDir} onClick={toggleSort} /></th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="px-4 py-12 text-center text-muted-foreground font-semibold">No characters match your filters.</td></tr>
              )}
              {filtered.map((char) => {
                const delta = levelDelta(char);
                return (
                  <tr key={char.id} className="border-b border-pink-100 hover:bg-pink-50/50 transition-colors">
                    <td className="px-4 py-3">
                      <Link href={`/character/${encodeURIComponent(char.name)}`} className="hover:opacity-80 transition-opacity">
                        <CharacterTag name={char.name} vocation={char.vocation} level={char.level} side="enemy" rank={char.rank} />
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground font-semibold">{char.vocation ?? '—'}</td>
                    <td className="px-4 py-3"><span className="tabular-nums font-bold text-foreground">{char.level}</span></td>
                    <td className="px-4 py-3"><OnlineIndicator online={char.online} /></td>
                    <td className="px-4 py-3 hidden md:table-cell"><LevelChangeIndicator delta={delta} /></td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-semibold">
                        <Clock className="size-3" />{timeAgo(char.last_seen_at)}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function SortButton({ label, field, sortField, sortDir, onClick }: { label: string; field: SortField; sortField: SortField; sortDir: SortDir; onClick: (f: SortField) => void }) {
  const active = sortField === field;
  return (
    <button
      onClick={() => onClick(field)}
      className={cn('flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider transition-colors', active ? 'text-foreground' : 'text-muted-foreground hover:text-foreground')}
    >
      {label}
      {active && (sortDir === 'desc' ? <TrendingDown className="size-3" /> : <TrendingUp className="size-3" />)}
    </button>
  );
}

function LevelChangeIndicator({ delta }: { delta: number | null }) {
  if (delta === null || delta === 0) {
    return <span className="inline-flex items-center gap-1 text-xs text-muted-foreground font-semibold"><Minus className="size-3" /> —</span>;
  }
  if (delta > 0) {
    return <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-500"><TrendingUp className="size-3" /> +{delta}</span>;
  }
  return <span className="inline-flex items-center gap-1 text-xs font-bold text-pink-500"><TrendingDown className="size-3" /> {delta}</span>;
}
