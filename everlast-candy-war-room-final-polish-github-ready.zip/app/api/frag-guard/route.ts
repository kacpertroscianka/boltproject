import { NextRequest, NextResponse } from 'next/server';
import { isAuthenticated } from '@/lib/auth-server';
import { hasCaptainAccess } from '@/lib/captain-auth';
import { isSameOrigin, isUuid } from '@/lib/team-request';
import { getServerSupabase, getCandySecret } from '@/lib/supabase-server';

function privateJson(body: unknown, status = 200): NextResponse {
  const res = NextResponse.json(body, { status });
  res.headers.set('Cache-Control', 'private, no-store');
  return res;
}

export async function POST(req: NextRequest) {
  if (!isAuthenticated()) return privateJson({ error: 'Unauthorized' }, 401);
  if (!isSameOrigin(req)) return privateJson({ error: 'Invalid origin' }, 403);
  if (!hasCaptainAccess()) return privateJson({ error: 'Captain Mode required' }, 403);
  try {
    const body = await req.json();
    const { action } = body as { action?: string };
    const supabase = getServerSupabase();
    const secret = getCandySecret();

    if (action === 'upsert') {
      const { characterName, side, unjust24h, unjust7d, unjust30d, notes, updatedBy } = body as Record<string, string | number | null | undefined>;
      if (typeof characterName !== 'string' || !characterName.trim() || characterName.length > 80 ||
          !['everlast', 'ally'].includes(String(side)) ||
          [unjust24h, unjust7d, unjust30d].some(v => typeof v !== 'number' || !Number.isSafeInteger(v) || v < 0 || v > 999) ||
          (notes != null && (typeof notes !== 'string' || notes.length > 1500)))
        return privateJson({ error: 'Invalid frag entry' }, 400);
      const { data, error } = await supabase.rpc('upsert_retro_frag_guard_entry', {
        p_secret: secret,
        p_character_name: characterName,
        p_side: side,
        p_unjust_24h: Number(unjust24h) || 0,
        p_unjust_7d: Number(unjust7d) || 0,
        p_unjust_30d: Number(unjust30d) || 0,
        p_notes: typeof notes === 'string' ? notes : null,
        p_updated_by: typeof updatedBy === 'string' ? updatedBy : null,
      });
      if (error) throw error;
      return privateJson({ data });
    }

    if (action === 'delete') {
      const { id } = body as Record<string, string | undefined>;
      if (!isUuid(id)) return privateJson({ error: 'Invalid ID' }, 400);
      const { data, error } = await supabase.rpc('delete_retro_frag_guard_entry', {
        p_secret: secret,
        p_id: id,
      });
      if (error) throw error;
      return privateJson({ data });
    }

    return privateJson({ error: 'Unknown action' }, 400);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Frag guard operation failed';
    return privateJson({ error: message }, 500);
  }
}
