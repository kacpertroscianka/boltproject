import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { createHmac } from 'crypto';
import { COOKIE_NAME, isAuthenticated } from '@/lib/auth-server';
import { getServerSupabase, getCandySecret } from '@/lib/supabase-server';

export const runtime = 'nodejs';

function privateJson(body: unknown, status: number) {
  const response = NextResponse.json(body, { status });
  response.headers.set('Cache-Control', 'private, no-store, max-age=0');
  response.headers.set('Vary', 'Cookie');
  return response;
}

/**
 * POST a heartbeat from a visible authenticated page.
 * The browser never supplies a presence identifier: it is generated from the
 * verified HttpOnly session cookie using a server-only keyed HMAC.
 * Different tabs with the same session cookie map to the SAME presence row.
 */
export async function POST() {
  if (!isAuthenticated()) {
    return privateJson({ error: 'Unauthorized' }, 401);
  }

  try {
    const token = cookies().get(COOKIE_NAME)?.value;
    if (!token) return privateJson({ error: 'Unauthorized' }, 401);

    const secret = getCandySecret();
    const sessionHash = createHmac('sha256', secret)
      .update('candy-presence-v1:')
      .update(token)
      .digest('hex');

    const { data, error } = await getServerSupabase().rpc('touch_candy_presence', {
      p_secret: secret,
      p_session_hash: sessionHash,
    });

    if (error || typeof data !== 'number' || !Number.isSafeInteger(data) || data < 0) {
      // A missing migration or upstream issue must never become a false 0.
      return privateJson({ error: 'Presence temporarily unavailable' }, 503);
    }

    return privateJson({ count: data, activeWindowSeconds: 90 }, 200);
  } catch {
    return privateJson({ error: 'Presence temporarily unavailable' }, 503);
  }
}
