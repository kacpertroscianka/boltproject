import { NextRequest } from 'next/server';
import { isAuthenticated } from '@/lib/auth-server';
import { captainConfigured, checkCaptainPassword, captainCookie, hasCaptainAccess, issueCaptainToken, type CaptainTeam } from '@/lib/captain-auth';
import { isSameOrigin, privateResponse } from '@/lib/team-request';

export async function GET() {
  if (!isAuthenticated()) return privateResponse({ error: 'Unauthorized' }, 401);
  return privateResponse({ configured: captainConfigured(), captain: hasCaptainAccess() });
}

// A basic in-process throttle protects local dev; production needs an edge/WAF rate limiter.
const attempts = new Map<string, { count: number; until: number }>();
export async function POST(req: NextRequest) {
  if (!isAuthenticated()) return privateResponse({ error: 'Unauthorized' }, 401);
  if (!isSameOrigin(req)) return privateResponse({ error: 'Invalid origin' }, 403);
  if (!captainConfigured()) return privateResponse({ error: 'Captain access is not configured' }, 503);
  const client = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim().slice(0, 90) || 'unknown';
  const now = Date.now();
  const previous = attempts.get(client);
  if (previous && previous.until > now && previous.count >= 5) return privateResponse({ error: 'Too many attempts' }, 429);
  try {
    const body: unknown = await req.json();
    if (!body || typeof body !== 'object' || !('password' in body) || typeof body.password !== 'string' || !('team' in body) || !['everlast','terrory','owner'].includes(String(body.team))) return privateResponse({ error: 'Invalid login fields' }, 400);
    const team = body.team as CaptainTeam;
    if (!checkCaptainPassword(body.password, team)) {
      attempts.set(client, { count: previous && previous.until > now ? previous.count + 1 : 1, until: now + 15 * 60_000 });
      return privateResponse({ error: 'Invalid captain password' }, 401);
    }
    attempts.delete(client);
    const res = privateResponse({ captain: true, configured: true });
    const opts = captainCookie();
    res.cookies.set(opts.name, issueCaptainToken(team), opts);
    return res;
  } catch { return privateResponse({ error: 'Invalid request' }, 400); }
}

export async function DELETE(req: NextRequest) {
  if (!isAuthenticated()) return privateResponse({ error: 'Unauthorized' }, 401);
  if (!isSameOrigin(req)) return privateResponse({ error: 'Invalid origin' }, 403);
  const res = privateResponse({ captain: false });
  res.cookies.set(captainCookie().name, '', { ...captainCookie(), maxAge: 0 });
  return res;
}
