import { NextRequest, NextResponse } from 'next/server';
import { isAuthenticated } from '@/lib/auth-server';
import { getServerSupabase, getCandySecret } from '@/lib/supabase-server';

/**
 * Unified data proxy. All browser data requests go through here.
 * Verifies session cookie, then calls SECURITY DEFINER RPC functions
 * that check the CANDY_SESSION_SECRET server-side token.
 */
export async function GET(req: NextRequest) {
  if (!isAuthenticated()) {
    return unauthorized();
  }

  const { searchParams } = new URL(req.url);
  const query = searchParams.get('q');

  if (!query) {
    return privateJson({ error: 'Query required' }, 400);
  }

  try {
    const supabase = getServerSupabase();
    const secret = getCandySecret();
    const params: Record<string, string> = {};
    searchParams.forEach((v, k) => {
      if (k !== 'q') params[k] = v;
    });

    let data: unknown = null;

    switch (query) {
      case 'characters-by-side': {
        const sides = (params.sides || '').split(',').filter(Boolean);
        const { data: result, error } = await supabase.rpc('get_characters_by_side', {
          p_secret: secret,
          p_sides: sides,
        });
        if (error) throw error;
        data = result;
        break;
      }
      case 'character-by-name': {
        const { data: result, error } = await supabase.rpc('get_character_by_name', {
          p_secret: secret,
          p_name: params.name || '',
        });
        if (error) throw error;
        // plpgsql returns a row of NULLs (not NULL) when nothing matches
        const row = result as Record<string, unknown> | null;
        data = row && row.id ? row : null;
        break;
      }
      case 'search-characters': {
        const { data: result, error } = await supabase.rpc('search_characters', {
          p_secret: secret,
          p_query: params.query || '',
          p_limit: Number(params.limit) || 20,
        });
        if (error) throw error;
        data = result;
        break;
      }
      case 'guilds': {
        const { data: result, error } = await supabase.rpc('get_guilds', {
          p_secret: secret,
        });
        if (error) throw error;
        data = result;
        break;
      }
      case 'recent-deaths': {
        const { data: result, error } = await supabase.rpc('get_death_events', {
          p_secret: secret,
          p_limit: Number(params.limit) || 200,
        });
        if (error) throw error;
        data = result;
        break;
      }
      case 'combat-for-character': {
        const { data: result, error } = await supabase.rpc('get_combat_events_for_char', {
          p_secret: secret,
          p_name: params.name || '',
          p_limit: Math.min(Math.max(Number(params.limit) || 5000, 1), 5000),
        });
        if (error) throw error;
        data = result ?? [];
        break;
      }
      case 'deaths-for-character': {
        const { data: result, error } = await supabase.rpc('get_deaths_for_char', {
          p_secret: secret,
          p_name: params.name || '',
          p_limit: Number(params.limit) || 50,
        });
        if (error) throw error;
        data = result;
        break;
      }
      case 'war-events': {
        const { data: result, error } = await supabase.rpc('get_war_events', {
          p_secret: secret,
          p_limit: Number(params.limit) || 2000,
        });
        if (error) throw error;
        // Apply filters client-side (the RPC returns all, we filter here)
        let filtered = result as Record<string, unknown>[];
        if (params.attribution) filtered = filtered.filter((e) => e.attribution === params.attribution);
        if (params.warCategory) filtered = filtered.filter((e) => e.war_category === params.warCategory);
        if (params.isPvp) filtered = filtered.filter((e) => String(e.is_pvp) === params.isPvp);
        if (params.since) filtered = filtered.filter((e) => new Date(e.death_time as string) >= new Date(params.since));
        if (params.until) filtered = filtered.filter((e) => new Date(e.death_time as string) <= new Date(params.until));
        if (params.search) {
          const q = params.search.toLowerCase();
          filtered = filtered.filter((e) =>
            String(e.character_name || '').toLowerCase().includes(q) ||
            String(e.killer_name || '').toLowerCase().includes(q) ||
            String(e.cause || '').toLowerCase().includes(q)
          );
        }
        data = filtered;
        break;
      }
      case 'recent-activity': {
        const { data: result, error } = await supabase.rpc('get_activity_snapshots', {
          p_secret: secret,
          p_limit: Number(params.limit) || 20,
        });
        if (error) throw error;
        data = result;
        break;
      }
      case 'recent-sync-logs': {
        const { data: result, error } = await supabase.rpc('get_sync_logs', {
          p_secret: secret,
          p_limit: Number(params.limit) || 10,
        });
        if (error) throw error;
        data = result;
        break;
      }
      case 'recent-level-ups': {
        const { data: result, error } = await supabase.rpc('get_level_events', {
          p_secret: secret,
          p_direction: 'up',
          p_limit: Number(params.limit) || 20,
        });
        if (error) throw error;
        data = await enrichLevelEvents(supabase, (result ?? []) as Record<string, unknown>[]);
        break;
      }
      case 'recent-level-downs': {
        const { data: result, error } = await supabase.rpc('get_level_events', {
          p_secret: secret,
          p_direction: 'down',
          p_limit: Number(params.limit) || 20,
        });
        if (error) throw error;
        data = await enrichLevelEvents(supabase, (result ?? []) as Record<string, unknown>[]);
        break;
      }
      case 'level-events-for-character': {
        const { data: result, error } = await supabase.rpc('get_level_events_for_char', {
          p_secret: secret,
          p_name: params.name || '',
          p_limit: Number(params.limit) || 50,
        });
        if (error) throw error;
        data = await enrichLevelEvents(supabase, (result ?? []) as Record<string, unknown>[]);
        break;
      }
      case 'level-guild-leaderboard': {
        const { data: result, error } = await supabase.rpc('get_level_leaderboard', {
          p_secret: secret,
          p_days: Number(params.days) || 7,
        });
        if (error) throw error;
        data = result ?? [];
        break;
      }
      case 'recent-deaths-since': {
        const { data: result, error } = await supabase.rpc('get_death_events', {
          p_secret: secret,
          p_limit: Number(params.limit) || 500,
        });
        if (error) throw error;
        const since = params.since;
        if (since) {
          const sinceDate = new Date(since);
          data = (result as Record<string, unknown>[]).filter(
            (e) => new Date(e.death_time as string) > sinceDate,
          );
        } else {
          data = result;
        }
        break;
      }
      case 'recent-level-events': {
        const direction = params.direction || 'all';
        const limit = Math.min(Number(params.limit) || 500, 5000);
        const directions = direction === 'all' ? ['up', 'down'] : [direction];
        const results = await Promise.all(directions.map(async (requestedDirection) => {
          const { data: result, error } = await supabase.rpc('get_level_events', {
            p_secret: secret,
            p_direction: requestedDirection,
            p_limit: limit,
          });
          if (error) throw error;
          return (result ?? []) as Record<string, unknown>[];
        }));
        const events = Array.from(new Map(results.flat().map((event) => [event.id, event])).values())
          .sort((a, b) => new Date(b.observed_at as string).getTime() - new Date(a.observed_at as string).getTime());
        const since = params.since;
        const filtered = since
          ? events.filter((event) => new Date(event.observed_at as string) > new Date(since))
          : events;
        data = await enrichLevelEvents(supabase, filtered.slice(0, limit));
        break;
      }
      case 'candy-awards': {
        const since = params.since || new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
        const guildFilter = params.guildFilter || 'all';
        const { data: result, error } = await supabase.rpc('get_candy_awards', {
          p_secret: secret,
          p_since: since,
          p_guild_filter: guildFilter,
        });
        if (error) throw error;
        data = result;
        break;
      }
      case 'active-team-war-call': {
        const { data: result, error } = await supabase.rpc('get_active_team_war_call', {
          p_secret: secret,
        });
        if (error) throw error;
        const row = result as Record<string, unknown> | null;
        data = row?.id ? row : null;
        break;
      }
      case 'team-supplies': {
        if (!/^[a-f0-9-]{36}$/i.test(params.warCallId || '')) return privateJson({ error: 'Invalid call ID' }, 400);
        const { data: result, error } = await supabase.rpc('get_team_supply_checklists', {
          p_secret: secret, p_war_call_id: params.warCallId,
        });
        if (error) throw error;
        data = result ?? [];
        break;
      }
      case 'after-battle-report': {
        if (!/^[a-f0-9-]{36}$/i.test(params.warCallId || '')) return privateJson({ error: 'Invalid call ID' }, 400);
        const { data: result, error } = await supabase.rpc('get_team_after_battle_report', {
          p_secret: secret, p_war_call_id: params.warCallId,
        });
        if (error) throw error;
        data = result;
        break;
      }
      case 'team-war-calls': {
        const { data: result, error } = await supabase.rpc('get_team_war_calls', {
          p_secret: secret,
        });
        if (error) throw error;
        data = result ?? [];
        break;
      }
      case 'team-war-call-responses': {
        const { data: result, error } = await supabase.rpc('get_team_war_call_responses', {
          p_secret: secret,
          p_war_call_id: params.warCallId || '',
        });
        if (error) throw error;
        data = result ?? [];
        break;
      }
      case 'retro-observed-last-hits': {
        const { data: result, error } = await supabase.rpc('get_retro_observed_last_hits', {
          p_secret: secret,
        });
        if (error) throw error;
        data = result ?? [];
        break;
      }
      case 'retro-frag-guard': {
        const { data: result, error } = await supabase.rpc('get_retro_frag_guard_entries', {
          p_secret: secret,
        });
        if (error) throw error;
        data = result ?? [];
        break;
      }

      case 'war-sessions': {
        const { data: result, error } = await supabase.rpc('get_war_sessions', {
          p_secret: secret,
          p_limit: Number(params.limit) || 50,
        });
        if (error) throw error;
        data = result;
        break;
      }
      case 'war-session': {
        const { data: result, error } = await supabase.rpc('get_war_session', {
          p_secret: secret,
          p_id: params.id || '',
        });
        if (error) throw error;
        data = result;
        break;
      }
      default:
        return privateJson({ error: 'Unknown query' }, 400);
    }

    return privateJson({ data });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Query failed';
    return privateJson({ error: message }, 500);
  }
}

async function enrichLevelEvents(
  supabase: ReturnType<typeof getServerSupabase>,
  events: Record<string, unknown>[],
): Promise<Record<string, unknown>[]> {
  if (events.length === 0) return events;
  const { data: characters, error } = await supabase.rpc('get_characters_by_side', {
    p_secret: getCandySecret(),
    p_sides: ['everlast', 'ally', 'enemy'],
  });
  if (error || !characters) return events;
  const roster = new Map((characters as Record<string, unknown>[]).map((character) => [
    String(character.name).toLowerCase(), character,
  ]));
  return events.map((event) => {
    const character = roster.get(String(event.character_name).toLowerCase());
    return character
      ? {
          ...event,
          character_side: character.side,
          character_guild_name: character.guild_name,
          character_vocation: character.vocation,
        }
      : event;
  });
}

function privateJson(body: unknown, status = 200): NextResponse {
  const res = NextResponse.json(body, { status });
  res.headers.set('Cache-Control', 'private, no-store');
  return res;
}

function unauthorized(): NextResponse {
  const res = NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  res.headers.set('Cache-Control', 'private, no-store');
  return res;
}
