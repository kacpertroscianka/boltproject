import { NextResponse } from 'next/server';
import { getCookieOptions } from '@/lib/auth-server';
import { captainCookie } from '@/lib/captain-auth';

export async function POST() {
  const opts = getCookieOptions();
  const res = NextResponse.json({ ok: true });
  for (const name of [opts.name, '__Host-candy_session']) {
    res.cookies.set(name, '', {
      httpOnly: true,
      secure: opts.secure,
      sameSite: opts.sameSite,
      path: opts.path,
      maxAge: 0,
    });
  }
  res.cookies.set(captainCookie().name, '', { ...captainCookie(), maxAge: 0 });
  return res;
}
