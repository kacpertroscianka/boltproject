import { NextRequest, NextResponse } from 'next/server';
import { captainCookie } from '@/lib/captain-auth';
import { verifyPassword, createSessionToken, isAuthConfigured, getCookieOptions, getCookieName, SESSION_DURATION_MS } from '@/lib/auth-server';

const attempts = new Map<string, { count: number; firstAt: number }>();
const MAX_ATTEMPTS = 10;
const WINDOW_MS = 15 * 60 * 1000;

export async function POST(req: NextRequest) {
  if (!isAuthConfigured()) {
    return NextResponse.json(
      { error: 'Server auth not configured.' },
      { status: 503 },
    );
  }

  const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown';
  const now = Date.now();
  const record = attempts.get(ip);
  if (record) {
    if (now - record.firstAt < WINDOW_MS && record.count >= MAX_ATTEMPTS) {
      return NextResponse.json({ error: 'Too many attempts.' }, { status: 429 });
    }
    if (now - record.firstAt >= WINDOW_MS) attempts.delete(ip);
  }

  let body: { password?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }

  const password = body.password;
  if (!password || typeof password !== 'string') {
    bumpAttempt(ip);
    return NextResponse.json({ error: 'Password required' }, { status: 400 });
  }

  const ok = verifyPassword(password);
  if (!ok) {
    bumpAttempt(ip);
    return NextResponse.json({ error: 'Incorrect password' }, { status: 401 });
  }

  attempts.delete(ip);
  const token = createSessionToken();
  const opts = getCookieOptions();

  const res = NextResponse.json({ ok: true });
  res.cookies.set(opts.name, token, {
    httpOnly: opts.httpOnly,
    secure: opts.secure,
    sameSite: opts.sameSite,
    path: opts.path,
    maxAge: opts.maxAge,
  });
  // New shared-password login must not inherit Captain privilege from an earlier user.
  res.cookies.set(captainCookie().name, '', { ...captainCookie(), maxAge: 0 });
  return res;
}

function bumpAttempt(ip: string) {
  const now = Date.now();
  const record = attempts.get(ip);
  if (record && now - record.firstAt < WINDOW_MS) {
    record.count++;
  } else {
    attempts.set(ip, { count: 1, firstAt: now });
  }
}
