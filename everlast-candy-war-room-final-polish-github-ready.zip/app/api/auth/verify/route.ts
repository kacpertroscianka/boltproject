import { NextResponse } from 'next/server';
import { isAuthenticated } from '@/lib/auth-server';

export async function GET() {
  return NextResponse.json({ authenticated: isAuthenticated() });
}
