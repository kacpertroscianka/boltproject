import { NextRequest, NextResponse } from 'next/server';
import { isAuthenticated } from '@/lib/auth-server';
import { hasCaptainAccess } from '@/lib/captain-auth';
import { isSameOrigin, isUuid } from '@/lib/team-request';
import { getServerSupabase, getCandySecret } from '@/lib/supabase-server';

function privateJson(body: unknown, status = 200): NextResponse {
  const res = NextResponse.json(body, { status });
  res.headers.set('Cache-Control', 'private, no-store');
  return res;
}

export async function POST(req: NextRequest) {
  if (!isAuthenticated()) return privateJson({ error: 'Unauthorized' }, 401);
  if (!isSameOrigin(req)) return privateJson({ error: 'Invalid origin' }, 403);
  try {
    const body = await req.json();
    const { action } = body as { action?: string };
    const supabase = getServerSupabase();
    const secret = getCandySecret();

    if (action === 'create-call') {
      if (!hasCaptainAccess()) return privateJson({ error: 'Captain Mode required' }, 403);
      const { title, meetingPoint, startsAt, notes, createdBy } = body as Record<string, string | null | undefined>;
      if (!title || typeof title !== 'string' || title.length > 120 || !title.trim() ||
          (meetingPoint && meetingPoint.length > 180) || (notes && notes.length > 2000) ||
          (createdBy && createdBy.length > 80) ||
          (startsAt && (Number.isNaN(Date.parse(startsAt)) || startsAt.length > 40))) return privateJson({ error: 'Invalid call fields' }, 400);
      const { data, error } = await supabase.rpc('create_team_war_call', {
        p_secret: secret,
        p_title: title,
        p_meeting_point: meetingPoint ?? null,
        p_starts_at: startsAt ?? null,
        p_notes: notes ?? null,
        p_created_by: createdBy ?? null,
      });
      if (error) throw error;
      return privateJson({ data });
    }

    if (action === 'respond') {
      const { warCallId, clientId, playerName, playerSide, readinessStatus, note } = body as Record<string, string | null | undefined>;
      if (!isUuid(warCallId) || !clientId || !playerName || !playerSide || !readinessStatus ||
          clientId.length > 100 || playerName.length > 80 || (note && note.length > 250)) {
        return privateJson({ error: 'Missing response fields' }, 400);
      }
      const { data, error } = await supabase.rpc('upsert_team_war_call_response', {
        p_secret: secret,
        p_war_call_id: warCallId,
        p_client_id: clientId,
        p_player_name: playerName,
        p_player_side: playerSide,
        p_readiness_status: readinessStatus,
        p_note: note ?? null,
      });
      if (error) throw error;
      return privateJson({ data });
    }

    if (action === 'supplies') {
      const { warCallId, clientId, potions, runes, amulets, backpack, voiceComms, note } = body as Record<string, unknown>;
      if (!isUuid(warCallId) || typeof clientId !== 'string' || clientId.length < 8 || clientId.length > 100 ||
          [potions, runes, amulets, backpack, voiceComms].some(v => typeof v !== 'boolean') ||
          (note != null && (typeof note !== 'string' || note.length > 240))) return privateJson({ error: 'Invalid checklist' }, 400);
      const { data, error } = await supabase.rpc('upsert_team_supply_checklist', {
        p_secret: secret, p_war_call_id: warCallId, p_client_id: clientId,
        p_potions: potions, p_runes: runes, p_amulets: amulets,
        p_backpack: backpack, p_voice_comms: voiceComms, p_note: note ?? null,
      });
      if (error) throw error;
      return privateJson({ data });
    }

    if (action === 'end-call') {
      if (!hasCaptainAccess()) return privateJson({ error: 'Captain Mode required' }, 403);
      const { warCallId } = body as Record<string, string | undefined>;
      if (!isUuid(warCallId)) return privateJson({ error: 'Invalid War Call ID' }, 400);
      const { data, error } = await supabase.rpc('end_team_war_call', {
        p_secret: secret,
        p_war_call_id: warCallId,
      });
      if (error) throw error;
      return privateJson({ data });
    }

    return privateJson({ error: 'Unknown action' }, 400);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Battle command operation failed';
    return privateJson({ error: message }, 500);
  }
}
