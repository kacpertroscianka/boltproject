import { NextRequest, NextResponse } from 'next/server';
import { isAuthenticated } from '@/lib/auth-server';
import { getServerSupabase, getCandySecret } from '@/lib/supabase-server';

function privateJson(body: unknown, status = 200): NextResponse {
  const res = NextResponse.json(body, { status });
  res.headers.set('Cache-Control', 'private, no-store');
  return res;
}

export async function GET(req: NextRequest) {
  if (!isAuthenticated()) {
    return privateJson({ error: 'Unauthorized' }, 401);
  }

  const { searchParams } = new URL(req.url);
  const since = searchParams.get('since');
  const limit = Math.min(Number(searchParams.get('limit')) || 100, 500);

  try {
    const supabase = getServerSupabase();
    const secret = getCandySecret();

    const [deathsResult, upLevelsResult, downLevelsResult] = await Promise.all([
      supabase.rpc('get_death_events', { p_secret: secret, p_limit: limit }),
      supabase.rpc('get_level_events', { p_secret: secret, p_direction: 'up', p_limit: limit }),
      supabase.rpc('get_level_events', { p_secret: secret, p_direction: 'down', p_limit: limit }),
    ]);

    const sinceDate = since ? new Date(since) : null;

    const deaths = (deathsResult.data ?? []) as Record<string, unknown>[];
    const upLevels = (upLevelsResult.data ?? []) as Record<string, unknown>[];
    const downLevels = (downLevelsResult.data ?? []) as Record<string, unknown>[];
    const levels = [...upLevels, ...downLevels];

    const filteredDeaths = sinceDate
      ? deaths.filter((d) => new Date(d.death_time as string) > sinceDate)
      : deaths;
    const filteredLevels = sinceDate
      ? levels.filter((l) => new Date(l.observed_at as string) > sinceDate)
      : levels;

    const latestDeath = filteredDeaths.length > 0
      ? Math.max(...filteredDeaths.map((d) => new Date(d.death_time as string).getTime()))
      : 0;
    const latestLevel = filteredLevels.length > 0
      ? Math.max(...filteredLevels.map((l) => new Date(l.observed_at as string).getTime()))
      : 0;
    const latest = Math.max(latestDeath, latestLevel);

    return privateJson({
      deaths: filteredDeaths,
      levelEvents: filteredLevels,
      latestTimestamp: latest > 0 ? new Date(latest + 1).toISOString() : null,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Alert feed failed';
    return privateJson({ error: message }, 500);
  }
}
