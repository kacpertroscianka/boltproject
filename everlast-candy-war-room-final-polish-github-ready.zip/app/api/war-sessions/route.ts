import { NextRequest, NextResponse } from 'next/server';
import { isAuthenticated } from '@/lib/auth-server';
import { getServerSupabase, getCandySecret } from '@/lib/supabase-server';

function privateJson(body: unknown, status = 200): NextResponse {
  const res = NextResponse.json(body, { status });
  res.headers.set('Cache-Control', 'private, no-store');
  return res;
}

export async function POST(req: NextRequest) {
  if (!isAuthenticated()) return privateJson({ error: 'Unauthorized' }, 401);
  try {
    const body = await req.json();
    const { action } = body as { action?: string };
    const supabase = getServerSupabase();
    const secret = getCandySecret();

    if (action === 'create') {
      const { name, scoringMode, notes } = body as { name?: string; scoringMode?: string; notes?: string };
      if (!name || typeof name !== 'string') return privateJson({ error: 'Name required' }, 400);
      const { data, error } = await supabase.rpc('create_war_session', {
        p_secret: secret,
        p_name: name,
        p_scoring_mode: scoringMode || 'last-hit',
        p_notes: notes || null,
      });
      if (error) throw error;
      return privateJson({ data });
    }

    if (action === 'end') {
      const { id, notes } = body as { id?: string; notes?: string };
      if (!id) return privateJson({ error: 'Session id required' }, 400);
      const { data, error } = await supabase.rpc('end_war_session', {
        p_secret: secret,
        p_id: id,
        p_notes: notes || null,
      });
      if (error) throw error;
      return privateJson({ data });
    }

    if (action === 'update') {
      const { id, name, notes, scoringMode } = body as { id?: string; name?: string; notes?: string; scoringMode?: string };
      if (!id) return privateJson({ error: 'Session id required' }, 400);
      const { data, error } = await supabase.rpc('update_war_session', {
        p_secret: secret,
        p_id: id,
        p_name: name || null,
        p_notes: notes ?? null,
        p_scoring_mode: scoringMode || null,
      });
      if (error) throw error;
      return privateJson({ data });
    }

    if (action === 'delete') {
      const { id } = body as { id?: string };
      if (!id) return privateJson({ error: 'Session id required' }, 400);
      const { data, error } = await supabase.rpc('delete_war_session', {
        p_secret: secret,
        p_id: id,
      });
      if (error) throw error;
      return privateJson({ data });
    }

    return privateJson({ error: 'Unknown action' }, 400);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Session operation failed';
    return privateJson({ error: message }, 500);
  }
}
