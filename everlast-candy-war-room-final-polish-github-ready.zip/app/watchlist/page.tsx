'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  Bell,
  Search,
  Plus,
  Trash2,
  LogIn,
  Shield,
  Heart,
  Sparkles,
  Swords,
  Skull,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { searchCharacters } from '@/lib/queries';
import type { Character, WatchlistEntry } from '@/lib/types';
import { LoadingState } from '@/components/stat-card';
import { CharacterTag, OnlineIndicator } from '@/components/character-tag';
import { cn } from '@/lib/utils';

export default function WatchlistPage() {
  const { user, loading: authLoading, signOut } = useAuth();
  const [loading, setLoading] = useState(true);
  const [watchlist, setWatchlist] = useState<WatchlistEntry[]>([]);
  const [search, setSearch] = useState('');
  const [results, setResults] = useState<Character[]>([]);

  useEffect(() => {
    if (!user) return;
    loadWatchlist();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  useEffect(() => {
    if (!search.trim()) { setResults([]); return; }
    const timer = setTimeout(() => { searchCharacters(search, 10).then(setResults).catch(console.error); }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  async function loadWatchlist() {
    setLoading(true);
    const { data } = await supabase.from('watchlists').select('*, character:characters(*)').eq('user_id', user!.id).order('created_at', { ascending: false });
    setWatchlist((data as WatchlistEntry[]) ?? []);
    setLoading(false);
  }

  async function addToWatchlist(characterId: string) {
    const { error } = await supabase.from('watchlists').insert({ user_id: user!.id, character_id: characterId });
    if (!error) { setSearch(''); loadWatchlist(); }
  }

  async function removeFromWatchlist(id: string) {
    const { error } = await supabase.from('watchlists').delete().eq('id', id);
    if (!error) loadWatchlist();
  }

  if (authLoading) return <LoadingState label="Loading..." />;

  if (!user) {
    return (
      <div className="space-y-6 animate-float-up">
        <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
          <Bell className="size-6 text-pink-400" /> Watchlist
        </h1>
        <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-12 text-center shadow-bubbly">
          <LogIn className="size-12 text-pink-200 mx-auto mb-4" />
          <h2 className="text-lg font-bold text-foreground">Sign In Required</h2>
          <p className="text-sm text-muted-foreground mt-1 mb-4 font-semibold">
            Create an account or sign in to follow characters and track their activity.
          </p>
          <Link href="/login" className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-pink-400 to-rose-400 px-5 py-2.5 text-sm font-bold text-white hover:from-pink-500 hover:to-rose-500 transition-all shadow-bubbly">
            <LogIn className="size-4" /> Sign In
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-float-up">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <Bell className="size-6 text-pink-400" /> Watchlist
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5 font-semibold">
            Follow characters and track their deaths and level changes
          </p>
        </div>
        <button onClick={signOut} className="text-xs text-muted-foreground hover:text-foreground transition-colors font-bold">Sign Out</button>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Add to watchlist + search */}
        <div className="space-y-4">
          <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
            <h2 className="text-sm font-bold text-foreground mb-4 flex items-center gap-1.5">
              <Heart className="size-4 text-pink-400" fill="currentColor" /> Add Character to Watchlist
            </h2>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-pink-300" />
              <input
                type="text"
                placeholder="Search characters to follow..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full rounded-xl border-2 border-pink-200 bg-white/70 py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-200 font-semibold"
              />
            </div>
            {results.length > 0 && (
              <div className="mt-2 space-y-1.5 rounded-xl border-2 border-pink-100 bg-pink-50/50 p-2">
                {results.map((char) => {
                  const already = watchlist.some((w) => w.character_id === char.id);
                  return (
                    <div key={char.id} className="flex items-center gap-2 rounded-lg p-1.5">
                      <CharacterTag name={char.name} vocation={char.vocation} level={char.level} side={char.side} />
                      <button
                        onClick={() => addToWatchlist(char.id)}
                        disabled={already}
                        className={cn('ml-auto rounded-lg p-1.5 transition-colors', already ? 'text-muted-foreground/40 cursor-not-allowed' : 'text-emerald-500 hover:bg-emerald-100')}
                      >
                        {already ? <Shield className="size-4" /> : <Plus className="size-4" />}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
            <h2 className="text-sm font-bold text-foreground mb-4">
              Following ({watchlist.length})
            </h2>
            {loading ? (
              <div className="text-sm text-muted-foreground py-4 font-semibold">Loading...</div>
            ) : watchlist.length === 0 ? (
              <div className="text-sm text-muted-foreground py-4 text-center font-semibold">No characters in your watchlist yet.</div>
            ) : (
              <div className="space-y-2.5">
                {watchlist.map((entry) => (
                  <div key={entry.id} className="flex items-center gap-3 rounded-xl border-2 border-pink-100 bg-pink-50/50 p-3">
                    {entry.character ? (
                      <>
                        <Link href={`/character/${encodeURIComponent(entry.character.name)}`}>
                          <CharacterTag name={entry.character.name} vocation={entry.character.vocation} level={entry.character.level} side={entry.character.side} />
                        </Link>
                        <div className="ml-auto flex items-center gap-3">
                          <OnlineIndicator online={entry.character.online} />
                          <button onClick={() => removeFromWatchlist(entry.id)} className="rounded-lg p-1.5 text-muted-foreground hover:text-pink-500 hover:bg-pink-100 transition-colors">
                            <Trash2 className="size-4" />
                          </button>
                        </div>
                      </>
                    ) : (
                      <span className="text-sm text-muted-foreground font-semibold">Character removed</span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Info panel */}
        <div className="space-y-4">
          <div className="rounded-2xl border-2 border-pink-200 bg-white/70 p-5 shadow-bubbly">
            <h2 className="text-sm font-bold text-foreground mb-3 flex items-center gap-1.5">
              <Sparkles className="size-4 text-amber-400" /> How Watchlist Works
            </h2>
            <div className="space-y-2 text-xs text-muted-foreground font-semibold">
              <div className="flex items-start gap-2">
                <Swords className="size-3.5 text-emerald-500 mt-0.5 shrink-0" />
                <span>Follow any character from either guild to see them in your watchlist.</span>
              </div>
              <div className="flex items-start gap-2">
                <Skull className="size-3.5 text-pink-400 mt-0.5 shrink-0" />
                <span>The dashboard shows recent deaths and level changes for all tracked characters.</span>
              </div>
              <div className="flex items-start gap-2">
                <Bell className="size-3.5 text-amber-400 mt-0.5 shrink-0" />
                <span>The sync engine checks for new deaths and level changes on a regular schedule via the TibiaData API.</span>
              </div>
            </div>
          </div>

          <div className="rounded-2xl border-2 border-pink-200 bg-gradient-to-br from-pink-50 to-rose-50 p-5 shadow-bubbly">
            <div className="flex items-center gap-2 mb-2">
              <Heart className="size-4 text-pink-400" fill="currentColor" />
              <h2 className="text-sm font-bold text-foreground">Quick Tips</h2>
            </div>
            <ul className="space-y-1.5 text-xs text-muted-foreground font-semibold">
              <li>Click any followed character to view their full profile and death history.</li>
              <li>The online indicator shows whether a character is currently in-game.</li>
              <li>Search by partial name — results filter as you type.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
