'use client';

import { useEffect, useState, useMemo } from 'react';
import Link from 'next/link';
import {
  Radar,
  Search,
  Swords,
  Skull,
  Filter,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Heart,
} from 'lucide-react';
import { getRecentDeaths } from '@/lib/queries';
import type { DeathEvent } from '@/lib/types';
import { LoadingState, MockDataBadge } from '@/components/stat-card';
import { CharacterTag, SideBadge } from '@/components/character-tag';
import { timeAgo, formatDateTime } from '@/lib/format';
import { cn } from '@/lib/utils';

type SortField = 'death_time' | 'character_level' | 'character_name';
type SortDir = 'asc' | 'desc';
type DeathFilter = 'all' | 'pvp' | 'pve';

const PAGE_SIZE = 15;

export default function DeathRadarPage() {
  const [loading, setLoading] = useState(true);
  const [deaths, setDeaths] = useState<DeathEvent[]>([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<DeathFilter>('all');
  const [sortField, setSortField] = useState<SortField>('death_time');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [page, setPage] = useState(0);

  useEffect(() => {
    getRecentDeaths(500)
      .then(setDeaths)
      .catch((e) => console.error(e))
      .finally(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    let result = [...deaths];
    if (filter === 'pvp') result = result.filter((d) => d.is_pvp);
    if (filter === 'pve') result = result.filter((d) => !d.is_pvp);
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      result = result.filter(
        (d) =>
          d.character_name.toLowerCase().includes(q) ||
          (d.killer_name?.toLowerCase().includes(q) ?? false) ||
          d.reason.toLowerCase().includes(q),
      );
    }
    result.sort((a, b) => {
      let cmp = 0;
      if (sortField === 'death_time') cmp = new Date(a.death_time).getTime() - new Date(b.death_time).getTime();
      if (sortField === 'character_level') cmp = a.character_level - b.character_level;
      if (sortField === 'character_name') cmp = a.character_name.localeCompare(b.character_name);
      return sortDir === 'desc' ? -cmp : cmp;
    });
    return result;
  }, [deaths, search, filter, sortField, sortDir]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const pageData = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const hasMockData = deaths.some((d) => d.source === 'mock-dev');

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDir(sortDir === 'desc' ? 'asc' : 'desc');
    } else {
      setSortField(field);
      setSortDir('desc');
    }
    setPage(0);
  };

  if (loading) return <LoadingState label="Scanning candy death radar..." />;

  return (
    <div className="space-y-6 animate-float-up">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            <Radar className="size-6 text-pink-400 animate-spin-slow" />
            Death Radar
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5 font-semibold">
            Track all deaths across Everlast, Terrory, and Mandatory Again
          </p>
        </div>
        <MockDataBadge show={hasMockData} />
      </div>

      {/* Filters bar */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-pink-300" />
          <input
            type="text"
            placeholder="Search by character, killer, or cause..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0); }}
            className="w-full rounded-xl border-2 border-pink-200 bg-white/70 py-2.5 pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-pink-400 focus:outline-none focus:ring-2 focus:ring-pink-200 font-semibold shadow-bubbly"
          />
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-xl border-2 border-pink-200 bg-white/70 p-1 shadow-bubbly">
            <Filter className="size-3.5 text-purple-400 mx-1.5" />
            {(['all', 'pvp', 'pve'] as DeathFilter[]).map((f) => (
              <button
                key={f}
                onClick={() => { setFilter(f); setPage(0); }}
                className={cn(
                  'rounded-lg px-3 py-1.5 text-xs font-bold uppercase tracking-wider transition-all',
                  filter === f ? 'bg-gradient-to-r from-pink-200 to-purple-200 text-pink-500' : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="text-xs text-muted-foreground font-semibold">
        Showing {pageData.length} of {filtered.length} deaths
        {filtered.length !== deaths.length && ` (filtered from ${deaths.length})`}
      </div>

      {/* Table */}
      <div className="rounded-2xl border-2 border-pink-200 bg-white/70 overflow-hidden shadow-bubbly">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b-2 border-pink-200 bg-pink-50/50">
                <th className="px-4 py-3 text-left">
                  <button onClick={() => toggleSort('character_name')} className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground">
                    Character <ArrowUpDown className="size-3" />
                  </button>
                </th>
                <th className="px-4 py-3 text-left text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Side</th>
                <th className="px-4 py-3 text-left">
                  <button onClick={() => toggleSort('character_level')} className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground">
                    Level <ArrowUpDown className="size-3" />
                  </button>
                </th>
                <th className="px-4 py-3 text-left text-[11px] font-bold uppercase tracking-wider text-muted-foreground hidden md:table-cell">Killer</th>
                <th className="px-4 py-3 text-left text-[11px] font-bold uppercase tracking-wider text-muted-foreground hidden lg:table-cell">Cause</th>
                <th className="px-4 py-3 text-center text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Type</th>
                <th className="px-4 py-3 text-left">
                  <button onClick={() => toggleSort('death_time')} className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-wider text-muted-foreground hover:text-foreground">
                    Time <ArrowUpDown className="size-3" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody>
              {pageData.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-12 text-center text-muted-foreground font-semibold">
                    No deaths match your filters.
                  </td>
                </tr>
              )}
              {pageData.map((death) => (
                <tr key={death.id} className="border-b border-pink-100 hover:bg-pink-50/50 transition-colors">
                  <td className="px-4 py-3">
                    <Link href={`/character/${encodeURIComponent(death.character_name)}`} className="hover:opacity-80 transition-opacity">
                      <CharacterTag name={death.character_name} vocation={death.character_vocation} side={death.character_side} />
                    </Link>
                  </td>
                  <td className="px-4 py-3"><SideBadge side={death.character_side} /></td>
                  <td className="px-4 py-3"><span className="tabular-nums text-foreground font-bold">{death.character_level}</span></td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    {death.killer_name ? (
                      <Link href={`/character/${encodeURIComponent(death.killer_name)}`} className="text-sm text-foreground hover:text-pink-400 transition-colors font-semibold">
                        {death.killer_name}
                      </Link>
                    ) : (
                      <span className="text-sm text-muted-foreground italic">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell max-w-xs">
                    <span className="text-xs text-muted-foreground truncate block font-semibold">{death.reason}</span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    {death.is_pvp ? (
                      <span className="inline-flex items-center gap-1 rounded-lg bg-pink-100 px-2 py-1 text-[10px] font-bold text-pink-500">
                        <Swords className="size-3" /> PvP
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 rounded-lg bg-purple-100 px-2 py-1 text-[10px] font-bold text-purple-400">
                        <Skull className="size-3" /> PvE
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-xs text-foreground font-semibold">{timeAgo(death.death_time)}</div>
                    <div className="text-[10px] text-muted-foreground">{formatDateTime(death.death_time)}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t-2 border-pink-200 px-4 py-3">
            <button
              onClick={() => setPage(Math.max(0, page - 1))}
              disabled={page === 0}
              className="flex items-center gap-1 rounded-xl px-3 py-1.5 text-xs font-bold text-muted-foreground hover:text-foreground hover:bg-pink-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft className="size-4" /> Previous
            </button>
            <span className="text-xs text-muted-foreground font-semibold">
              Page {page + 1} of {totalPages}
            </span>
            <button
              onClick={() => setPage(Math.min(totalPages - 1, page + 1))}
              disabled={page >= totalPages - 1}
              className="flex items-center gap-1 rounded-xl px-3 py-1.5 text-xs font-bold text-muted-foreground hover:text-foreground hover:bg-pink-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              Next <ChevronRight className="size-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
