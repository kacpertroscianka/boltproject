import Link from 'next/link';
import { Home, SearchX } from 'lucide-react';

export default function NotFound() {
  return <div className="mx-auto max-w-lg rounded-3xl border-2 border-pink-200 bg-white/90 p-8 text-center shadow-bubbly">
    <SearchX className="mx-auto size-12 text-pink-400" aria-hidden="true" />
    <h1 className="mt-3 text-2xl font-black text-foreground">🍬 Nie znaleziono strony</h1>
    <p className="mt-2 text-sm text-muted-foreground">Ten adres nie prowadzi do podstrony Everlast Candy War Room.</p>
    <Link href="/" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-pink-500 px-4 py-2 font-bold text-white hover:bg-pink-600"><Home className="size-4" /> Wróć na dashboard</Link>
  </div>;
}
